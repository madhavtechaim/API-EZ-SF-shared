import { Router } from '@angular/router';
import { LogsComponent } from './../../modals/logs/logs.component';
import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-activity-card',
  templateUrl: './activity-card.component.html',
  styleUrls: ['./activity-card.component.scss']
})
export class ActivityCardComponent implements OnInit {
  @Input() CardData:any=''

  details: any = navigator.userAgent;
  regexp: any = /android|iphone|kindle|ipad/i;
  isMobileDevice: any;

  constructor(public dialog: MatDialog, private storageService:StorageService, private router:Router) { }

  ngOnInit(): void {
    this.isMobileDevice = this.regexp.test(this.details);
    // console.log("this.CardData",this.CardData);
    
  }

  openLogsDialog(title:any ,message:any,data:any ){
    const dialogRef = this.dialog.open(LogsComponent, {
      disableClose: true,
      width: '400px',
      data: { title: title, messeage: message,inputValue:data },
    });

    dialogRef.afterClosed().subscribe(result => {
      //success code here
      if(result){
        // this.getCaseDetails();
      }
    });
  }



  eventDetails(data:any): void {
    this.storageService.secureStorage.setItem('updateEvent',data);
    this.router.navigate(['/home/event-details'])
  }

  onPressCall=()=>{
    // console.log("////");
  }

}
