import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GstUploadDocComponent } from './gst-upload-doc.component';

describe('GstUploadDocComponent', () => {
  let component: GstUploadDocComponent;
  let fixture: ComponentFixture<GstUploadDocComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GstUploadDocComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GstUploadDocComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
