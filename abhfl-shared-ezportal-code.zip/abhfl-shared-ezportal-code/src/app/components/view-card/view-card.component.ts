import { environment } from './../../../environments/environment.prod';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-view-card',
  templateUrl: './view-card.component.html',
  styleUrls: ['./view-card.component.scss']
})
export class ViewCardComponent implements OnInit {
  @Input() heading: string = '';
  @Input() subHeading: string = '';
  @Input() icon: string = '';
  @Input() aadhar:any='';
  path: string;
  constructor() { }

  ngOnInit(): void {
    this.path = environment.imgUrl
    // console.log("iconiconicon",this.icon);
  }

}
