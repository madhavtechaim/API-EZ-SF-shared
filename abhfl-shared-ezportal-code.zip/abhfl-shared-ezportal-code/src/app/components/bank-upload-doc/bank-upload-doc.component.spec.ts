import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BankUploadDocComponent } from './bank-upload-doc.component';

describe('BankUploadDocComponent', () => {
  let component: BankUploadDocComponent;
  let fixture: ComponentFixture<BankUploadDocComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BankUploadDocComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BankUploadDocComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
