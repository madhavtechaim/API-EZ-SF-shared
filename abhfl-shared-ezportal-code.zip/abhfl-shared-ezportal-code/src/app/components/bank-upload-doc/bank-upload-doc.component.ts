import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiService } from 'src/app/services/api.service';
import { StorageService } from 'src/app/services/storage.service';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-bank-upload-doc',
  templateUrl: './bank-upload-doc.component.html',
  styleUrls: ['./bank-upload-doc.component.scss']
})
export class BankUploadDocComponent implements OnInit {
  @Input() heading: string = '';
  @Input() subHeading: string = '';
  @Input() data:any='';
  @Output() detect = new EventEmitter<boolean>();
  userData: any;
  constructor(private _apiService:ApiService,private storageService:StorageService,private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    // console.log(this.data);
    
  }


  uploadDoc(event:any){
    const file = event.target.files[0]

    // return;
    this.spinner.show();
    if(event.target.files[0].size > 5242880){
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: "Document size should be up to 5MB",
        showConfirmButton: false,
        timer: 1500
      })
      this.spinner.hide();
      return;
    }

    if(event.target.files[0].type == 'image/png' || event.target.files[0].type == 'image/jpeg' || event.target.files[0].type == 'image/jpg' ||event.target.files[0].type == 'application/pdf'  ){
        // console.log("filefilefile",file);
    const dataUp = new FormData();
    dataUp.append('file',file)
    dataUp.append('caseId', this.data.caseID)
    // dataUp.append('documentId',this.data.did)
    // dataUp.append('docType',this.data.docName?this.data.docName:'')
  
    this._apiService.bankUploadDoc(dataUp).subscribe((response:any)=>{
      if(!response.error){
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
        this.detect.emit(true);
      }else{
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    },(err: HttpErrorResponse) =>
      {
        this.spinner.hide();
      if (err.status === 400 || err.status === 500) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message ,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })

    }else{
      this.spinner.hide();
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Please upload pdf, jpg , jpeg , png image',
        showConfirmButton: false,
        timer: 1500
      })
    }




  
    
    
  }

}
