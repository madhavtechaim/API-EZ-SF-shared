import { AuthService } from 'src/app/services/auth.service';
import { StorageService } from 'src/app/services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';
import { MatDialog } from '@angular/material/dialog';
import { take } from 'rxjs';
import { QueriesComponent } from 'src/app/pages/queries/queries.component';
import { QueriesModalComponent } from 'src/app/modals/queries-modal/queries-modal.component';
@Component({
  selector: 'app-partner-card',
  templateUrl: './partner-card.component.html',
  styleUrls: ['./partner-card.component.scss']
})
export class PartnerCardComponent implements OnInit {

  @Input() data: any
  @Input() year: any

  details: any = navigator.userAgent;
  regexp: any = /android|iphone|kindle|ipad/i;
  isMobileDevice: any;
  completeCaseData: any;
  userInfo: any;
  currentUrl: any;
  trainingApproval: boolean = false;

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, private storageService: StorageService, private spinner: NgxSpinnerService, private _auth: AuthService, public dialog: MatDialog, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    this.isMobileDevice = this.regexp.test(this.details);
    console.log("data:::::::::::", this.data);
    this.currentUrl = this.route.snapshot.url.join('/');
    this.currentUrl == 'training-approval' ? this.trainingApproval = true : this.trainingApproval = false;
    console.log("this.currentUrlthis.currentUrl::", this.currentUrl, this.trainingApproval);
  }

  ngAfterViewInit(): void {
    this.currentUrl == 'training-approval' ? this.trainingApproval = true : this.trainingApproval = false;
  }

  downloadDocuments(dmsId: any) {
    this.spinner.show();
    let documentData

    documentData = {
      DID: dmsId,
    }


    this._apiService.downloadDocuments(documentData).pipe(
      take(1)
    ).subscribe((res: any) => {
      if (!res.error) {
        var contentDisposition = res.headers.get('content-disposition');
        var filename = contentDisposition.split(';')[1].split('filename')[1].split('=')[1].trim().replaceAll('"', '');

        let downloadLink = document.createElement('a');
        downloadLink.href = window.URL.createObjectURL(res.body);
        downloadLink.setAttribute('download', filename);
        document.body.appendChild(downloadLink);
        downloadLink.click();
        downloadLink.remove();
        this.spinner.hide();

      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } if ((err.status === 422)) {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: "Your RCU is under review, Kindly contact OPS team.",
          // title: type+" not available, please try again.",
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }

  onClickQueryCount = (queries: any) => {
    const dialogRef = this.dialog.open(QueriesModalComponent, {
      disableClose: true,
      width: '400px',
      data: { queries: queries },
    });
  }

  onClickApproveTraning = (data: any) => {
    Swal.fire({
      position: 'center',
      icon: 'warning',
      title: "By checking you are confirming the DSA training.",
      confirmButtonColor: "#facea8",
      showCancelButton: true,
      focusConfirm: false,
      confirmButtonText: "Confirm",
      cancelButtonText: "Cancel",
      showConfirmButton: true,
      // timer: 1500
    }).then((result) => {
      if (result.isConfirmed) {
        this.spinner.show();
        this._apiService.approveDSATrainingBySM({
          token: this.userInfo.token,
          version: this.userInfo.version,
          partnerId: data.id,
          mobile_no: data.mobile_no
        }).subscribe((res) => {

          if (!res.error) {
            this.spinner.hide();
            this.data.sm_approve_training_consent = 1;
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: res.message,
              showConfirmButton: false,
              timer: 1500
            })

            // this.ngOnInit()

          } else {
            this.spinner.hide();
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: res.message,
              showConfirmButton: false,
              timer: 1500
            })
          }

        }, (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
        })
      } else if (result.isDenied) {

      }

    });

  }
  onClickApproveCertification = (data: any) => {
    Swal.fire({
      position: 'center',
      icon: 'warning',
      title: "By checking you are confirming the DSA certification.",
      confirmButtonColor: "#facea8",
      showCancelButton: true,
      focusConfirm: false,
      confirmButtonText: "Confirm",
      cancelButtonText: "Cancel",
      showConfirmButton: true,
      // timer: 1500
    }).then((result) => {
      if (result.isConfirmed) {
        this.spinner.show();
        this._apiService.approveDSACertificationBySM({
          token: this.userInfo.token,
          version: this.userInfo.version,
          partnerId: data.id,
          mobile_no: data.mobile_no,
          year: this.year
        }).subscribe((res) => {

          if (!res.error) {
            this.spinner.hide();
            this.data.sm_approve_certification_consent = 1;
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: res.message,
              showConfirmButton: false,
              timer: 1500
            })

            // this.ngOnInit()

          } else {
            this.spinner.hide();
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: res.message,
              showConfirmButton: false,
              timer: 1500
            })
          }

        }, (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
        })
      } else if (result.isDenied) {

      }

    });

  }
}
