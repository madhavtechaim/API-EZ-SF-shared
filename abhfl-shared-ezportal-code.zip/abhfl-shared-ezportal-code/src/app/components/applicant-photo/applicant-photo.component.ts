import { StorageService } from 'src/app/services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import { environment } from 'src/environments/environment';
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-applicant-photo',
  templateUrl: './applicant-photo.component.html',
  styleUrls: ['./applicant-photo.component.scss']
})
export class ApplicantPhotoComponent implements OnInit {
  @Input() required: boolean = false;
  @Input() subHeading: string = '';
  @Input() data:any;
  @Input() type:any;
  @Input() caseID:any;
  @Output() detect = new EventEmitter<boolean>();
  path: string;
  userData: any;
  caseId: any;

  constructor(private _apiService:ApiService, private storageService:StorageService,private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    this.caseId = this.storageService.secureStorage.getItem('CaseID');



    // console.log("cdscdscds",this.data);

  }


  callMe(value : any) {
    this.path = environment.imgUrl + value;
    // console.log("environment.imgUrl + value",environment.imgUrl + value);
    this.userData.caseId = this.caseId;
  }

 uploadDoc(event:any){
  const file = event.target.files[0]
  // console.log(this.caseID);


  // console.log("eventeventeventevent",event.target.files);

  if(event.target.files[0].size > 2097152){
    Swal.fire({
      position: 'center',
      icon: 'warning',
      title: "Image size should be up to 2MB",
      showConfirmButton: false,
      timer: 1500
    })
    return
  }

  if(event.target.files[0].type == 'image/png' || event.target.files[0].type == 'image/jpeg' || event.target.files[0].type == 'image/jpg'){
    if(this.type=='directorUploadFile') {
      this.spinner.show();
      const data = new FormData();
      data.append('file',file)
      data.append('caseId',this.data.caseId)
      data.append('directorId',this.data.directorId)
      data.append('token',this.data.token)
      data.append('version',this.data.version)

      this._apiService.uploadDirectorPhoto(data).subscribe((response:any)=>{
        if(!response.error){
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.detect.emit(true)
        }else{
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },(err: HttpErrorResponse) =>
        {
          this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
      })
    }
    else {
      this.spinner.show();
      const data = new FormData();
      data.append('file',file)
      data.append('caseId',this.caseId ?this.caseId :this.caseID )

      this._apiService.uploadImage(data).subscribe((response:any)=>{
        if(!response.error){
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.detect.emit(true)
        }else{
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },(err: HttpErrorResponse) =>
        {
          this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
      })
    }
  }else{
    Swal.fire({
      position: 'center',
      icon: 'warning',
      title: 'Please upload jpg , jpeg or png image',
      showConfirmButton: false,
      timer: 1500
    })
  }





}

}
