import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-download-document',
  templateUrl: './download-document.component.html',
  styleUrls: ['./download-document.component.scss']
})
export class DownloadDocumentComponent implements OnInit {
  @Input() heading: string = '';
  @Input() subHeading: string = '';
  constructor() { }

  ngOnInit(): void {
  }

}
