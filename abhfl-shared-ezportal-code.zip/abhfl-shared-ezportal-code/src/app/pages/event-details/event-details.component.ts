import { StorageService } from 'src/app/services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { LogsComponent } from 'src/app/modals/logs/logs.component';

@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.scss']
})
export class EventDetailsComponent implements OnInit {

  form: FormGroup;
  formSumitAttempt: boolean;
  isWebRequest: boolean = false;
  highestQualification: any;
  professions: any;

  appointmentStatus: any ;
  appointmentDisposition: any ;
  appointmentSubDisposition: any ;
  flag: boolean;
  eventData: any;
  appointmentdata: any[] =[];
  dispositionData: any[]=[];
  subDispositionData: any=[];
  todayDate:any = moment().format('YYYY-MM-DD');
  userInfo: any;

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, public dialog: MatDialog,private storageService:StorageService, private spinner: NgxSpinnerService) { }


  ngOnInit(): void {

    this.userInfo = this.storageService.secureStorage.getItem("userinfo");

   this.eventData =  this.storageService.secureStorage.getItem('updateEvent');

  //  console.log("this.eventDatathis.eventDatathis.eventData",this.eventData);
   

   this.getAppointment();

  //  this.getDisposition('1',this.appointmentStatus);
   

    this.form = this._formBuilder.group({
      // appointmentStatus: ['', [Validators.required]],
      // appointmentDisposition: ['', [Validators.required]],
      // appointmentSubdisposition: ['', [Validators.required]],
      rescheduleDescription: ['', [Validators.required]]
      // startDate: ['', [Validators.required]],
      // startTime: ['', [Validators.required]],
      // endDate: ['', [Validators.required]],
      // endTime: ['', [Validators.required]],
      // eventReminder: ['', [Validators.required]],
    });


    this.patchData(this.eventData);

  }

  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }


  getAppointment(){
    this.spinner.show();

    this._apiService.getAppointment('').subscribe(res=>{
      if(!res.error){
        this.appointmentdata = res.appointmentData; 
        this.appointmentStatus = this.eventData.appointment_status;
        this.getDisposition(this.appointmentdata.find((ele:any) => ele.appointment_status == this.eventData.appointment_status).aid,this.eventData.appointment_status)
      
        if(this.appointmentdata.find((ele:any) => ele.appointment_status == this.eventData.appointment_status).is_timeApplicable){
          this.flag = true;
          this.form.addControl('startDate',new FormControl('',[Validators.required]));
          this.form.addControl('startTime',new FormControl('',[Validators.required]));
          this.form.addControl('eventReminder',new FormControl('',[Validators.required]));
        }else{
          this.flag = false;
          this.form.removeControl('startDate');
          this.form.removeControl('startTime');
          this.form.removeControl('eventReminder');
        }
        this.form.updateValueAndValidity();
        this.spinner.hide();
      }else{
        this.spinner.hide();
      }
    })
  }

  getDisposition(ids:any,value:any){

    if(value == 'New Appointment'){
      return;
    }


    this.spinner.show();

    if(this.appointmentdata.find((ele:any) => ele.appointment_status == value).is_timeApplicable){
      
      this.flag = true;
      this.form.addControl('startDate',new FormControl('',[Validators.required]));
      this.form.addControl('startTime',new FormControl('',[Validators.required]));
      this.form.addControl('eventReminder',new FormControl('',[Validators.required]));
    }else{
      this.flag = false;
      this.form.removeControl('startDate');
      this.form.removeControl('startTime');
      this.form.removeControl('eventReminder');
    }
    this.form.updateValueAndValidity();

    this.appointmentStatus = value
    this.dispositionData = [];
    this.subDispositionData = [] ; 
    let dataD = {
      appointmentstatusId: ids
    }

    this._apiService.getDisposition(dataD).subscribe(res=>{
      if(!res.error){
        this.spinner.hide();

        this.dispositionData = res.dispositionData?res.dispositionData:[] ; 

        if(this.dispositionData){
          this.appointmentDisposition = this.eventData.disposition_status? this.eventData.disposition_status : '';
          
          if( this.dispositionData.find((ele:any) => (ele.disposition_status
            == this.eventData.disposition_status))){
              this.getSubDisposition( this.dispositionData.find((ele:any) => (ele.disposition_status
                == this.eventData.disposition_status)).did  ,this.dispositionData)
          }
        }
        
      }
    })
  }

  getSubDisposition(value:any,ids:any,){
    this.spinner.show();
    this.appointmentDisposition = value;
    let dataD = {
      dispositionId: ids
    }
    this._apiService.getSubDisposition(dataD).subscribe(res=>{
    
      if(!res.error){
        this.spinner.hide();
        this.subDispositionData = res.dispositionData ; 
        this.appointmentSubDisposition = this.eventData.appointment_subdisposition;
      }else{
        this.spinner.hide();
      }
    })
  }




  patchData(data:any){
    // this.appointmentStatus = data.appointment_status;
    // this.appointmentDisposition = data.appointment_disposition;
    // this.appointmentSubDisposition = data.appointment_subdisposition;

    // if(this.appointmentDisposition == 'Not Met, Reschedule Appointment' || this.appointmentSubDisposition == 'Not Met, Reschedule Appointment as phone keeps ringing'){
    //   this.flag = true;
    //   this.form.addControl('startDate',new FormControl('',[Validators.required]));
    //   this.form.addControl('startTime',new FormControl('',[Validators.required]));
    //   this.form.addControl('endDate',new FormControl('',[Validators.required]));
    //   this.form.addControl('endTime',new FormControl('',[Validators.required]));
    //   this.form.addControl('eventReminder',new FormControl('',[Validators.required]));
    // }else{
    //   this.flag = false;
    //   this.form.removeControl('startDate');
    //   this.form.removeControl('startTime');
    //   this.form.removeControl('endDate');
    //   this.form.removeControl('endTime');
    //   this.form.removeControl('eventReminder');
    // }
    // this.form.updateValueAndValidity();

    // this.form.patchValue({
    //   rescheduleDescription:data.reschedule_description
    // })

    // if(this.flag){
    //   this.form.patchValue({
    //     startDate : data.start_date,
    //     startTime : data.start_time,
    //     endDate : data.end_date,
    //     endTime : data.end_time,
    //     eventReminder : data.event_reminder
    //   })
    // }
  }






  onChangeAppointmentSubDisposition(status:any,value:any) {
    this.appointmentSubDisposition = status;

  }

  submit() {
    this.formSumitAttempt=true;

    if(this.appointmentStatus =='New Appointment'){
     return;
    }

    
    if (this.form.valid) {
      this.spinner.show();
      this.isWebRequest = true;

      let data={
        eventId:this.eventData.event_id,
        appointmentStatus:  this.appointmentStatus,
        appointmentDisposition: this.appointmentDisposition,
        appointmentSubdisposition: this.appointmentSubDisposition,
        rescheduleDescription: this.form.value.rescheduleDescription,
        startDate:  this.form.value.startDate ? this.form.value.startDate : '',
        startTime: this.form.value.startTime ? this.form.value.startTime : '',
        endDate: this.form.value.endDate ? this.form.value.endDate : '',
        endTime: this.form.value.endTime ? this.form.value.endTime : '',
        eventReminder: this.form.value.eventReminder ? this.form.value.eventReminder : '',
        // token:this.storageService.secureStorage.getItem('token'),
        // version:this.storageService.secureStorage.getItem('version'),
        token:this.userInfo.token,
        version:this.userInfo.version,
      
      }


      this._apiService.updateEventSchedule(data).subscribe(
        (response: any) => {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message ,
            showConfirmButton: false,
            timer: 1500
          })
          this.router.navigate(['/home/dsa-dashboard'])
        },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        }
      );
    }
    // this.router.navigate(['/home/dsa-dashboard'])
  }

  cancel() {
    this.router.navigate(['/home/dsa-dashboard'])
  }

  navigateTo(){
    this.router.navigate(['/home/dsa-dashboard'])
  }


  openLogsDialog(title:any ,message:any,data:any ){

    // console.log("title,message,data",title,message,data);
    


    const dialogRef = this.dialog.open(LogsComponent, {
      disableClose: true,
      width: '400px',
      data: { title: title, messeage: message,inputValue:data },
    });

    dialogRef.afterClosed().subscribe(result => {
      //success code here
      if(result){
        // this.getCaseDetails();
      }
    });
  }
}