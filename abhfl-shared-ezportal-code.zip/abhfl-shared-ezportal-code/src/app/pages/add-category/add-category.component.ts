import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { AuthService } from 'src/app/services/auth.service';
import { StorageService } from 'src/app/services/storage.service';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.scss']
})
export class AddCategoryComponent implements OnInit {
  ddd: string | null;
  userData: any;

  form: FormGroup;
  formSumitAttempt: boolean;
  isWebRequest: boolean = false;
  partnerTypeData: any;
  userDetails: any;
  emailVerify: boolean;
  mobileVerify: boolean ;
  rollslist: any;

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, public dialog: MatDialog,private storageService:StorageService,private _auth:AuthService) { }

  ngOnInit(): void {

    this.form = this._formBuilder.group({
      Category: ['', [Validators.required]],
      roleArray:['',[Validators.required]]
    });

    this.getRolls();
  }


  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }


  getRolls(){
    this._apiService.getRolls('').subscribe((response:any)=>{
      if(!response.error){
        this.rollslist = response.roleList;
      }else{
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    },
    (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }



  submit() {
    this.formSumitAttempt = true;
    // console.log(this.form.value)

    if (this.form.valid) {
      this.isWebRequest = true;
      let data={ ...this.form.value}
      // console.log(data);
    this._apiService.addCategory(data).subscribe((response:any)=>{
      if(!response.error){
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
        this.router.navigate(['/home/add-subcategory'])
      }else{
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    },
    (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
    }
    
  }

  cancel() {
    this.router.navigate(['/home'])
  }



}
