import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ESignDocumentComponent } from 'src/app/modals/e-sign-document/e-sign-document.component';
import { AadharComponent } from 'src/app/modals/aadhar/aadhar.component';
import { OtpComponent } from 'src/app/modals/otp/otp.component';

@Component({
  selector: 'app-code-of-conduct',
  templateUrl: './code-of-conduct.component.html',
  styleUrls: ['./code-of-conduct.component.scss']
})
export class CodeOfConductComponent implements OnInit {

  constructor(private router: Router, public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  back(): void {
    this.router.navigate(['/home/upload-documents'])
  }

  next() {
    this.router.navigate(['/home/reference-details'])
  }

  cancel() {
    this.router.navigate(['/home'])
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(ESignDocumentComponent, {
      disableClose: true,
      width: '100%',
      data: {},
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result)
        this.openAadharDialog()
    });
  }

  openAadharDialog(): void {
    const dialogRef = this.dialog.open(AadharComponent, {
      disableClose: true,
      width: '400px',
      data: {},
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result)
        this.openAadharOTPDialog()
    });
  }

  openAadharOTPDialog(): void {
    const dialogRef = this.dialog.open(OtpComponent, {
      disableClose: true,
      width: '400px',
      data: { title: 'E-Sign Document', messeage: 'We have sent OTP to your Aadhar registered mobile number' },
    });

    dialogRef.afterClosed().subscribe(result => {
      //success code here
    });
  }
}
