import { StorageService } from './../../services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ShareLinkComponent } from 'src/app/modals/share-link/share-link.component';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-add-partner',
  templateUrl: './add-partner.component.html',
  styleUrls: ['./add-partner.component.scss']
})
export class AddPartnerComponent implements OnInit {
  form: FormGroup;
  formSumitAttempt: boolean;
  isWebRequest: boolean = false;
  agentTypeData: any;
  userData: any;
  schemeData: any;
  branchArray: any[] = [];
  userInfo: any;
  partnerList: any[] = [{ title: 'Referal Partner', value: 'Referal Partner' }, { title: 'Direct Selling Agent (DSA)', value: 'DSA' }];
  filteredPartner: any[];
  businessActivities: any[];
  filteredBranch: any[] = [];
  branchList: any[] = [];

  selectedWithOtherBusinessDo: string;

  businessActivity: any[] = [
    { title: "Retail shop", value: "Retail shop" },
    { title: "Kirana", value: "Kirana" },
    { title: "Any other Business activities", value: "Any other Business activities" },
  ]
  personaOfChannelData: any[] = [
    { title: "Property Broker", value: "Property Broker" },
    { title: "Financial Planner", value: "Financial Planner" },
    { title: "Insurance Agent", value: "Insurance Agent" },
    { title: "Loan Advisor", value: "Loan Advisor" },
    { title: "CA", value: "CA" },
    { title: "Others", value: "Others" },
  ]
  topFisNameData: any[] = [
    { title: "0", value: 0 },
    { title: "1", value: 1 },
    { title: "2", value: 2 },
    { title: "3", value: 3 },
  ]
  topFISNameDataList: any;
  selectedFisName: any;
  personaOfChannelDataList: any;
  bankMasterList: any = [];
  maxCount: any;
  isVisible: boolean=false;
  rpMMBList:any[]=[
    { "title": "No Business", "value": "No Business" },
    { "title": "<= 15 Lakh ", "value": "<= 15 Lakh " },
    { "title": "15.01 Lakh  to 25 Lakh ", "value": "15.01 Lakh  to 25 Lakh " },
    { "title": "25.01 Lakh  to 40 Lakh ", "value": "25.01 Lakh  to 40 Lakh " },
    { "title": "40.01 Lakh  to 60 Lakh", "value": "40.01 Lakh  to 60 Lakh" },
    { "title": "60.01 Lakh  to 75 Lakh", "value": "60.01 Lakh  to 75 Lakh" },
    { "title": "75.01 Lakh  to 90 Lakh", "value": "75.01 Lakh  to 90 Lakh" },
    { "title": "90.01 Lakh  to 1.10 Cr", "value": "90.01 Lakh  to 1.10 Cr" },
    { "title": "1.11 cr to 1.25 cr", "value": "1.11 cr to 1.25 cr" },
    { "title": "1.26 cr to  1.50 cr", "value": "1.26 cr to  1.50 cr" },
    { "title": "1.51 cr to  2 cr", "value": "1.51 cr to  2 cr" },
    { "title": "> 2 cr", "value": "> 2 cr" }
  ];

  dsaMMBList:any[] = [
    { title: "No Business", value: "No Business" },
    { title: "<= 15 Lakh ", value: "<= 15 Lakh " },
    { title: "15.01 Lakh  to 25 Lakh ", value: "15.01 Lakh  to 25 Lakh " },
    { title: "25.01 Lakh  to 40 Lakh ", value: "25.01 Lakh  to 40 Lakh " },
    { title: "40.01 Lakh  to 60 Lakh", value: "40.01 Lakh  to 60 Lakh" },
    { title: "60.01 Lakh  to 75 Lakh", value: "60.01 Lakh  to 75 Lakh" },
    { title: "75.01 Lakh  to 90 Lakh", value: "75.01 Lakh  to 90 Lakh" },
    { title: "90.01 Lakh  to 1.10 Cr", value: "90.01 Lakh  to 1.10 Cr" },
    { title: "1.11 cr to 1.25 cr", value: "1.11 cr to 1.25 cr" },
    { title: "1.26 cr to  1.50 cr", value: "1.26 cr to  1.50 cr" },
    { title: "1.51 cr to  2 cr", value: "1.51 cr to  2 cr" },
    { title: "2.01 cr to  2.5 cr", value: "2.01 cr to  2.5 cr" },
    { title: "2.51 cr to  3 cr", value: "2.51 cr to  3 cr" },
    { title: "3.01 cr to  4 cr", value: "3.01 cr to  4 cr" },
    { title: "4 cr to  5 cr", value: "4 cr to  5 cr" },
    { title: "5.01 cr to  7 cr", value: "5.01 cr to  7 cr" },
    { title: "7.01 cr to 10 cr", value: "7.01 cr to 10 cr" },
    { title: "> 10cr", value: "> 10cr" },
  ];
  tMMBList: any[]=[];
  

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, public dialog: MatDialog, private storageService: StorageService, private spinner: NgxSpinnerService) { }




  ngOnInit(): void {
    console.log("businessActivitybusinessActivitybusinessActivity", this.businessActivity);
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    // this.userData = this.storageService.secureStorage.getItem('UserDetails');
    console.log("&&&&", this.userInfo)
    // console.log("&&&&-----",this.userData)
    this.form = this._formBuilder.group({
      fullName: ['', [Validators.required]],
      typeOfAgent: ['', [Validators.required, this.requireMatch.bind(this)]],
      branch: ['',[Validators.required]],
      phoneNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      emailAddress: ['', [Validators.required, Validators.email]],
      numberOfFIEmpanelled: ['',[Validators.required,Validators.min,Validators.max]],
      totalFinancialServicesSalesExperienceInYears: ['',[Validators.required,Validators.min,Validators.max]],
      totalMonthlyMortgageBusiness: ['',[Validators.required]],
      monthlyNumberOfFilesOrCustomersProcessed: ['',[Validators.required,Validators.min,Validators.max]],
      mortgageSalesExperienceInYears: ['',[Validators.required,Validators.min,Validators.max]],
      monthlyNumberOfMortgageFilesOrCustomersProcessed: ['',[Validators.required,Validators.min,Validators.max]],
      numberOfEmployeesOrManpowerInOffice: ['',[Validators.required,Validators.min,Validators.max]],
      numberOfBuilderConnects: ['',[Validators.required,Validators.min,Validators.max]],
      averageDisbursementTicketSize: ['',[Validators.required,Validators.min]],

      // old
      // topFisName: ['', [Validators.required, this.requireMatch2.bind(this)]],
      // whichOtherBusinessDo: ['', [Validators.required, this.requireMatch3.bind(this)]],
      // personaOfChannel: ['', [this.requireMatch4.bind(this)]],
      // NumberOfFI: ['', [Validators.required]],
      // NumberOfEmployee: ['', [Validators.required]],
      // houseLoanSellingExperience: ['', [Validators.required]],
      // insuranceSalesExperience: ['', [Validators.required]],
      // scheme: ['', [Validators.required]],
      // totalMonthlyBusinessCR: ['', [Validators.required]],
      // totalMonthlyIncome: ['', [Validators.required]],
      // ownCar: ['',[Validators.required]],
      // builderConnects: ['',[Validators.required]],
      // IsDSABusinessSourceOfIncome: ['',[Validators.required]],
      // incomeComingFromDSABusiness: ['',[Validators.required]],
      // filesprocessedMonth: ['', [Validators.required]],
      // filesprocessedMortgage: ['', [Validators.required]],
      // mentionBusiness: [''],
      // fisnameone: [''],
      // fisnametwo: [''],
      // fisnamethre: [''],
      // builder1: [''],
      // builder2: [''],
      // builder3: ['']
    });

    this.getAllAgentType();
    this.getAllScheme();
    this.getAllBranch();

    this.branchArray = [
      { id: 1, name: 'Pune' },
      { id: 2, name: 'Mumbai' },
      { id: 3, name: 'Nagpur' },
    ]

    this.filteredPartner = [...this.partnerList]
    this.businessActivities = [...this.businessActivity]
    this.topFISNameDataList = [...this.topFisNameData]
    this.personaOfChannelDataList = [...this.personaOfChannelData]



    this.form.controls['typeOfAgent'].valueChanges.subscribe((res: any) => {
      this.filteredPartner = this.partnerList.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
      if (this.filteredPartner.length == 0) {
        this.filteredPartner = [...this.partnerList]
      }
      if (res === 'Referal Partner') {
        this.maxCount = 100;
        this.tMMBList = this.rpMMBList;
        this.isVisible = true;
      } else if(res === 'Direct Selling Agent (DSA)'){
        this.maxCount = 5000;
        this.tMMBList = this.dsaMMBList;
        this.isVisible = true;
      } else {
        this.tMMBList = [];
        this.isVisible = false;
      }
    })

    // this.form.controls['whichOtherBusinessDo'].valueChanges.subscribe((res: any) => {
    //   this.businessActivities = this.businessActivity.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
    //   if (this.businessActivities.length == 0) {
    //     this.businessActivities = [...this.businessActivity]
    //   }
    // })
    // this.form.controls['topFisName'].valueChanges.subscribe((res: any) => {
    //   this.topFISNameDataList = this.topFisNameData.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
    //   if (this.topFISNameDataList.length == 0) {
    //     this.topFISNameDataList = [...this.topFisNameData]
    //   }
    // })
    // this.form.controls['topFisName'].valueChanges.subscribe((res: any) => {
    //   if (typeof res === 'string') {
    //     this.topFISNameDataList = this.topFisNameData.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
    //     if (this.topFISNameDataList.length === 0) {
    //       this.topFISNameDataList = [...this.topFisNameData];
    //     }
    //   }
    // })

    // this.form.controls['personaOfChannel'].valueChanges.subscribe((res: any) => {
    //   this.personaOfChannelDataList = this.personaOfChannelData.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
    //   if (this.personaOfChannelDataList.length == 0) {
    //     this.personaOfChannelDataList = [...this.personaOfChannelData]
    //   }
    // })


    this.form.controls['branch'].valueChanges.subscribe((res: any) => {
      if (res) {
        this.filteredBranch = this.branchList.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
        if (this.filteredBranch.length == 0) {
          this.filteredBranch = [...this.branchList]
        }
      } else {
        this.filteredBranch = [...this.branchList]
      }

    })

    this._apiService.getbankMaster().subscribe((response: any) => {
      if (!response.err) {
        this.bankMasterList = response?.bank_data;
        console.log("bankMster", this.bankMasterList);
      }
    }, (err) => {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
        showConfirmButton: false,
        timer: 1500
      });
    })


  }

  // getNumberArray(value: number): number[] {
  //   for (let i = 0; i < this.selectedFisName; i++) {
  //     const controlName = `branchname${i + 1}`;
  //     this.form.addControl(controlName, this._formBuilder.control('', [Validators.required]));
  //   }
  //   return Array.from({ length: value }, (_, index) => index);
  // }


  requireMatch(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.partnerList && this.partnerList.find((ele: any) => ele.title == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }
  requireMatch2(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.topFisNameData && this.topFisNameData.find((ele: any) => ele.title == selection) == null) {
      return { requireMatch2: true };
    }
    return null;
  }

  requireMatch3(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.businessActivity && this.businessActivity.find((ele: any) => ele.title == selection) == null) {
      return { requireMatch3: true };
    }
    return null;
  }
  requireMatch4(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.personaOfChannelData && this.personaOfChannelData.find((ele: any) => ele.title == selection) == null) {
      return { requireMatch4: true };
    }
    return null;
  }


  requireMatch1(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.branchList && this.branchList.find((ele: any) => ele.value == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }



  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }

  openShareLinkDialog(): void {
    // console.log(this.userData, 'this.userData');

    const dialogRef = this.dialog.open(ShareLinkComponent, {
      disableClose: true,
      width: '400px',
      data: {
        partnerName: this.form.value.fullName,
        phoneNo: this.form.value.phoneNumber,
        emailId: this.form.value.emailAddress,
        schemeId: this.form.value.scheme,
        branchName: this.form.value.branch,
        token: this.userInfo.token,
        version: this.userInfo.version,
        typeOfAgent: this.filteredPartner.find((ele: any) => ele.title == this.form.value.typeOfAgent).value,
        // whichOtherBusinessDo: this.businessActivities.find((ele: any) => ele.title == this.form.value.whichOtherBusinessDo).value,
        smEmail: this.userInfo.email
      },
    });


    dialogRef.afterClosed().subscribe(result => {
      //your code herr
      this.router.navigate(['/home/dsa-dashboard'])
    });
  }


  getAllAgentType() {

    let data = {
      // perPage:100000,
      type: "agent_type"
    }

    this._apiService.getAgentType(data).subscribe((res) => {
      this.agentTypeData = res;
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }


  getAllScheme() {
    let data = {
      type: "scheme"
    }
    this._apiService.getAgentType(data).subscribe((res) => {
      this.schemeData = res;
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }


  getAllBranch() {
    let data = {
      searchTerm: "",
      token: this.userInfo.token,
      version: this.userInfo.version
    }
    this._apiService.getBranchData(data).subscribe((res) => {

      if (!res.error) {
        // console.log(res);
        this.branchArray = res.data;
        this.branchArray.forEach((ele: any) => {
          this.branchList.push({ title: ele.branch_desc, value: ele.branch_desc })
        })
        this.filteredBranch = [...this.branchList];

        // console.log("this.branchArraythis.branchArray",this.branchArray);

      }

    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }




  addPartner() {
    this.formSumitAttempt = true;
    // console.log(this.form.value)

    console.log("add partner data::::", this.form.value);

    if (this.form.valid) {
      this.spinner.show();
      this.isWebRequest = true;
      let data = new FormData();
      // data.append('token', this.userInfo.token);
      data.append('typeOfAgent', this.filteredPartner.find((ele: any) => ele.title == this.form.value.typeOfAgent).value);
      data.append('partnerName', this.form.value.fullName);
      data.append('phoneNo', this.form.value.phoneNumber);
      data.append('emailId', this.form.value.emailAddress);
      data.append('schemeId', this.form.value.scheme);
      data.append('branchName', this.form.value.branch);
      data.append('token', this.userInfo.token);
      data.append('version', this.userInfo.version);
      data.append('numberOfFIEmpanelled', this.form.value.numberOfFIEmpanelled);
      data.append('totalFinancialServicesSalesExperienceInYears', Number(this.form.value.totalFinancialServicesSalesExperienceInYears).toFixed(2));
      data.append('totalMonthlyMortgageBusiness', this.form.value.totalMonthlyMortgageBusiness);
      data.append('monthlyNumberOfFilesOrCustomersProcessed', this.form.value.monthlyNumberOfFilesOrCustomersProcessed);
      data.append('mortgageSalesExperienceInYears', Number(this.form.value.mortgageSalesExperienceInYears).toFixed(2));
      data.append('monthlyNumberOfMortgageFilesOrCustomersProcessed', this.form.value.monthlyNumberOfMortgageFilesOrCustomersProcessed);
      data.append('numberOfEmployeesOrManpowerInOffice', this.form.value.numberOfEmployeesOrManpowerInOffice);
      data.append('numberOfBuilderConnects', this.form.value.numberOfBuilderConnects);
      data.append('averageDisbursementTicketSize', this.form.value.averageDisbursementTicketSize);
      // data.append('builderConnects', this.form.value.builderConnects);
      // data.append('filesprocessedMonth', this.form.value.filesprocessedMonth);
      // data.append('filesprocessedMortgage', this.form.value.filesprocessedMortgage);
      // data.append('NumberOfFI', this.form.value.NumberOfFI);
      // data.append('IsDSABusinessSourceOfIncome', this.form.value.IsDSABusinessSourceOfIncome);
      // data.append('houseLoanSellingExperience', this.form.value.houseLoanSellingExperience);
      // data.append('houseLoanSellingExperience', this.form.value.houseLoanSellingExperience);
      // data.append('incomeComingFromDSABusiness', this.form.value.incomeComingFromDSABusiness);
      // data.append('insuranceSalesExperience', this.form.value.insuranceSalesExperience);
      // data.append('ownCar', this.form.value.ownCar);
      // data.append('NumberOfEmployee', this.form.value.NumberOfEmployee);
      // data.append('personaOfChannel', this.form.value.personaOfChannel);
      // data.append('topFisName', this.form.value.topFisName);
      // data.append('totalMonthlyBusinessCR', this.form.value.totalMonthlyBusinessCR);
      // data.append('totalMonthlyIncome', this.form.value.totalMonthlyIncome);
      // data.append('typeOfAgent', this.form.value.typeOfAgent);
      // data.append('typeOfAgent', 'DSA');
      // data.append('whichOtherBusinessDo', this.form.value.whichOtherBusinessDo);
      // data.append('mentionBusiness', this.form.value.mentionBusiness);
      // data.append('fisnameone', this.form.value.fisnameone),
      // data.append('fisnamethre', this.form.value.fisnamethre),
      // data.append('fisnametwo', this.form.value.fisnametwo),
      // data.append('builder2', this.form.value.builder2),
      // data.append('builder1', this.form.value.builder1),
      // data.append('builder3', this.form.value.builder3),
        this._apiService.addPartner(data).subscribe(
          (response: any) => {

            if (!response.error) {
              this.spinner.hide();
              // Swal.fire({
              //   position: 'center',
              //   icon: 'success',
              //   title: response.message,
              //   showConfirmButton: false,
              //   timer: 1500,

              // })
              this.openShareLinkDialog();
            } else {
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: response.message,
                showConfirmButton: false,
                timer: 1500
              })


            }

            // this.router.navigate(['/home/dsa-dashboard'])

          },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
            this.isWebRequest = false;
          }
        );
    }
  }

  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  cancel() {
    this.router.navigate(['/home/dsa-dashboard'])
  }


  keyPressName(event: any) {
    const pattern = /^[a-zA-Z ]*$/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }


  navigateTo() {
    this.router.navigate(['/home/dsa-dashboard'])
  }

  onInput(event: any): void {
    const value = event.target.value;
    
    // Check if the value is an integer
    if (value && !Number.isInteger(Number(value))) {
      // If it's not an integer, reset the value to the last valid integer
      event.target.value = Math.floor(Number(value)); // Or you could also set it to the last valid integer
    }
  }

  // onInputToFixed(event: any): void {
  //   let value = event.target.value;
  //   console.log("typeof(value)",typeof(value), value);

  //   if (value && !Number.isInteger(Number(value))) {
  //     // If it's not an integer, reset the value to the last valid integer
  //     event.target.value = Number(value).toFixed(2); // Or you could also set it to the last valid integer
  //   }
  //   // value = Number(value).toFixed(2)
  //   // // If the value is a valid number, format it to 2 decimal places
  //   // if (!isNaN(value) && value !== '') {
  //   //   // value = parseFloat(value).toFixed(2);
  //   //   // value = Number(value).toFixed(2);
  //   //   value = Math.floor(value * 100) / 100;
  //   // }
  //   // console.log("value",Number(value),Number(value).toFixed(2));
  //   // // Update the input field with the formatted value
  //   // this.form = value;
  // }

  blockDecimal(event: KeyboardEvent) {
    if (event.key === '.' || event.key === ',' || event.key === 'e') {
      event.preventDefault();
    }
  }

  blockE(event: KeyboardEvent) {
    if (event.key === 'e') {
      event.preventDefault();
    }
  }

  validateTwoDecimals(event: any,formControlName:any): void {
    const input = event.target;
    const value = input.value;
    // if (event.key === 'e') {
    //   event.preventDefault();
    // }
    if (value && !/^\d{0,2}(\.\d{0,2})?$/.test(value)) {
      // Truncate to two decimal places
      const truncated = parseFloat(value).toFixed(2);
      input.value = truncated;
      // this.form.get('totalFinancialServicesSalesExperienceInYears')?.setValue(truncated);
      this.form.get(formControlName)?.setValue(truncated);
    }
    
  }
}
