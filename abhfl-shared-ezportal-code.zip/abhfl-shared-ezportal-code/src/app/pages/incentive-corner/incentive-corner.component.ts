import { StorageService } from './../../services/storage.service';
import { ActivityFiltersComponent } from 'src/app/modals/activity-filters/activity-filters.component';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { debounceTime, Observable } from 'rxjs';
// import * as moment from 'moment';
import { NestedTreeControl } from '@angular/cdk/tree';

import { MatTreeNestedDataSource } from '@angular/material/tree';
import { DomSanitizer } from '@angular/platform-browser';
import { environment } from 'src/environments/environment';
import * as fs from 'file-saver';
import { HttpErrorResponse, HttpEvent, HttpEventType, HttpResponse, HttpClient } from '@angular/common/http';
import { RaisedQueryComponent } from 'src/app/modals/raised-query/raised-query.component';

interface FoodNode {
  name: string;
  children?: FoodNode[];
}

interface FoodNode1 {
  path: FoodNode1[] | Observable<FoodNode1[]> | null | undefined;


  /*  year: string;
  name?:string;
   path: string;
   MIME_TYPE: string;
   months?: FoodNode1[];
   files?: FoodNode1[]; */
  /*   year: string;
    name:string; */
  /*   path?:FoodNode1[];
    files?:FoodNode1[];
    months?: FoodNode1[]; */
}
const TREE_DATA: FoodNode[] = [
  {
    name: 'Fruit',
    children: [{ name: 'Apple' }, { name: 'Banana' }, { name: 'Fruit loops' }],
  },
  {
    name: 'Vegetables',
    children: [
      {
        name: 'Green',
        children: [{ name: 'Broccoli' }, { name: 'Brussels sprouts' }],
      },
      {
        name: 'Orange',
        children: [{ name: 'Pumpkins' }, { name: 'Carrots' }],
      },
    ],
  },
];
interface FoodNode3 {
  year: string;
  path: string;
  months?: FoodNode[];
}

const TREE_DATA3: FoodNode3[] = [
  {
    year: '2020',
    path: 'G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2020',
    months: [{ name: 'Apple' }, { name: 'Banana' }, { name: 'Fruit loops' }],
  },

];

/*  const TREE_DATA1: FoodNode1[] = 
[{ "year": "2020", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2020", "months": [{ "year": "Feb", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2020\\Feb", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2020\\Feb\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }, { "year": "Jan", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2020\\Jan", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2020\\Jan\\RM_EMP002_data - Copy.pdf", "name": "RM_EMP002_data - Copy.pdf" }, { "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2020\\Jan\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }] }, { "year": "2021", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2021", "months": [{ "year": "Feb", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2021\\Feb", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2021\\Feb\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }, { "year": "Jan", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2021\\Jan", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2021\\Jan\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }] }, { "year": "2022", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2022", "months": [{ "year": "Feb", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2022\\Feb", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2022\\Feb\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }, { "year": "Jan", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2022\\Jan", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2022\\Jan\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }] }, { "year": "2023", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2023", "months": [{ "year": "Feb", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2023\\Feb", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2023\\Feb\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }, { "year": "Jan", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2023\\Jan", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2023\\Jan\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }] }]
 */@Component({
  selector: 'app-incentive-corner',
  templateUrl: './incentive-corner.component.html',
  styleUrls: ['./incentive-corner.component.scss']
})
export class IncentiveCornerComponent implements OnInit {
  milestoneOverIndex: any;

  date: any = new Date();
  hour: any = new Date().getHours();
  minute: any = new Date().getMinutes();
  second: any = new Date().getSeconds();
  items = Array.from({ length: 20 }).map((_, i) => `Item #${i}`);
  step = 0;
  imgPath: any;
  imgPath1:any;
  imgsrc:any;
  incentiveCornerListList: any;
  docId: any;
  listArray: any;
  fileExists = false;
  filePath = '';
  fileName: any;
   renderer: any;
   elementRef: any;
   yearList: any;
   monthYearList: any = [];
  //  scorecardsPathArray: any;
  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }


  panelOpenState = false;
  dayEventList: any[] = [];
  isWebRequest: boolean = false;

  filterFromDate: any;
  filterToDate: any;
  filterAgentType: any;
  filterEventTitle: any;
  filterEventType: any;
  filterEventStatus: any;
  greeTingMessage: string;
  appointmentState: any = "All";
  display: any;
  filterData: any;
  userInfo: any;
  treeControl = new NestedTreeControl<FoodNode>(node => node.children);
  treeControl1 = new NestedTreeControl<FoodNode1>(node => node.path);
  dataSource = new MatTreeNestedDataSource<FoodNode>();

  selectedItem:any;
  /*  treeControl1 = new NestedTreeControl<FoodNode1>(node => node.months); */
  dataSource1 = new MatTreeNestedDataSource<FoodNode1>();
  project: any = [];
  constructor(private dom: DomSanitizer,
    private http: HttpClient,private sanitizer: DomSanitizer,
    private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService,
    public dialog: MatDialog, private storageService: StorageService, private spinner: NgxSpinnerService) {

    this.dataSource.data = TREE_DATA;
    /* this.dataSource1.data = TREE_DATA1; */
  }

  ngOnInit(): void {
    this.docId='D102';

    if (this.hour < 12) {
      this.greeTingMessage = "GOOD MORNING";
    } else if (this.hour < 17) {
      this.greeTingMessage = "GOOD AFTERNOON";
    } else {
      this.greeTingMessage = "GOOD EVENING";
    }
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");

    /*  this.project = [{ "year": "2020", 
 "path": "https://www.africau.edu/images/default/sample.pdf", 
 "months": [{ "year": "Feb", "path": "https://www.africau.edu/images/default/sample.pdf", 
 "files": [{ "MIME_TYPE": "pdf", "path": "https://www.africau.edu/images/default/sample.pdf",
  "name": "RM_EMP002_data.pdf" }] }, 
  { "year": "Jan", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2020\\Jan", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2020\\Jan\\RM_EMP002_data - Copy.pdf", "name": "RM_EMP002_data - Copy.pdf" }, { "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2020\\Jan\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }] }, { "year": "2021", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2021", "months": [{ "year": "Feb", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2021\\Feb", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2021\\Feb\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }, { "year": "Jan", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2021\\Jan", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2021\\Jan\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }] }, { "year": "2022", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2022", "months": [{ "year": "Feb", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2022\\Feb", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2022\\Feb\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }, { "year": "Jan", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2022\\Jan", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2022\\Jan\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }] }, { "year": "2023", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2023", "months": [{ "year": "Feb", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2023\\Feb", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2023\\Feb\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }, { "year": "Jan", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2023\\Jan", "files": [{ "MIME_TYPE": "pdf", "path": "G:\\AFT\\Clients\\ABFHL\\project-management-system-laravel-import-export\\public\\incentives\\2023\\Jan\\RM_EMP002_data.pdf", "name": "RM_EMP002_data.pdf" }] }] }]; */

    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    this.getdocumentqueryList();
  // console.log("=====>", this.userInfo.code);
    this._apiService.filterSend.subscribe((res: any) => {
      this.appointmentState = res.eventType
      // console.log("resresres",res);
      // if(res.eventType =='ALL'){
      //   this.appointmentState = res.eventType
      // }else if(res.eventType =='NEW APPOINTMENT'){
      //   this.appointmentState = 'New Appointment'
      // }else if(res.eventType =='FOLLOW UP'){
      //   this.appointmentState = 'Followup'
      // }else if(res.eventType =='CONVERTED'){
      //   this.appointmentState = 'Converted'
      // }else if(res.eventType =='WRONG NUMBER'){
      //   this.appointmentState = 'Wrong Number'
      // }else if(res.eventType =='NOT INTERESTED'){
      //   this.appointmentState = 'Not Interested'
      // }else if(res.eventType =='RENEWAL COLLECTED'){
      //   this.appointmentState = 'Renewal Collected'
      // }


      if (this.appointmentState == 'Follow Up') {
        this.appointmentState = 'Followup';
      }


      this.filterData = {
        startDate: '',
        fromDate: res.fromDate ? res.fromDate : '',
        toDate: res.toDate ? res.toDate : '',
        agentType: '',
        eventTitle: '',
        eventType: '',
        eventStatus: this.appointmentState ? this.appointmentState : '',
        type: res.type ? res.type : 'Monthly',
        searchTerm: '',
        token: this.userInfo.token,
        version: this.userInfo.version,
      }
    })
    this.getEventList(this.filterData);
  }

  getdocumentqueryList() {
    this.spinner.show();

  // console.log("______", this.userInfo.code)
    let data =
    {
      // employee_code:"EMP002", this.storageService.secureStorage.getItem("userinfo")
      // employee_code: this.storageService.secureStorage.getItem("userinfo").code,
      token: this.userInfo.token,
      version: this.userInfo.version,
      employee_code: this.userInfo.code,
      //"EMP002"
    }
    // this._apiService.getDocument(data).subscribe((res:any) => {
      this._apiService.getIncentiveFolders(data).subscribe((res:any) => {
      // let res:any = this._apiService.responseObj;
      this.incentiveCornerListList = res;
      this.yearList = this.incentiveCornerListList.yearList;
      this.monthYearList = this.incentiveCornerListList.monthYearList;
      this.project = this.incentiveCornerListList;
      this.spinner.hide();
      // this.scorecardsPathArray = this.incentiveCornerListList.monthPathList;      


    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }

    })
  }

  search(event: any) {
    // console.log(event,event.target.value
    //   );
    this.filterData.searchTerm = event.target.value
    this.filterData.token = this.userInfo.token;
    this.filterData.version = this.userInfo.version;



    setTimeout(() => {
      // console.log('Hello world')
      this.getEventList(this.filterData);
    }, 2000)


  }
  /*  startTimer() {
     clearInterval(this.interval);
     // console.log("=====>");
     this.interval = setInterval(() => {
       if (this.time === 0) {
         this.time++;
       } else {
         this.time++;
       }
       this.display = this.transform(this.time)
     }, 1000);
   }
  */
 
   raisedQuery(): void {
    const dialogRef = this.dialog.open(RaisedQueryComponent, {
      data:this.docId,
      disableClose: true,
      panelClass:'small-css'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        dialogRef.close();
        
      }
  
    });
  }
  addIncentiveCorner(): void {
    this.router.navigate(['/home/incentive-queries'])
  }
  openFilterDialog(): void {
    const dialogRef = this.dialog.open(ActivityFiltersComponent, {
      disableClose: true,
      width: '400px',
    });

    dialogRef.afterClosed().subscribe(result => {

      if (result.status) {
        this.filterData.eventStatus = result.data.eventStatus ? result.data.eventStatus : [];
        this.filterData.agentType = result.data.agentType ? result.data.agentType : [];
        this.filterData.eventTitle = result.data.eventTitle ? result.data.eventTitle : [];
        this.filterData.fromDate = result.data.fromDate ? result.data.fromDate : this.filterData.fromDate;
        this.filterData.toDate = result.data.toDate ? result.data.fromDate : this.filterData.toDate;
        this.filterData.eventStatus = this.appointmentState ? this.appointmentState : 'All';
        this.filterData.token = this.userInfo.token;
        this.filterData.version = this.userInfo.version;




        this.getEventList(this.filterData);
      } else {

      }

      //success code here
    });
  }

  appointmentStatus(value: any) {
    this.appointmentState = value;
    this.filterData.eventStatus = value;
    this.getEventList(this.filterData);
  }
  downloadExcel(name: any) {
    let path = this.filePath;
    let file = this.filePath.substr(this.filePath.indexOf('incentives'));
    let filename = path.substr(path.lastIndexOf('\\') + 1)
    let sub=file.substr(0, file.indexOf('.'));
    let final=sub.substr(1, sub.lastIndexOf('_')+1).substr(sub.lastIndexOf('\\'));
    // console.log('Sub=',final.substring(0,final.lastIndexOf('_')));
    let space=sub.substr(0, sub.lastIndexOf('_')) + '/' + file.substr(file.indexOf('.') + 1) + '/' + name;
    
    this.http.get(environment.imgUrl + "indocs/" + space.replace(/ /g, '_'), { observe: 'response', responseType: 'blob' as 'json' })
      .subscribe(
        (response: any) => {
          let blob = new Blob([response.body]);
          fs.saveAs(blob, final.substring(0,final.lastIndexOf('_'))+name+"."+ filename.substr(filename.indexOf('.') + 1));

        }, (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
    
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: 'File not exists.Please try to download another file',
              showConfirmButton: false,
              timer: 1500
            })
          }
    
        })
  }
  getEventList(data: any) {
    this.spinner.show();

    data.eventStatus = data.eventStatus != 'All' ? data.eventStatus : ''

    this._apiService.getEventList(data).subscribe((res) => {

      if (!res.error) {
        this.dayEventList = [];
        this.dayEventList = res.eventData;
        this.spinner.hide();
        if (this.dayEventList) {
          // this.appointmentState = this.dayEventList[0].appointment_status
          // if(this.appointmentState != 'All'){
          //   this.dayEventList= this.dayEventList.filter((ele:any )=> ele.appointment_status == this.appointmentState)
          //   // console.log("this.dayEventList",this.dayEventList);
          // }else{

          // }
          this.dayEventList.forEach((element: any) => {
            element.start_time = moment(element.start_time, "HH:mm:ss").format("hh:mm A");
          });
        }
      } else {
        this.spinner.hide();
      }
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }

  navigateTo() {
    this.router.navigate(['/home/dsa-dashboard'])
  }


  expandMilestone(id: number) {
  // console.log("=====>", id);
    if (this.project['managersTeam'][id].selected) {
      this.project['managersTeam'][id].selected = false;
    } else {
      this.project['managersTeam'][id].selected = true;
    }
  // console.log("==wwww===>", id);
    this.spinner.hide();
    this.listArray = this.project;
  }
  expandMilestone1(id: number) {
  // console.log("=====>", id);
    if (this.project['managersTeam']['team'][id].selected) {
      this.project['managersTeam']['team'][id].selected = false;
    } else {
      this.project['managersTeam']['team'][id].selected = true;
    }
  // console.log("==wwww===>", id);
    this.spinner.hide();
    this.listArray = this.project;
  }
  expandTasklist(id: number,) {
    this.spinner.show()
    this.listArray = this.project;

  }


  downloadDocuments(imgPath:any){
  /*   const blob = new Blob([imgPath], { type: 'application/pdf' });
    var contentType='application/pdf' */
    var name='pdf';
   // window.open(imgPath);
 // console.log("======>",imgPath.changingThisBreaksApplicationSecurity  );
    const link = document.createElement("a");
    link.href = imgPath.changingThisBreaksApplicationSecurity ;
    link.download = name;
    link.click();
   // this.downloadFile(imgPath,name, contentType); 
  }

 /*  downloadFile(base64content: string, contentType: string, name: string) {
    const blobData = this.convertBase64ToBlobData(base64content, contentType);

    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      //IE
      window.navigator.msSaveOrOpenBlob(blobData, name);
    } else {
      // chrome
      const blob = new Blob([base64content], { type: contentType });
      const url = window.URL.createObjectURL(blob);
      // window.open(url);
      const link = document.createElement("a");
      link.href = url;
      link.download = name;
      link.click();
    }
  } */
   convertBase64ToBlobData(base64content: string, contentType: string) {
     throw new Error('Method not implemented.');
   }
  download(item: any, item1: any, item2: any,item3:any,type:any) {
    //this.imgPath=null;
    this.spinner.show();
  // console.log("======>", item2);
  // console.log("======>", item,);
  // console.log("======>", item1);
  // console.log("======>", item3);
    this.imgPath = item1.files.path.split("\\").join("/").replaceAll("//","/").replace("D:/API",environment.api);
    this.imgPath1 = item1.files.path.split("\\").join("/").replaceAll("//","/").replace("D:/API",environment.api);
    // console.log(this.imgPath," ",this.imgPath1," ",item1.files.path.split("\\").join("/").replaceAll("//","/").replace("D:/API",environment.api));
    /* this.imgPath1 =  {
      url: item1.files[0].path,
      httpHeaders: {Authorization: `Bearer ${this.getToken()}`},
      withCredentials: true,
    };  */
    this.imgsrc = this.imgPath1;
    this.docId = 'D102';
      this.imgPath = this.imgPath;
    // this.imgPath = this.dom.bypassSecurityTrustResourceUrl(item2.path);
    this.imgPath = this.dom.bypassSecurityTrustResourceUrl(this.imgPath);
    // console.log(this.imgPath," ",this.imgsrc," ",this.imgPath1);
  // this.imgPath=this.sanitizer.bypassSecurityTrustResourceUrl(item2.path);
  // this.imgPath=this.sanitizer.bypassSecurityTrustResourceUrl(this.imgPath);
  if(type=='m'){
    window.open(this.imgPath1);
      
  }
  item2.path = this.imgPath1;
  // console.log(">>>>>>>>>>>>>>",item2);
console.log(this.imgPath,'imgPath')
    this.spinner.hide();
    this.spinner.show();
    this.fileExists = true;
    this.filePath = 'imgPath';
    this.fileName = item1.files.name;
    this._apiService.checkExcelFileExists({
      year: item1.year,
      path: item1.path,
      files: [item2]
    }).subscribe((res) => {
      // this.fileExists = res.fileExist;
      this.selectedItem={
        year: item3.year,
        month: item1.year,
        path: item1.path,
        files: [item2]
      };
      this.filePath = res.file;

      this.spinner.hide();

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }

    })
    /* this.imgPath=item; */
  }

  hasChild = (_: number, node: FoodNode) => !!node.children && node.children.length > 0;
  /*    hasChild1 = (_: number, node: FoodNode1) => !!node.year && node.year.length > 0; 
     hasChild2 = (_: number, node: FoodNode1) => !!node.path && node.path.length > 0; 
     hasChild3 = (_: number, node: FoodNode1) => !!node.months && node.months.length > 0; 
     hasChild4 = (_: number, node: FoodNode1) => !!node.MIME_TYPE && node.MIME_TYPE.length > 0; 
     hasChild5 = (_: number, node: FoodNode1) => !!node.files && node.files.length > 0; 
     hasChild6 = (_: number, node: FoodNode1) => !!node.path && node.path.length > 0;  */

     onError(error: any,imgPath:any) {
    // console.log("KD",imgPath,error)
    }

    downloadPDF(item: any, item1: any, item2: any,item3:any){
      let path = this.filePath;
    let file = this.filePath.substr(this.filePath.indexOf('incentives'));
    let filename = path.substr(path.lastIndexOf('\\') + 1)
    let sub=file.substr(0, file.indexOf('.'));
    let final=sub.substr(1, sub.lastIndexOf('_')+1).substr(sub.lastIndexOf('\\'));
  // console.log('Sub=',final.substring(0,final.lastIndexOf('_')));
    let space=sub.substr(0, sub.lastIndexOf('_')) + '/' + file.substr(file.indexOf('.') + 1) + '/' + name;
    
      window.open(environment.imgUrl + "uploads/DSA/Document_Attachment/" + item.substr(0, item.lastIndexOf('.')) + "." + item.substr(item.lastIndexOf('.') + 1));
      
    }

    fetchScorecard(item: any){
      console.log("scorecardPaths",item);
    }
}
