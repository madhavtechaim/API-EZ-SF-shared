import { CompleteApplicationComponent } from './../../modals/complete-application/complete-application.component';
import { AuthService } from 'src/app/services/auth.service';
import { StorageService } from 'src/app/services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';
import { MatDialog } from '@angular/material/dialog';
import { take } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {


  date: any = new Date();
  hour: any = new Date().getHours();
  minute: any = new Date().getMinutes();
  second: any = new Date().getSeconds();

  applicationData: any;
  greeTingMessage: any = "";
  applicationStateCount: any;
  applicationStateCountPercent: any = 0;
  applicationstepIndicator: any = 1;
  activeStepInView: any = 1;

  ExternalQueryOpen: any = 0;
  ExternalQueryInProgress: any = 0;
  ExternalQueryResolved: any = 0;
  queryData: any;
  type: any='Open';


  activeStepTextView: any = { id: 1, title: "STEP 1 - BASIC DETAILS", description: "BE READY FOR SEAMLESS ONBOARDING" , link:'/home/basic-details'};
  stepsArray: any = [
    { id: 1, title: "STEP 1 - BASIC DETAILS", description: "BE READY FOR SEAMLESS ONBOARDING" , link:'/home/basic-details'  },
    { id: 2, title: "STEP 2 - KYC DETAILS", description: "CHECK IF ITS YOU. Keep your PAN, Aadhaar Card and Photo Ready. Say Cheeeze, For your Happy Picture", link:'/home/kyc-details' },
    { id: 3, title: "STEP 3 - PERSONAL DETAILS", description: "UNDERSTAND YOUR PROFILE", link:'/home/partner-details'  },
    { id: 4, title: "STEP 4 - ADDRESS DETAILS", description: "VERIFY YOUR ADDRESS", link:'/home/address-details'  },
    { id: 5, title: "STEP 5 - BANK DETAILS", description: "FOR YOUR PAYOUT TRANSFER", link:'/home/bank-details'  },
    { id: 6, title: "STEP 6 - DOCUMENT UPLOAD", description: "SEAMLESSLY UPLOAD DOCUMENTS", link:'/home/upload-documents'  },
    // { id: 7, title: "STEP 7 - CODE OF CONDUCT", description: "REVIEW AND E-SIGN YOUR CODE OF CONDUCT WITH AADHAR NUMBER" },
    { id: 7, title: "STEP 7 - REFERENCE DETAILS", description: "PROVIDE REFERENCE DETAILS", link:'/home/reference-details'  },
    { id: 8, title: "STEP 8 - FINANCIAL INSTITUTION DETAILS", description: "PROVIDE FINANCIAL INSTITUTION DETAILS", link:'/home/financial-institution-details'  },
    { id: 9, title: "STEP 9 - CIBIL BUREAU", description: "CHECK YOUR CREDIT SCORE", link:'/home/bureau-details'  },
  ];
  userData: any;
  userDetails: any;
  activeRoutes: any;
  activeRoutesList: any=1;
  activeId: number =1;
  categoryList: any[]=[];
  flagTrue: boolean;
  resourceState: any ='Pending';
  time: number = 0;
  display: any;
  interval: any;
  userInfo: any;
  applicationForm: any;
  completeCaseData: any;
  agreementPdf: any;
  annualCategoryList: any[]=[];
  selectedYear: any = new Date().getFullYear();
  annualResourceState: any ='Pending';

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService,private storageService:StorageService , private spinner: NgxSpinnerService,private _auth:AuthService, public dialog: MatDialog) { }


  ngOnInit(): void {
    this.time = 0;

    this.userInfo = this.storageService.secureStorage.getItem("userinfo")

    this.startTimer();

    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    console.log("==////=",this.userData.partner_type)

    if (this.hour < 12) {
      this.greeTingMessage = "GOOD MORNING";
    } else if (this.hour < 17) {
      this.greeTingMessage = "GOOD AFTERNOON";
    } else {
      this.greeTingMessage = "GOOD EVENING";
    }
    this.getApplicationDetails();
    this.changeResource('Pending','auto');
    this.changeAnnualResource('Pending','auto');
   
   
  }


  getCaseDetails(){
    this._apiService.getCaseDetails({phoneNo:this.userData.phone_no, token:this.userInfo.token,
      version:this.userInfo.version}).subscribe((res)=>{
      if(!res.error){
        this.userDetails = res.data[0]; 
        this.getApplicationDetails()
    }

   },(err: HttpErrorResponse) =>
    {
    if (err.status === 400) {
      Swal.fire({
        position: 'center',
        icon: 'success',
        title: err.error.message,
        showConfirmButton: false,
        timer: 1500
      })
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
        showConfirmButton: false,
        timer: 1500
      })
    }
  })
  }


  getApplicationDetails() {
    this.spinner.show();
    let data = {
      // caseId: 20,
      // phoneNo: this.userData.phone_no,
      token:this.userInfo.token
      // version:this.userInfo.version,
    }
    this._apiService.getApplication(data).subscribe((res) => {
    
      if (res.error == true) {
        this.applicationstepIndicator = 1
        this.flagTrue = true;
        this.spinner.hide();
      } else {
        this.spinner.hide();
        this.applicationData = res;
        console.log("%%%%%",this.applicationData.data[0].partner_type)

        if(this.applicationData.data[0].new_case_id && this.applicationData.data[0].stage_count == 9){
          this.getcaseApplicationandQueryDetails();
          this.getApplicationCompletionData('unclick');
          // this.getPdfAgreement();
        }
        this.getcaseQueryDetails(this.type);
        this.changeResource('Pending','auto');
        this.changeAnnualResource('Pending','auto');
        this.applicationStateCount = res.data[0].stage_count === null ? null :res.data[0].stage_count ;
        this.applicationstepIndicator = this.applicationStateCount;
        if(this.applicationStateCount !=9 && this.applicationStateCount !=null){
          this.activeRoutes = this.stepsArray.find((ele:any) => ele.id == this.applicationStateCount+1)
        } else if(this.applicationStateCount ===null) {
          this.activeRoutes = this.stepsArray.find((ele:any) => ele.id == 1);
        } else{
          this.activeRoutes = this.stepsArray.find((ele:any) => ele.id == this.applicationStateCount)
        }
       
        this.applicationStateCountPercent = (this.applicationStateCount / 9) * 100;
        this.applicationStateCountPercent = parseFloat(this.applicationStateCountPercent).toFixed(0);


        this.activeRoutesList = this.stepsArray.find((ele:any) => ele.id == this.applicationStateCount);
        this.activeId = this.activeRoutesList.id
        // console.log("this.activeRoutesListthis.activeRoutesList",this.applicationData);
      
        
      }

      // this.getcaseApplicationandQueryDetails();
      // this.getcaseQueryDetails(this.type);

    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }

  // onPressPrevious = () => {

  //   if (this.activeStepInView > 1) {
  //     this.activeStepInView--
  //     this.activeRoutesList = this.stepsArray.find((ele:any) => ele.id == this.applicationStateCount);
  //     // this.activeStepTextView = this.stepsArray[this.activeStepInView - 1]
  //   }
  // }

  // onPressNext = () => {
  //   if (this.activeStepInView < 9) {
  //     this.activeStepInView++
  //     this.activeStepTextView = this.stepsArray[this.activeStepInView - 1]
  //   }
  // }

  getApplicationCompletionData(data:any){
    this.spinner.show();
    this._apiService.getApplicationCompletionData({applicationcaseId:this.applicationData.data[0].new_case_id}).subscribe((res:any)=>{
      if(!res.error){
        this.spinner.hide();
  
        if(data=='Click'){
        this.applicationForm = res.path;
       
        
        window.open(res.path,'_blank');
      }else{
          this.completeCaseData = res.caseData[0];
       
        }
    
      }else{
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }

  getPdfAgreement(){
    this.spinner.show();
    this._apiService.getAgreementPdf({applicationcaseId:this.applicationData.data[0].new_case_id}).subscribe((res:any)=>{
      if(!res.error){
        this.spinner.hide();
  
        this.agreementPdf = res.path;
        window.open( this.agreementPdf,'_blank');

      }else{
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }


  startTimer() {
    clearInterval(this.interval);
    // console.log("=====>");
    this.interval = setInterval(() => {
      if (this.time === 0) {
        this.time++;
      } else {
        this.time++;
      }
      this.display = this.transform(this.time)
    }, 1000);
  }


  transform(value: number): string {
    const minutes: number = Math.floor(value / 60);
    return minutes + ':' + (value - minutes * 60);
  }





  onPressPrevious = () => {
     if (this.activeId > 1) {
      this.activeId--
      this.activeRoutesList = this.stepsArray[this.activeId-1]
    }
  }

  onPressNext = () => {
    if (this.activeId < 9) {
      this.activeId ++
      this.activeRoutesList = this.stepsArray[this.activeId-1]

    }
  }


  changeCode(value:any){
    this.activeRoutesList = this.stepsArray[value-1];
  }


  changeResource(event:any,state:any){

    if(state =='auto'){
      this.resourceState = event ;
    }else{
      this.resourceState = event.target.value ;
    }
    this.spinner.show();
    const data= new FormData();
   
    // data.append('version', this.storageService.secureStorage.getItem('version'));
    // data.append('role', this.userData.partner_type);
    // data.append('mobile', this.userData.phone_no);
    data.append('token', this.userInfo.token);

    

   this._apiService.getCategoryList(data).subscribe((response:any)=>{
     if(!response.error){
       this.categoryList=[];
       let defaultLanguage="English";
      if(response.language!=null){
        defaultLanguage=response.language
      }

      response.data.map((content:any)=>{
        if(content.language==defaultLanguage){
          this.categoryList.push(content)
        }
      })


      //  this.categoryList = response.data;
       this.spinner.hide();
       if(this.resourceState != 'Pending'){
         this.categoryList = this.categoryList.filter((ele:any)=> ele.status == this.resourceState);
       }else if(this.resourceState == 'Pending'){
        this.categoryList = this.categoryList.filter((ele:any)=> ele.status == null);
       }
     
      //  console.log(this.categoryList);
       
     }
   },( (err: HttpErrorResponse) => {
    this.spinner.hide();
     if (err.status === 400) {
       Swal.fire({
         position: 'center',
         icon: 'success',
         title: err.error.message,
         showConfirmButton: false,
         timer: 1500
       })
     } else {
       Swal.fire({
         position: 'center',
         icon: 'error',
         title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
         showConfirmButton: false,
         timer: 1500
       })
     }

   }));
  }

  changeAnnualResource(event: any, state: any) {

    if (state == 'auto') {
      this.annualResourceState = event;
    } else {
      this.annualResourceState = event.target.value;
    }
    this.spinner.show();

    const data = new FormData();
    
    data.append('version', this.storageService.secureStorage.getItem('version'));
    data.append('role', this.userData.partner_type);
    data.append('mobile', this.userData.phone_no);
    data.append('token', this.userInfo.token);
    data.append('version', this.userInfo.version);
    data.append('year', this.selectedYear);

    this._apiService.getTrainingCategoryList(data).subscribe((response: any) => {
      if (!response.error) {
        this.annualCategoryList = [];
        let defaultLanguage = "English";
        if (response.language != null) {
          defaultLanguage = response.language
        }

        response.data.map((content: any) => {
          if (content.language == defaultLanguage) {
            this.annualCategoryList.push(content)
          }
        });

        this.spinner.hide();
        if (this.annualResourceState != 'Pending') {
          this.annualCategoryList = this.annualCategoryList.filter((ele: any) => ele.status == this.annualResourceState);
        } else if (this.annualResourceState == 'Pending') {
          this.annualCategoryList = this.annualCategoryList.filter((ele: any) => ele.status == null);
        }
      }
    }, ((err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    }));

  }



  getType(type:any)
  {
    this.getcaseQueryDetails(type)
  }

  getcaseApplicationandQueryDetails() {
    // console.log(this.applicationData);
    this.spinner.show();

    let data = {
      ApplicationID: this.applicationData.data[0].new_case_id,
      // token:this.storageService.secureStorage.getItem('token'),
      // version:this.storageService.secureStorage.getItem('version')
      // token:this.userInfo.token,
      // version:this.userInfo.version,
      


      // "D2022082400002",
    }
    this._apiService.getcaseApplicationandQueryDetails(data).subscribe((res) => {
      this.spinner.hide();
      if (res.error == true) {
        this.applicationstepIndicator = 1 ;
        this.ExternalQueryOpen = 0;
        this.ExternalQueryInProgress = 0;
        this.ExternalQueryResolved = 0;
      } else {
        this.ExternalQueryOpen = res.applicationData[0].ExternalQueryOpen ? res.applicationData[0].ExternalQueryOpen :0;
        this.ExternalQueryInProgress = res.applicationData[0].ExternalQueryInProgress ? res.applicationData[0].ExternalQueryInProgress : 0 ;
        this.ExternalQueryResolved = res.applicationData[0].ExternalQueryResolved ? res.applicationData[0].ExternalQueryResolved : 0;
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }



  getcaseQueryDetails(types:any) {
    // console.log(this.applicationData);
    this.spinner.show();
    this.type=types
    let data = {
      ApplicationID: this.applicationData.data[0].new_case_id,
      QueryType: "External",
      QueryStatus:  this.type,
    }
    this._apiService.getcaseQueryDetails(data).subscribe((res) => {
      this.spinner.hide();
      if (res.error == true) {
        this.applicationstepIndicator = 1
      } else {
        this.queryData = res.queryData;
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }

  openApplication(){


    this.router.navigate(['/home/userApplication'])


    return


    const dialogRef = this.dialog.open(CompleteApplicationComponent, {
      disableClose: true,
      panelClass: 'fullscreen',
      width: '100%',
    // width:'100',
      // width: '500px',
      data: { title: 'title', messeage: 'messeage' }
    });

    

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
      


      }
    });
  }


  agreement(){
    // Swal.fire({
    //   position: 'center',
    //   icon: 'warning',
    //   title: "Agreement not generated.",
    //   showConfirmButton: false,
    //   timer: 1500
    // })
  }



  downloadDocuments(type:any){
    this.spinner.show();
    let documentData

    if(type =='Agreement'){
      documentData={
        DID :this.completeCaseData.agreement_dms_id,
      }
    }else{
      documentData={
        DID :this.completeCaseData.application_dms_id,
      }
    }

    this._apiService.downloadDocuments(documentData).pipe(
      take(1)
  ).subscribe((res:any)=>{
      if(!res.error){
        var contentDisposition = res.headers.get('content-disposition');
       var filename = contentDisposition.split(';')[1].split('filename')[1].split('=')[1].trim().replaceAll('"', '');

      let downloadLink = document.createElement('a');
      downloadLink.href = window.URL.createObjectURL(res.body);
      downloadLink.setAttribute('download',filename);
      document.body.appendChild(downloadLink);
      downloadLink.click();
      downloadLink.remove();
      this.spinner.hide();
    
      }else{
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      }if((err.status === 422)){
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: "Your RCU is under review, Kindly contact OPS team.",
          // title: type+" not available, please try again.",
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }



}