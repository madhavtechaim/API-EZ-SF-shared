import { StorageService } from 'src/app/services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import { OtpComponent } from 'src/app/modals/otp/otp.component';
import { WaitingAadharComponent } from 'src/app/modals/waiting-aadhar/waiting-aadhar.component';
import { NgxSpinnerService } from 'ngx-spinner';
import * as moment from 'moment';
import { AuthService } from 'src/app/services/auth.service';
import { ConsentComponent } from 'src/app/modals/consent/consent.component';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-partner-details',
  templateUrl: './partner-details.component.html',
  styleUrls: ['./partner-details.component.scss']
})
export class PartnerDetailsComponent implements OnInit {
  form: FormGroup;
  formSumitAttempt: boolean;
  isWebRequest: boolean = false;
  highestQualification: any;
  professions: any;
  userData: any;
  userDetails: any;
  adharData: any;
  setIndex: any;
  directorsData: any;
  applicantDirectors: any = [];
  directorFlag: boolean;
  flagArray: any = [];
  patchValue: any;
  aadharNo: any;
  caseId: any;
  dirId: any;
  salutationList: any[] = [{ title: 'Mr.', value: 'Mr.' }, { title: 'Mrs.', value: 'Mrs.' }, { title: 'Dr.', value: 'Dr.' }];
  highestQualificationList: any[] = [];
  experienceList: any[] = [{ title: 'Less than 2 years', value: 'Less than 2 years' }, { title: 'Greater than 2 years', value: 'Greater than 2 years' }];


  today = moment().format('YYYY-MM-DD');
  userInfo: any;
  filteredSalutation: any[];
  highestQuali: any;
  filteredExperience: any[];
  indv: boolean = false;
  aadharFlag: any;
  directorCibilConsentFlag: any;
  removeDetails: boolean = true;
  count: number;
  otherPhoto: any;
  isAuthorised: boolean = true;

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, public dialog: MatDialog, private storageService: StorageService, private route: ActivatedRoute, private spinner: NgxSpinnerService, private _auth: AuthService) { }

  ngOnInit(): void {
    this.flagArray = []
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    this.aadharFlag = this.storageService.secureStorage.getItem('AadharFlag');
    this.directorCibilConsentFlag = this.storageService.secureStorage.getItem('DirectorCibilConsentFlag');

    console.log("this.directorCibilConsentFlag===>==>", this.directorCibilConsentFlag);
      

    console.log("this.aadharFlagthis.aadharFlag", this.aadharFlag);


    this.adharData = this.storageService.secureStorage.getItem('Aadhar');
    this.userData = this.storageService.secureStorage.getItem('UserDetails');

    this.aadharNo = this.storageService.secureStorage.getItem('aadharNo');

    this.caseId = this.storageService.secureStorage.getItem('CaseId');
    this.dirId = this.storageService.secureStorage.getItem('DirAdhar');


    this.route.params.subscribe(params => {
      let isAadharVerification = params['isDirectorAadharVerification'];
      if (isAadharVerification) {
        this.route.queryParams.subscribe(params => {
          let requestId = params['requestId'];
          this.openAadharVerificationModal(requestId, this.caseId, this.aadharNo, this.dirId);
        })
      }
    }
    )
    this.getCaseDetails();

    this.getAllQualifications();
    // this.getAllProfession();
    this.form = this._formBuilder.group({
      salutation: ['', [Validators.required, this.requireMatch.bind(this)]],
      panfullname: ['', [Validators.required]],
      fathersName: ['', [Validators.required]],
      // mothersName: [''],
      dateOfBirth: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      heighestQualification: [null, [Validators.required, this.requireMatch1.bind(this)]],
      // profession: ['', [Validators.required]],
      dateOfIncorporation: [''],
      applicantExperience: [null, [Validators.required, this.requireMatch2.bind(this)]],
      Directors: this._formBuilder.array([])
    }
    );
    // ,this.requireMatch1.bind(this)

    // this.addDirectorRow();
    this.form.controls['salutation'].valueChanges.subscribe((res: any) => {
      this.filteredSalutation = this.salutationList.filter((x: any) => x.title.toLowerCase().includes(res.toLowerCase()));
      if (this.filteredSalutation.length == 0) {
        this.filteredSalutation = [...this.salutationList]
      }
    })


    // if(this.aadharFlag){
    //   this.form.removeControl('')
    // }

    this.form.controls['applicantExperience'].valueChanges.subscribe((res: any) => {

      console.log("resresres vfdvdvf", res);

      if (!res) {
        this.filteredExperience = [...this.experienceList]
      } else {
        this.filteredExperience = this.experienceList.filter((x: any) => x.value.toLowerCase().includes(res.toLowerCase()));
        if (this.filteredExperience.length == 0) {
          this.filteredExperience = [...this.experienceList]
        }
      }

    })




    this.form.controls['heighestQualification'].valueChanges.subscribe((res: any) => {
      console.log(res);

      if (this.highestQuali && this.highestQuali.length > 0) {
        this.highestQualificationList = this.highestQuali.filter((x: any) => x.title.toLowerCase().includes(res.toLowerCase()));
        console.log(this.highestQualificationList);
        if (this.highestQualificationList.length == 0) {
          this.highestQualificationList = [...this.highestQuali]
        }
      }
    })

  }



  addItem() {
    this.itemsArray.push(this.createDirectorsRow());
    this.itemsArray.updateValueAndValidity();
  }

  remoteItem(index: number) {
    this.itemsArray.removeAt(index);
    this.itemsArray.updateValueAndValidity()
  }

  get itemsArray(): any {
    return <FormArray>this.form.get('Directors') as FormArray;
  }

  requireMatch(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.salutationList && this.salutationList.find((ele: any) => ele.value == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }

  requireMatch1(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.highestQuali && this.highestQuali.find((ele: any) => ele.title == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }

  requireMatch2(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.experienceList && this.experienceList.find((ele: any) => ele.value == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }

  removeControlAtIndex(group: any, index: number, tID: any) {
    if (tID) {
      this._apiService.deleteDirector({ directorId: tID }).subscribe((res: any) => {
        if (!res.error) {
          this.itemsArray.controls.splice(index, 1)
          this.flagArray.splice(index, 1)
          this.directorsData.splice(index, 1)
        } else {

        }
      })
    } else {
      this.itemsArray.controls.splice(index, 1)
    }
  }

  addDirectorRow(data: any) {
    console.log("+++++", data);
    if (data != 'Auto') {
      this.saveAbove(data);
    } else {
      this.addItem()
      if (data == 'mannual') {
        this.flagArray.push({
          panFlag: false,
          adharFlag: false,
          verifyMobileFlag: false,
          verifyEmailFlag: false,
          verifyCibilOtpFlag: false,
          authorisedFlag: false
        })
      }
    }
  }

  createDirectorsRow(): FormGroup {
    return this._formBuilder.group({
      // directorPan: ['', [Validators.required, Validators.pattern('[A-Z]{5}[0-9]{4}[A-Z]{1}')]],
      directorPan: [''],
      directorCkyc: [''],
      directorAadhar: [''],
      directorFullname: ['', [Validators.required]],
      directorFatherName: [''],
      directorMotherName: ['ggggg',],
      directorDob: ['', [Validators.required]],
      directorGender: ['', [Validators.required]],
      directorQualification: [null, [Validators.required]],
      directorProfession: [''],
      directorSalutation: ['', [Validators.required]],
      authorisedFlag: [''],
      directorEmail: [''],
      directorMobile: [''],
      verifyCibilOtpFlag: [false],
      tid: [''],
      otherFile: ['']
    });
  }

  changeAuthorise(event: any, index: any, did: any) {
    // console.log(event.checked,index);
    console.log("++++", did);
    if (event.checked) {
      this.flagArray[index].authorisedFlag = true
      this.itemsArray.controls[index].controls.authorisedFlag.patchValue(true)
      this.itemsArray.controls[index].controls.directorMobile.setValidators([Validators.required, Validators.pattern("[1-9]{1}[0-9]{9}")])
      this.itemsArray.controls[index].controls.directorPan.setValidators([Validators.required, Validators.pattern('[A-Z]{5}[0-9]{4}[A-Z]{1}')])
      this.itemsArray.controls[index].controls.directorEmail.setValidators([Validators.required, Validators.email])
    }
    else {
      if (did != null) {
        this.getUncheckedAuthorized(did, 0)
      }
      this.flagArray[index].authorisedFlag = false
      this.itemsArray.controls[index].controls.authorisedFlag.patchValue(false)
      this.itemsArray.controls[index].controls.directorMobile.setValidators(null)
      this.itemsArray.controls[index].controls.directorPan.setValidators(null)
      this.itemsArray.controls[index].controls.directorEmail.setValidators(null)
    }
    this.itemsArray.controls[index].controls.authorisedFlag.updateValueAndValidity()
    this.itemsArray.controls[index].controls.directorMobile.updateValueAndValidity()
    this.itemsArray.controls[index].controls.directorPan.updateValueAndValidity()
    this.itemsArray.controls[index].controls.directorEmail.updateValueAndValidity()
    this.itemsArray.updateValueAndValidity()
    this.form.updateValueAndValidity()
  }

  getUncheckedAuthorized(did: any, value: any) {
    this.spinner.show();
    this._apiService.uncheckAuthorisedDirector({ caseId: this.userDetails.case_id, directorId: did, token: this.userInfo.token, value: value }).subscribe((response: any) => {
      if (!response.error) {
        this.spinner.hide();

        this.ngOnInit();
        // this.f['Directors']['controls'].forEach((element: any, i: any) => {
        //   if (index == i) {
        //     element.controls.authorisedFlag.patchValue(event.checked);
        //     // this.form.controls['directorPan'].addValidators([Validators.required, Validators.pattern('[A-Z]{5}[0-9]{4}[A-Z]{1}')])
        //     this.f['Directors']['controls'][i].controls['directorPan'].addValidators([Validators.required, Validators.pattern('[A-Z]{5}[0-9]{4}[A-Z]{1}')]);
        //     this.f['Directors']['controls'][i].controls['directorFullname'].reset();
        //   } else {
        //     element.controls.authorisedFlag.patchValue(false);
        //     this.f['Directors']['controls'][i].controls['directorPan'].removeValidators();
        //   }
        // });


      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    },
      (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
        this.isWebRequest = false;
      })
  }

  getCaseDetails() {
    this.spinner.show();
    this._apiService.getCaseDetails({ token: this.userInfo.token }).subscribe((res) => {
      if (!res.error) {
        this.userDetails = res.data[0];

        this.directorsData = res.directorData;
        // this.directorsData = res.directorData.reverse();


        if (this.userDetails.partner_type == 'DSA') {
          this.form.addControl('applicantExperience', new FormControl('', [Validators.required]));
          this.form.controls['applicantExperience'].updateValueAndValidity();
        } else {
          this.form.removeControl('applicantExperience');
          this.form.updateValueAndValidity();
        }

        if (this.userDetails.constitution_type == 'Partnership' || this.userDetails.constitution_type == 'PVT'
          || this.userDetails.constitution_type == 'HUF' || this.userDetails.constitution_type == 'Public') {
          this.removeDetails = false;
          this.form.removeControl('salutation');
          this.form.removeControl('fathersName');
          this.form.removeControl('dateOfBirth');
          this.form.removeControl('gender');
          this.form.removeControl('heighestQualification');
          this.form.updateValueAndValidity();
        } else if (this.userDetails.constitution_type == 'Proprietor') {
          this.removeDetails = false;
          this.form.removeControl('salutation');
          this.form.removeControl('fathersName');
          this.form.removeControl('gender');
          this.form.removeControl('heighestQualification');
          this.form.updateValueAndValidity();
        } else {
          this.removeDetails = true;
        }

        if (this.userDetails.constitution_type == 'Individual') {

          this.indv = false;
          this.form.removeControl('dateOfIncorporation');
          this.form.addControl('dateOfIncorporation', new FormControl(''));
          this.form.controls['dateOfIncorporation'].updateValueAndValidity();
        } else {
          this.indv = true;
          this.form.addControl('dateOfIncorporation', new FormControl(''));
          this.form.updateValueAndValidity();
        }


        if (this.userDetails.constitution_type != 'Individual') {
          this.directorFlag = true
        } else {
          this.directorFlag = false
        }

        //  this.highestQualificationList = [...this.highestQualification];

        //  console.log("this.highestQualificationListthis.highestQualificationListthis.highestQualificationList",this.highestQualificationList);


        this.form.patchValue({
          panfullname: this.userDetails.panfullname, fathersName: this.userDetails.father_name, dateOfBirth: this.userDetails.date_of_birth, gender: this.userDetails.gender,
          // mothersName:this.userDetails.mother_name,
          dateOfIncorporation: this.userDetails.date_of_incorporation,
          // heighestQualification: this.userDetails.qualification ?  parseInt(this.userDetails.qualification ):'',
          // heighestQualification:this.highestQualificationList.find((ele:any)=> ele.value == parseInt(this.userDetails.qualification )).length>0?this.highestQualificationList.find((ele:any)=> ele.value == parseInt(this.userDetails.qualification )):'',
          // profession:this.userDetails.profession ? parseInt(this.userDetails.profession):''
          applicantExperience: this.userDetails.applicant_experience
        })





        console.log(this.highestQualificationList);


        if (this.userDetails && this.highestQualificationList.length > 0 && this.removeDetails) {

          this.form.patchValue({
            heighestQualification: this.highestQualificationList.find(ele => ele.value == this.userDetails.qualification).title,
          })
        }


        if (this.userDetails.salution != null) {
          this.form.patchValue({
            salutation: this.userDetails.salution
          })
        } else {
          if (this.userDetails.gender == 'MALE') {
            this.form.patchValue({
              salutation: 'Mr.'
            })
          } else if (this.userDetails.gender == 'FEMALE') {
            this.form.patchValue({
              salutation: 'Mrs.'
            })
          }
        }

        // heighestQualification:parseInt(this.userDetails.qualification?this.userDetails.qualification:null),
        //   profession:parseInt(this.userDetails.profession ?this.userDetails.profession : null)
        this.setIndex = null;
        if (this.directorsData.length > 0) {
          this.flagArray = []
          this.directorsData.forEach((element: any, i: any) => {
            this.addDirectorRow('Auto');
            this.f['Directors']['controls'][i].patchValue(
              {
                directorPan: element.director_pan,
                directorCkyc: 51561616516,
                directorAadhar: element.director_aadhar,
                directorFullname: element.director_full_name,
                directorFatherName: null,
                // directorFatherName: element.director_father_name ,
                // directorMotherName : element.director_mother_name,
                directorDob: element.director_dob && element.director_dob != "0000-00-00" ? element.director_dob : null,
                directorGender: element.director_gender,
                directorQualification: element.director_qualification ? element.director_qualification : null,
                directorProfession: null,
                directorSalutation: element.director_salutation,
                authorisedFlag: element.authorised_flag,
                directorEmail: element.director_email,
                directorMobile: element.director_mobile,
                verifyCibilOtpFlag: element.cibil_consent_check == 1 ? true : false,
                tid: element.tid,
                otherFile: element.other_adhar_file_name ? (environment.imgUrl + element.other_adhar_file_path + element.other_adhar_file_name) : null,
              })
            this.f['Directors']['controls'][i].updateValueAndValidity()
            this.flagArray[i] = { ...this.flagArray[i], authorisedFlag: false }
            if (element.authorised_flag) {
              this.itemsArray['controls'][i].controls.directorMobile.setValidators([Validators.required, Validators.pattern("[1-9]{1}[0-9]{9}")])
              this.itemsArray['controls'][i].controls.directorPan.setValidators([Validators.required, Validators.pattern('[A-Z]{5}[0-9]{4}[A-Z]{1}')])
              this.itemsArray['controls'][i].controls.directorEmail.setValidators([Validators.required, Validators.email])
              this.itemsArray['controls'][i].controls.otherFile.setValidators([Validators.required])
              this.itemsArray['controls'][i].controls.directorMobile.updateValueAndValidity()
              this.itemsArray['controls'][i].controls.directorPan.updateValueAndValidity()
              this.itemsArray['controls'][i].controls.directorEmail.updateValueAndValidity()
              this.itemsArray['controls'][i].controls.otherFile.updateValueAndValidity()
              this.itemsArray.updateValueAndValidity()
              this.form.updateValueAndValidity()
              this.flagArray[i] = { ...this.flagArray[i], authorisedFlag: true }
            }
            // console.log('environment.imgUrl + element.other_adhar_file_path + element.other_adhar_file_name',environment.imgUrl + element.other_adhar_file_path + element.other_adhar_file_name)
            console.log('itemsArray', this.itemsArray)

            // if (element.authorised_flag) {
            //   this.setIndex = i
            //   this.f['Directors']['controls'][i].controls['directorEmail'].addValidators([Validators.required, Validators.email]);
            //   this.form.updateValueAndValidity();
            // }

            if (element.director_gender) {
              if (element.director_salutation != null) {
                this.f['Directors']['controls'][i].patchValue({
                  directorSalutation: element.director_salutation,
                })
              } else {
                if (element.director_gender == 'MALE') {
                  this.f['Directors']['controls'][i].patchValue({
                    directorSalutation: 'Mr.',
                  })
                } else if (element.director_gender == 'FEMALE') {
                  this.f['Directors']['controls'][i].patchValue({
                    directorSalutation: 'Mrs.'
                  })

                }
              }
            }

            this.flagArray[i] = {
              ...this.flagArray[i],
              panFlag: element.director_pan_verify_flag == 1 ? true : false,
              adharFlag: element.director_adhaar_verify_flag == 1 ? true : false,
              verifyMobileFlag: element.isMobileVerified == 1 ? true : false,
              verifyEmailFlag: element.isEmailVerified == 1 ? true : false,
              verifyCibilOtpFlag: element.is_cibil_otp_verified == 1 ? true : false,
              authorisedFlag: element.authorised_flag == 1 ? true : false,
            }

            // this.flagArray.push({
            //   panFlag: element.director_pan_verify_flag == 1 ? true : false,
            //   adharFlag: element.director_adhaar_verify_flag == 1 ? true : false,
            //   verifyMobileFlag: element.isMobileVerified == 1 ? true : false,
            //   verifyEmailFlag: element.isEmailVerified == 1 ? true : false,
            //   verifyCibilOtpFlag: element.is_cibil_otp_verified == 1 ? true : false,
            //   authorisedFlag: element.authorised_flag == 1 ? true : false,
            // })
          })
          this.spinner.hide();
        } else {
          this.flagArray = [];
          this.flagArray.push({
            panFlag: false,
            adharFlag: false,
            verifyMobileFlag: false,
            verifyEmailFlag: false,
            verifyCibilOtpFlag: false,
            authorisedFlag: false
          })
          this.setIndex = null
        }

      }
      this.form.controls['Directors'].updateValueAndValidity()
      this.form.updateValueAndValidity()
      console.log('this.form', this.form)

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })
  }

  get f(): any {
    return this.form.controls;
  }

  get g() {
    return (<FormArray>this.form.get('Directors')).controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }

  back(): void {
    this.router.navigate(['/home/kyc-details'])
  }

  next() {

    this.formSumitAttempt = true;
    console.log(this.form)
    if (this.form.invalid) {
      return;
    }
    let checkValid = false;
    this.g.forEach(ele => {
      if (ele.status == 'INVALID') {
        checkValid = true;
      }
    })

    if (this.form.valid && !checkValid) {
      this.isWebRequest = true;
      this.applicantDirectors = [];
      this.itemsArray.updateValueAndValidity()
      this.form.updateValueAndValidity()
      this.f['Directors']['controls'].forEach((element: any, i: any) => {
        let elementData = { ...element }
        if (this.flagArray[i].authorisedFlag) {
          elementData.value.authorisedFlag = true
        } else {
          elementData.value.authorisedFlag = false
        }
        this.applicantDirectors.push(elementData.value);
      });


      let allCibilChecked=true;
      this.applicantDirectors.forEach((element: any, i: any) => {
      if(element.authorisedFlag==true){
        if(element.verifyCibilOtpFlag==false){
          allCibilChecked=false
        }
      }
      });

      if(this.userDetails.constitution_type != 'Individual' && this.userDetails.constitution_type != 'Proprietor'){
        this.isAuthorised= false;
        if(this.applicantDirectors.length >0){
          this.isAuthorised = this.applicantDirectors.some((element: any, i: any) => {
            return element.authorisedFlag==true;
          });
        }
      } else {
        this.isAuthorised = true;
      }


      if(!this.isAuthorised){
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Please check atleast one authorised person.',
          showConfirmButton: false,
          timer: 1500
        })
      } else if(!allCibilChecked){
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Please check all authorised directors CIBIL cencent.',
          showConfirmButton: false,
          timer: 1500
        })
      }else{
      this.spinner.show();

        let data = {
          appId: this.userDetails.case_id,
          salutation: this.form.value.salutation ? this.form.value.salutation : null,
          panfullname: this.form.value.panfullname,
          fathersName: this.form.value.fathersName ? this.form.value.fathersName : null,
          // motherName:this.form.value.mothersName,
          DOB: this.form.value.dateOfBirth ? this.form.value.dateOfBirth : null,
          gender: this.form.value.gender ? this.form.value.gender : null,
          // qualification:this.form.value.heighestQualification,
          qualification: this.form.value.heighestQualification ? this.highestQualificationList.find(ele => ele.title == this.form.value.heighestQualification).value : null,
          profession: null,
          // profession:this.form.value.profession,
          dateofIncorporation: this.form.value.dateOfIncorporation,
          applicantExperience: this.form.value.applicantExperience,
          ApplicantDirectors: this.applicantDirectors,
          stageCount: 3,
          isAuthorisedDirectorAdded: false,
          token: this.userInfo.token
        }
  
        this._apiService.addCaseDetail(data).subscribe((response: any) => {
          if (!response.error) {
            this.spinner.hide();
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: response.message,
              showConfirmButton: false,
              timer: 1500
            })
  
            this.router.navigate(['/home/address-details']);
          } else {
            this.spinner.hide();
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: response.message,
              showConfirmButton: false,
              timer: 1500
            })

          }
        },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })
  
            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
            this.isWebRequest = false;

          })
      }


      
    }
  }

  getDirector() {
    let data = {
      caseId: 1,
      directorId: 3
    }
    this._apiService.getCaseDirector(data).subscribe((res: any) => {
      if (!res.err) {

      } else {

      }
    })
  }

  getAllQualifications() {
    let data = {
      type: "highest_qualification"
    }
    this.spinner.show();
    this._apiService.getMasters(data).subscribe((res) => {
      this.highestQuali = [];
      this.highestQualificationList = [];
      this.highestQualification = res;

      this.highestQualification.forEach((element: any) => {
        this.highestQuali.push({ title: element.highest_qualification, value: element.hid })
        // this.highestQualificationList.push({title:element.highest_qualification,value:element.hid})
      });
      this.highestQualificationList = [...this.highestQuali]
      this.spinner.hide();
      if (this.userDetails && this.highestQualificationList.length > 0) {


        console.log(this.userDetails, this.form.value.heighestQualification, this.highestQualificationList, this.highestQualificationList.find(ele => ele.value == this.userDetails.qualification), this.userDetails.qualification);


        this.form.patchValue({
          heighestQualification: this.highestQualificationList.find(ele => ele.value == this.userDetails.qualification) ? this.highestQualificationList.find(ele => ele.value == this.userDetails.qualification).title : '',
        })
      }

      // this.highestQualificationList = [...this.highestQuali];
      console.log("this.highestQualificationthis.highestQualification", this.highestQualificationList);
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }

  // getAllProfession() {
  //   let data = {
  //     type: "profession"
  //   }
  //   this.spinner.show();
  //   this._apiService.getMasters(data).subscribe((res) => {
  //     // console.log(">>>>>>>", res)
  //     this.spinner.hide();
  //     this.professions = res;
  //   }, (err: HttpErrorResponse) => {
  //     this.spinner.hide();
  //     if (err.status === 400) {
  //       Swal.fire({
  //         position: 'center',
  //         icon: 'success',
  //         title: err.error.message,
  //         showConfirmButton: false,
  //         timer: 1500
  //       })

  //     } else {
  //       Swal.fire({
  //         position: 'center',
  //         icon: 'error',
  //         title: 'Server error',
  //         showConfirmButton: false,
  //         timer: 1500
  //       })
  //     }
  //     this.isWebRequest = false;
  //   })
  // }


  onPressVerifyPanCard(index: any, did: any): void {
    this.itemsArray.updateValueAndValidity()
    this.form.updateValueAndValidity()

    if (this.f['Directors']['controls'][index].controls['directorPan'].status != 'INVALID') {

      this.spinner.show();

      this._apiService.directorPanVerify({ panNumber: this.f['Directors']['controls'][index].controls['directorPan'].value, caseId: this.userDetails.case_id, directorId: did ? did : null, token: this.userInfo.token }).subscribe((response: any) => {
        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.storageService.secureStorage.setItem('DirectorPan' + index, response.data.result)
          // this.flagArray[index].panFlag = true;
          this.flagArray[index] = { ...this.flagArray[index], panFlag: true };
          this.f['Directors']['controls'][index].controls['tid'].patchValue(response.directorId);
          this.f['Directors']['controls'][index].controls['directorFullname'].patchValue(response.directorId);
          // this.getDirectors(response.directorId, index);
          // this.getCaseDetails();
          this.ngOnInit();
        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }

      }, (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
      })
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: 'Please enter correct pan number first.',
        showConfirmButton: false,
        timer: 1500
      })
    }
  }



  openOTPDialog(title: string, message: string, index: any): void {

    this.spinner.show();
    this._apiService.directorAdhaarVerify({
      name: this.storageService.secureStorage.getItem('DirectorPan' + index).name,
    }).subscribe((response: any) => {
      if (!response.error) {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })

        this.storageService.secureStorage.setItem('DirAdhar' + index, response.data.result)
        let data = {
          name: this.f['Directors']['controls'][index].controls['directorFullname'].value,
          // adharNumber:this.form.value.adharCard,
          adharNumber: this.f['Directors']['controls'][index].value.directorAadhar,
          accessKey: response.data.result.accessKey,
          caseId: this.userDetails.case_id,
          // directorId:this.directorsData[index].tid
          directorId: this.f['Directors']['controls'][index].controls['tid'].value
        }

        const dialogRef = this.dialog.open(OtpComponent, {
          disableClose: true,
          width: '400px',
          data: { title: title, messeage: message, inputValue: data },
        });

        dialogRef.afterClosed().subscribe(result => {
          //success code here
          if (result) {
            // this.directorsData[index].director_adhaar_verify_flag =1;
            // this.flagArray[index].adharFlag = true;
            this.flagArray[index] = { ...this.flagArray[index], adharFlag: true };
            this.getDirectors(this.f['Directors']['controls'][index].controls['tid'].value, index)
            // this.getCaseDetails();
          }
        });
      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })




    // if (this.f['Directors']['controls'][index].controls['directorAadhar'].status != "") {
    //   this._apiService.directorAdhaarVerify({ name:this.storageService.secureStorage.getItem('DirectorPan'+index).name,
    //   adharNumber:this.f['Directors']['controls'][index].controls['directorAadhar'].value}).subscribe((response:any)=>{
    //     if(!response.error){
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'success',
    //         title: response.message,
    //         showConfirmButton: false,
    //         timer: 1500
    //       })

    //       this.storageService.secureStorage.setItem('DirAdhar'+index,response.data.result)
    //       let data ={
    //         name: this.f['Directors']['controls'][index].controls['directorFullname'].value,
    //         // adharNumber:this.form.value.adharCard,
    //         adharNumber:this.f['Directors']['controls'][index].value.directorAadhar            ,
    //         accessKey:response.data.result.accessKey,
    //         caseId:this.userDetails.case_id,
    //         // directorId:this.directorsData[index].tid
    //         directorId:this.f['Directors']['controls'][index].controls['tid'].value
    //       }

    //       const dialogRef = this.dialog.open(OtpComponent, {
    //         disableClose: true,
    //         width: '400px',
    //         data: { title: title, messeage: message,inputValue:data },
    //       });

    //       dialogRef.afterClosed().subscribe(result => {
    //         //success code here
    //         if(result){
    //           // this.directorsData[index].director_adhaar_verify_flag =1;
    //           this.flagArray[index].adharFlag = true ;
    //           this.getDirectors(this.f['Directors']['controls'][index].controls['tid'].value,index)
    //           // this.getCaseDetails();
    //         }
    //       });
    //     }else{
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'warning',
    //         title: response.message,
    //         showConfirmButton: false,
    //         timer: 1500
    //       })
    //     }

    //   },(err: HttpErrorResponse) => {
    //     if (err.status === 400) {
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'error',
    //         title: err.error.message,
    //         showConfirmButton: false,
    //         timer: 1500
    //       })
    //     } else {
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'error',
    //         title: 'Server error',
    //         showConfirmButton: false,
    //         timer: 1500
    //       })
    //     }
    // })

    // } else {
    //   Swal.fire({
    //     position: 'center',
    //     icon: 'error',
    //     title: 'Please enter pan number first.',
    //     showConfirmButton: false,
    //     timer: 1500
    //   })
    // }

  }


  getDirectors(data: any, index: any) {
    this.spinner.show();
    this._apiService.getCaseDirector({ directorId: data, caseId: this.userDetails.case_id }).subscribe((res) => {
      if (!res.error) {
        // this.directorsData = res.directorData.reverse();
        this.spinner.hide();
        // console.log("resres",res);
        this.patchValue = res.logData[0];

        this.f['Directors']['controls'][index].patchValue({
          directorPan: this.patchValue.director_pan,
          directorAadhar: this.patchValue.director_aadhar,
          directorFullname: this.patchValue.director_full_name,
          // directorFatherName: this.patchValue.director_father_name ,
          // directorMotherName :this.patchValue.director_mother_name,
          directorDob: this.patchValue.director_dob,
          directorGender: this.patchValue.director_gender,
          directorQualification: this.patchValue.director_qualification,
          directorProfession: this.patchValue.director_profession,
          directorSalutation: this.patchValue.director_salutation,
          authorisedFlag: this.patchValue.authorised_flag,
          tid: this.patchValue.tid,
        })



        if (this.patchValue.director_gender) {
          if (this.f['Directors']['controls'][index]['director_salutation'].value != null) {
            this.f['Directors']['controls'][index].patchValue({
              directorSalutation: this.f['Directors']['controls'][index]['director_salutation'].value,
            })
          } else {
            if (this.f['Directors']['controls'][index]['director_gender'].value == 'MALE') {
              this.f['Directors']['controls'][index].patchValue({
                directorSalutation: 'Mr.',
              })
            } else if (this.f['Directors']['controls'][index]['director_gender'].value == 'FEMALE') {
              this.f['Directors']['controls'][index].patchValue({
                directorSalutation: 'Mrs.'
              })

            }
          }
        }


        // return;

      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })
  }



  cancel() {
    this.router.navigate(['/home'])
  }




  // openOTPDialogWaiting(title: string, message: string, index: any): void {
  //   this.spinner.show();
  //   // if(this.f['Directors']['controls'][index].controls.directorAadhar.value ){
  //   this._apiService.verifyDirAdhar({ token: this.userInfo.token }).subscribe((response: any) => {
  //     if (!response.error) {
  //       this.spinner.hide();
  //       Swal.fire({
  //         position: 'center',
  //         icon: 'success',
  //         title: response.message,
  //         showConfirmButton: false,
  //         timer: 1500
  //       })
  //       let redirectUrl = response.data.result.link
  //       this.storageService.secureStorage.setItem('DirAdhar', this.f['Directors']['controls'][index].controls.tid.value)
  //       this.storageService.secureStorage.setItem('CaseId', this.userDetails.case_id);
  //       // this.storageService.secureStorage.setItem('aadharNo',  this.f['Directors']['controls'][index].controls.directorAadhar.value );
  //       window.location = redirectUrl;

  //     } else {
  //       this.spinner.hide();
  //       Swal.fire({
  //         position: 'center',
  //         icon: 'warning',
  //         title: response.message,
  //         showConfirmButton: false,
  //         timer: 1500
  //       })
  //     }

  //   },
  //     (err: HttpErrorResponse) => {
  //       this.spinner.hide();
  //       if (err.status === 400) {
  //         Swal.fire({
  //           position: 'center',
  //           icon: 'error',
  //           title: err.error.message,
  //           showConfirmButton: false,
  //           timer: 1500
  //         })

  //       } else {
  //         Swal.fire({
  //           position: 'center',
  //           icon: 'error',
  //           title: 'Server error',
  //           showConfirmButton: false,
  //           timer: 1500
  //         })
  //       }
  //     })
  //   // }





  // }


  openOTPDialogWaiting(title: string, message: string, index: any): void {

    if (!this.f['Directors']['controls'][index].controls.tid.value) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: "Please verify PAN first",
        showConfirmButton: false,
        timer: 1500
      })
      return;
    }


    this.spinner.show();
    // if(this.f['Directors']['controls'][index].controls.directorAadhar.value ){
    this._apiService.verifyDirAdharDigilocker({ token: this.userInfo.token, caseId: this.userDetails.case_id, directorId: this.f['Directors']['controls'][index].controls.tid.value }).subscribe((response: any) => {
      if (!response.error) {
        // this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
        let redirectUrl = response.link
        this.storageService.secureStorage.setItem('DirAdhar', this.f['Directors']['controls'][index].controls.tid.value)
        this.storageService.secureStorage.setItem('CaseId', this.userDetails.case_id);
        // this.storageService.secureStorage.setItem('aadharNo',  this.f['Directors']['controls'][index].controls.directorAadhar.value );
        // window.location = redirectUrl;

        window.open(redirectUrl, '_blank');
        this.count = 0
        const myTimer = setInterval((i: any) => {
          console.log("Geeeee");
          this.count = this.count + 1;
          console.log("this.countthis.count", this.count);

          this._apiService.verifyAdharFlagCheck({
            token: this.userInfo.token, caseId: this.userDetails.case_id, type: "director",
            directorId: this.f['Directors']['controls'][index].controls.tid.value
          }).subscribe((res: any) => {
            if (!res.error) {
              if (res.adhar_flag == 1) {
                clearInterval(myTimer);
                // Swal.fire({
                //   position: 'center',
                //   icon: 'warning',
                //   title: "Time out. Please Try again",
                //   showConfirmButton: false,
                //   timer: 1500
                // })
                this.flagArray[index].adharFlag = true;
                this.flagArray[index] = { ...this.flagArray[index], adharFlag: true };
                this.spinner.hide();
                this.ngOnInit();
              } else if (res.adhar_error_Flag == 1) {
                clearInterval(myTimer);
                this.spinner.hide();
                Swal.fire({
                  position: 'center',
                  icon: 'warning',
                  title: res.adhar_error,
                  showConfirmButton: false,
                  timer: 1500
                })
              }
            } else {

            }
          }, (err: HttpErrorResponse) => {

            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
          })

          if (this.count > 23) {
            clearInterval(myTimer);
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: "Time out. Please Try again",
              showConfirmButton: false,
              timer: 1500
            })
            this.spinner.hide();
          }
        }, 5000)






      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }

    },
      (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message ? err.error.message : 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
      })
    // }
  }



  openAadharVerificationModal(Id: any, caseId: any, aadharId: any, dirId: any) {

    const dialogRef = this.dialog.open(WaitingAadharComponent, {
      disableClose: true,
      width: '400px',
      data: { title: 'Aadhar Verification', messeage: 'Please wait ... We are verifying your identity', requestId: Id, caseId: caseId, aadharId: aadharId, dirId: dirId }

      // , caseId : this.userDetails.case_id
    });

    dialogRef.afterClosed().subscribe(result => {
      //success code here

      this.router.navigate(['/home/partner-details'])
      this.getCaseDetails();

    });

  }

  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
    console.log(this.form)
  }

  keyPressName(event: any) {
    const pattern = /^[a-zA-Z ]*$/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }



  changePanNo(event: any, index: any, did: any) {

    // this.directorsData.element.director_pan



    // console.log(event.target.value , index, did ,this.f['Directors']['controls'][index].controls['directorPan'].value);
    // if(event.target.value == this.directorsData[index].director_pan || !this.flagArray[index].panFlag){
    //   // console.log("No Call");
    // }else{
    //   if(this.f['Directors']['controls'][index].controls['directorPan'].status != 'INVALID'){
    //      this.changePANFlag(index,did);
    //    }
    //   // console.log("Call");
    // }

    console.log(this.f['Directors']['controls'][index].controls['directorPan'].status, event.target.value, this.flagArray[index].panFlag);

    // this.f['Directors']['controls'][index].controls['directorPan'].status == 'INVALID' &&

    if (event.target.value != this.f['Directors']['controls'][index].value['directorPan'] && this.flagArray[index].panFlag) {
      this.changePANFlag(index, did);
    }

  }


  changePANFlag(index: any, tid: any) {

    this.spinner.show();
    this._apiService.unverifyDirPAN({ caseId: this.userDetails.case_id, directorId: tid }).subscribe((res: any) => {
      if (!res.error) {
        this.spinner.hide();
        // this.getCaseDetails();
        // this.flagArray[index].panFlag = false;
        this.flagArray[index] = { ...this.flagArray[index], panFlag: false };
        this.getDirectors(tid, index);

        this.ngOnInit();
        // Swal.fire({
        //   position: 'center',
        //   icon: 'success',
        //   title: res.message,
        //   showConfirmButton: false,
        //   timer: 1500
        // })
        // this.getCaseDetails();
        // this.itrVerify = false;
        // this.panVerify = false;
      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })

  }

  navigateTo() {
    this.router.navigate(['/home'])
  }

  saveAbove(values: any) {


    this.formSumitAttempt = true;
    this.itemsArray.updateValueAndValidity()
    this.form.updateValueAndValidity()

    let checkValid = false;
    this.g.forEach(ele => {
      console.log("_____", ele);
      if (ele.status == 'INVALID') {
        checkValid = true;
      }
    })
    if (this.form.invalid) {
      return;
    }

    console.log('this.form', checkValid)

    if (this.form.valid) {
      this.spinner.show();

      this.isWebRequest = true;
      this.applicantDirectors = [];
      console.log('this.form', this.form)
      this.itemsArray.updateValueAndValidity()
      this.form.updateValueAndValidity()
      this.f['Directors']['controls'].forEach((element: any) => {
        this.applicantDirectors.push(element.value);
      });

      let data = {
        appId: this.userDetails.case_id,
        salutation: this.form.value.salutation,
        panfullname: this.form.value.panfullname,
        fathersName: this.form.value.fathersName,
        // motherName:this.form.value.mothersName,
        DOB: this.form.value.dateOfBirth,
        gender: this.form.value.gender,
        // qualification:this.form.value.heighestQualification,
        qualification: this.highestQualificationList[0].value,
        profession: null,
        applicantExperience: this.form.value.applicantExperience,
        dateofIncorporation: this.form.value.dateOfIncorporation,
        ApplicantDirectors: this.applicantDirectors,
        stageCount: 3,
        isAuthorisedDirectorAdded: true,
        token: this.userInfo.token,
        version: this.userInfo.version,
      }

      // console.log(data);


      this._apiService.addCaseDetail(data).subscribe((response: any) => {
        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          let items = (<FormArray>this.form.get('Directors')).controls;


          items.push(this.createDirectorsRow())
          if (values == 'mannual') {
            this.flagArray.push({
              panFlag: false,
              adharFlag: false,
              verifyMobileFlag: false,
              verifyEmailFlag: false,
              verifyCibilOtpFlag: false,
              authorisedFlag: false
            })
          }
          this.flagArray[items.length - 1].panFlag = false;
          this.flagArray[items.length - 1].adharFlag = false

          // this.router.navigate(['/home/address-details']);
        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        })


      // this.router.navigate(['/home/address-details'])
    }
  }

  openOTPDialogBox(i: number, title: string, message: string, val: any, directorId: any): void {
    let value = ''
    this.spinner.show();

    if (title == 'Director Email Verification') {
      let data = {
        caseId: this.userDetails.case_id,
        directorId: directorId,
        mobileNo: '',
        emailId: val.directorEmail.value,
        type: "verifyDirectorEmailOTP",
        token: this.userInfo.token
      }

      this._apiService.sendDirectorVerificationOtp(data).subscribe((response: any) => {

        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })

          const dialogRef = this.dialog.open(OtpComponent, {
            disableClose: true,
            width: '400px',
            data: { title: title, messeage: message, inputValue: data, otp: response.otp },
          });

          dialogRef.afterClosed().subscribe(result => {
            if (result) {
              this.saveAbove('Auto');
              this.ngOnInit()
            }
          });

        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        })
      console.log("/////", data);
      // const dialogRef = this.dialog.open(OtpComponent, {
      //   disableClose: true,
      //   width: '400px',
      //   data: { title: title, message: message , inputValue:data , otp:'123456' },
      // });
    } else if (title == 'Director Phone Number Verification') {

      let data = {
        caseId: this.userDetails.case_id,
        directorId: directorId,
        mobileNo: val.directorMobile.value,
        emailId: '',
        type: "verifyDirectorMobileOTP",
        token: this.userInfo.token
      }
      this._apiService.sendDirectorVerificationOtp(data).subscribe((response: any) => {

        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })

          const dialogRef = this.dialog.open(OtpComponent, {
            disableClose: true,
            width: '400px',
            data: { title: title, messeage: message, inputValue: data, otp: response.otp },
          });

          dialogRef.afterClosed().subscribe(result => {
            if (result) {
              this.saveAbove('Auto');
              this.ngOnInit()
            }
            //success code here
          });

        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        })

      // const dialogRef = this.dialog.open(OtpComponent, {
      //   disableClose: true,
      //   width: '400px',
      //   data: { title: title, message: message , inputValue:data, otp:'123456' },
      // });

    } else if (title == 'CIBIL OTP') {

      let data = {
        caseId: this.userDetails.case_id,
        directorId: directorId,
        mobileNo: val.directorMobile.value,
        emailId: val.directorEmail.value,
        type: "verifyDirectorCibilOtp",
        token: this.userInfo.token
      }


      this._apiService.sendDirectorVerificationOtp(data).subscribe((response: any) => {

        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })

          const dialogRef = this.dialog.open(OtpComponent, {
            disableClose: true,
            width: '400px',
            data: { title: title, messeage: message, inputValue: data, otp: response.otp },
          });

          dialogRef.afterClosed().subscribe(result => {
            if (result) {
              this.getCibilScore(i, directorId)
            }
            this.saveAbove('Auto');
            this.ngOnInit()
            //success code here
          });

        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        })

    }
  }

  consentDialog(i: number, title: string, messeage: string, val: any, directorId: any, index: any): void {


    // console.log("---22////22222--13333333-dddd-2-2", this.flagArray[index])

    if (!this.flagArray[index].panFlag) {

      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'PAN verification Remain, Please verify PAN.',
        showConfirmButton: false,
        timer: 1500
      })
    } else if (!this.aadharFlag && !this.flagArray[index].adharFlag) {

      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Adhar verification Remain, Please verify Adhar.',
        showConfirmButton: false,
        timer: 1500
      })
    } else if (!this.flagArray[index].verifyMobileFlag) {

      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Mobile number verification Remain, Please verify mobile number.',
        showConfirmButton: false,
        timer: 1500
      })
    } else if (!this.flagArray[index].verifyEmailFlag) {

      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Email verification Remain, Please verify Email.',
        showConfirmButton: false,
        timer: 1500
      })
    } else {
      const dialogRef = this.dialog.open(ConsentComponent, {
        disableClose: true,
        width: '400px',
        data: { title: title, messeage: messeage },
      });

      dialogRef.afterClosed().subscribe(result => {
        if (!result) {
          this.itemsArray.updateValueAndValidity()
          this.form.updateValueAndValidity()
          this.flagArray[index].verifyCibilOtpFlag = false
          this.itemsArray.controls[i].patchValue({
            verifyCibilOtpFlag: false
          })
          this.itemsArray.updateValueAndValidity()
          this.form.updateValueAndValidity()
        } else {
          this.openOTPDialogBox(i, 'CIBIL OTP', 'By providing OTP you allow us to access your CIBIL details.', val, directorId);
        }
        // console.log("=====///==",result)
      })
    }





  }

  getCibilScore(i: number, directorId: any) {
    this.spinner.show();
    let data = {
      caseId: this.userDetails.case_id,
      directorId: directorId,
      token: this.userInfo.token,
      version: this.userInfo.version
    }

    this._apiService.getCibilScore(data).subscribe((res: any) => {
      if (!res.error) {
        this.spinner.hide();
        this.itemsArray.controls[i].patchValue({
          verifyCibilOtpFlag: true
        })
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
        this.ngOnInit()
      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
        this.ngOnInit()
      }
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.ngOnInit()

    })
  }

  changePhotoFlag(event: any) {
    this.ngOnInit()

  }

}
