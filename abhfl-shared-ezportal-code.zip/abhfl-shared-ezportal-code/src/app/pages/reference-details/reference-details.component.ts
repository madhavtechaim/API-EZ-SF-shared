import { StorageService } from './../../services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-reference-details',
  templateUrl: './reference-details.component.html',
  styleUrls: ['./reference-details.component.scss']
})
export class ReferenceDetailsComponent implements OnInit {

  form: FormGroup;
  formSumitAttempt: boolean;
  isWebRequest: boolean = false;
  adharData: any;
  userData: any;
  ref1Area: any=[];
  ref1Landmark: any=[];
  ref2Area: any =[];
  ref2Landmark: any=[];
  userDetails: any;
  referance: any;
  relationTypeData: any;
  ref1: any = true;
  ref2: any = true;
  userInfo: any;

  relationList1: any[] = [];
  filterRelation1:any[]=[]
  relationList2: any[] = [];
  filterRelation2:any[]=[]

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, private storageService:StorageService, private spinner: NgxSpinnerService,private _auth:AuthService) { }


  ngOnInit(): void {

    this.userInfo = this.storageService.secureStorage.getItem("userinfo");

    this.adharData = this.storageService.secureStorage.getItem('Aadhar');
    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    this.form = this._formBuilder.group({
      //Reference1 Address
      reference1rid:[''],
      reference1Name: ['', [Validators.required]],
      // reference1RelationshipWithApplicant: ['', [Validators.required,this.requireMatch.bind(this)]],
      reference1PhoneNumber: ['', [Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      reference1Email:['',[Validators.required,Validators.email]],
      reference1WorkingWith: ['', [Validators.required]],
      reference1OfficeEmail:['',[Validators.required,Validators.email]],
      // reference1KnowingSince: ['', [Validators.required]],
      // reference1AddressLine1: ['', [Validators.required]],
      // reference1AddressLine2: ['', [Validators.required]],
      // reference1Landmark: ['', [Validators.required]],
      // reference1Pincode: ['', [Validators.required,Validators.pattern(/^\d{6}$/)]],
      // reference1Area: ['',[Validators.required]],
      // reference1PostOffice: ['', [Validators.required]],
      // reference1City: ['', [Validators.required]],
      // reference1District: ['', [Validators.required]],
      // reference1State: ['', [Validators.required]],
      // reference1Country: ['', [Validators.required]],

      //Reference2 Address
      reference2rid:[''],
      reference2Name: ['', [Validators.required]],
      // reference2RelationshipWithApplicant: ['', [Validators.required,this.requireMatch.bind(this)]],
      reference2PhoneNumber: ['', [Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      reference2Email:['',[Validators.required,Validators.email]],
      reference2WorkingWith: ['', [Validators.required]],
      reference2OfficeEmail:['',[Validators.required,Validators.email]],
      // reference2KnowingSince: ['', [Validators.required]],
      // reference2AddressLine1: ['', [Validators.required]],
      // reference2AddressLine2: ['', [Validators.required]],
      // reference2Landmark: ['', [Validators.required]],
      // reference2Pincode: ['', [Validators.required,Validators.pattern(/^\d{6}$/)]],
      // reference2Area: ['',[Validators.required]],
      // reference2PostOffice: ['', [Validators.required]],
      // reference2City: ['', [Validators.required]],
      // reference2District: ['', [Validators.required]],
      // reference2State: ['', [Validators.required]],
      // reference2Country: ['', [Validators.required]],

    });
    this.getCaseDetails();
    // this.getAllRelationtType();

    // this.form.controls['reference1Pincode'].valueChanges.subscribe((res:any)=>{
      
    //   // console.log(res);
      
    //   if(this.form.controls['reference1Pincode'].status != 'INVALID'){
    //     this.onEnterPermanantPincode(res,'','ref1');
    //   }

    // })

    // this.form.controls['reference2Pincode'].valueChanges.subscribe((res:any)=>{
  
    //   if(this.form.controls['reference2Pincode'].status != 'INVALID'){
    //   this.onEnterPermanantPincode(res,'','ref2');
    //   }
    // })



    // this.form.controls['reference1RelationshipWithApplicant'].valueChanges.subscribe((res:any)=>{
    //   this.filterRelation1 = this.relationList1.filter((x:any) => x.title.toLowerCase().includes(res.toLowerCase()));
    //   if(this.filterRelation1.length == 0){
    //     this.filterRelation1=[...this.relationList1]
    //   }
    // })


    // this.form.controls['reference2RelationshipWithApplicant'].valueChanges.subscribe((res:any)=>{
    //   if(res){
    //     this.filterRelation2 = this.relationList2.filter((x:any) => x.title.toLowerCase().includes(res.toLowerCase()));
    //     if(this.filterRelation2.length == 0){
    //       this.filterRelation2=[...this.relationList2]
    //     }
    //   }else{
    //     this.filterRelation2=[...this.relationList2]
    //   }
      
    // })


  }


  requireMatch(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.relationList1 && this.relationList1.find((ele:any)=> ele.title == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }


  requireMatch1(control: FormControl): ValidationErrors | null {
    const selection1: any = control.value;
    console.log("selectionselection",selection1);

    if (this.relationList2 && this.relationList2.find((ele:any)=> ele.title == selection1) == null) {
      return { requireMatch: true };
    }
    return null;
  }




  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }


  onEnterPermanantPincode(event: any,type:string,addressType:string) {
    this.spinner.show();

    let data= {
      // token: "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjIsImlhdCI6MTY2Mzc2OTg1NSwiZXhwIjoxNjc5NTM3ODU1fQ.9WxzOeboC2O4LYoLFYUx5Lqo8q27hjQ-8Ai05U7S9do",
      // version: 19,
      pincode:event
  }
   
    this._apiService.getPincodeDetails1(data).subscribe((res) => {
      if (!res.error ) {
        let city
        // for (let index = 0; index < res[0].PostOffice.length; index++) {
        //   let area = res[0].PostOffice[index].Name;
        //   let landmark = res[0].PostOffice[index].Name;
        //    city = res[0].PostOffice[index];

        
        //   if(addressType =='ref1'){
        //     this.ref1Area.push({ value: area, title: area });
        //     this.ref1Landmark.push({ value: landmark, title: landmark });
        //     // this.permanantCity.push({ value: city, title: city });
        //   }else if(addressType =='ref2'){
        //     this.ref2Area.push({ value: area, title: area });
        //     this.ref2Landmark.push({ value: landmark, title: landmark });
        //     // this.currentCity.push({ value: city, title: city });
        //   }
        // }

        if(addressType =='ref1'){

          this.form.controls['reference1District'].patchValue(res.data.city);
          this.form.controls['reference1State'].patchValue(res.data.state);
          this.form.controls['reference1Country'].patchValue(res.data.country);
          this.form.controls['reference1City'].patchValue(res.data.city);

          // this.form.controls['reference1District'].patchValue(city.District);
          // this.form.controls['reference1State'].patchValue(city.State);
          // this.form.controls['reference1Country'].patchValue(city.Country);
          // this.form.controls['reference1City'].patchValue( res[0].PostOffice[0].Block);
        }else if(addressType =='ref2'){

          this.form.controls['reference2District'].patchValue(res.data.city);
          this.form.controls['reference2State'].patchValue(res.data.state);
          this.form.controls['reference2Country'].patchValue(res.data.country);
          this.form.controls['reference2City'].patchValue(res.data.city);

          // this.form.controls['reference2District'].patchValue(city.District);
          // this.form.controls['reference2State'].patchValue(city.State);
          // this.form.controls['reference2Country'].patchValue(city.Country);
          // this.form.controls['reference2City'].patchValue( res[0].PostOffice[0].Block);

      
          // this.form.controls['reference2Area'].patchValue(this.permantAddress?.area);
          // this.form.controls['permanantLand'].patchValue(this.permantAddress?.landmark);
          // this.form.controls['reference2City'].patchValue(this.permantAddress.city == null ? res[0].PostOffice[0].Block: this.permantAddress.city);
        }
        this.spinner.hide();

      }else{
        
        if(addressType =='ref1'){

          this.form.controls['reference1District'].reset();
          this.form.controls['reference1State'].reset();
          this.form.controls['reference1Country'].reset();
          this.form.controls['reference1City'].reset();

          // this.form.controls['reference1District'].patchValue(city.District);
          // this.form.controls['reference1State'].patchValue(city.State);
          // this.form.controls['reference1Country'].patchValue(city.Country);
          // this.form.controls['reference1City'].patchValue( res[0].PostOffice[0].Block);
        }else if(addressType =='ref2'){

          this.form.controls['reference2District'].reset();
          this.form.controls['reference2State'].reset();
          this.form.controls['reference2Country'].reset();
          this.form.controls['reference2City'].reset();

          // this.form.controls['reference2District'].patchValue(city.District);
          // this.form.controls['reference2State'].patchValue(city.State);
          // this.form.controls['reference2Country'].patchValue(city.Country);
          // this.form.controls['reference2City'].patchValue( res[0].PostOffice[0].Block);

      
          // this.form.controls['reference2Area'].patchValue(this.permantAddress?.area);
          // this.form.controls['permanantLand'].patchValue(this.permantAddress?.landmark);
          // this.form.controls['reference2City'].patchValue(this.permantAddress.city == null ? res[0].PostOffice[0].Block: this.permantAddress.city);
        }
        this.spinner.hide();
      }
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
    })
  }

  collapse(data:any,status:any){
    if(data =='Ref1'){
      this.ref1 = status ; 
    }else if(data =='Ref2'){
      this.ref2 = status ;
    }
  }



  getCaseDetails(){
    this.spinner.show();
    this._apiService.getCaseDetails({token:this.userInfo.token}).subscribe((res)=>{
      if(!res.error){
        this.userDetails = res.data[0]; 
        this.referance = res.referenceData;
  
        if(this.referance.length>0){
          this.form.patchValue({
            reference1rid : this.referance[0].rid,
            reference1Name:  this.referance[0].reference_name,
            // reference1RelationshipWithApplicant: parseInt(this.referance[0].reference_relation) ,
            reference1Email : this.referance[0].reference_email,
            reference1PhoneNumber: this.referance[0].reference_phone_no,
            // reference1KnowingSince: this.referance[0].reference_since,
            // reference1AddressLine1: this.referance[0].reference_addressline1,
            // reference1AddressLine2: this.referance[0].reference_addressline2,
            // reference1Landmark: this.referance[0].reference_landmark,
            // reference1Pincode: this.referance[0].reference_pincode,
            // reference1Area: this.referance[0].reference_area,
            // reference1PostOffice: this.referance[0].reference_postoffice,
            // reference1City: this.referance[0].reference_city,
            // reference1District: this.referance[0].reference_district,
            // reference1State: this.referance[0].reference_state,
            // reference1Country: this.referance[0].reference_country,

            reference1WorkingWith: this.referance[0].reference_works_with,
            reference1OfficeEmail:this.referance[0].reference_office_email,

    
            reference2rid : this.referance[1].rid,
            reference2Name:  this.referance[1].reference_name,
            // reference2RelationshipWithApplicant: parseInt(this.referance[1].reference_relation),
            reference2Email : this.referance[0].reference_email,
            reference2PhoneNumber: this.referance[1].reference_phone_no,
            // reference2KnowingSince: this.referance[1].reference_since,
            // reference2AddressLine1: this.referance[1].reference_addressline1,
            // reference2AddressLine2: this.referance[1].reference_addressline2,
            // reference2Landmark: this.referance[1].reference_landmark,
            // reference2Pincode: this.referance[1].reference_pincode,
            // reference2Area: this.referance[1].reference_area,
            // reference2PostOffice: this.referance[1].reference_postoffice,
            // reference2City: this.referance[1].reference_city,
            // reference2District: this.referance[1].reference_district,
            // reference2State: this.referance[1].reference_state,
            // reference2Country: this.referance[1].reference_country,
            reference2WorkingWith: this.referance[1].reference_works_with,
            reference2OfficeEmail:this.referance[1].reference_office_email,
    
            // this.form.patchValue({cancelledCheque: this.userDetails.cancelled_cheque_no ,ifscCode :this.userDetails.ifsc_code, accountNumber :this.userDetails.account_number , bankName :this.userDetails.bank_name, branchName :this.userDetails.branch_name, micrNumber:this.userDetails.micr_code, yersOfRelationship:this.userDetails.no_of_years,accountType:this.userDetails.account_type,accountHolder:this.userDetails.account_holder_name,owner1:this.userDetails.owner1,owner2:this.userDetails.owner2
            }) 
        }


        if(this.userDetails && this.relationList1.length>0){
          this.form.patchValue({
            reference1RelationshipWithApplicant: this.relationList1.find((ele:any)=>ele.value == parseInt(this.referance[0].reference_relation)).title,
            reference2RelationshipWithApplicant: this.relationList2.find((ele:any)=>ele.value == parseInt(this.referance[1].reference_relation)).title
          })
        }
       
        this.spinner.hide();
    }else{
      this.spinner.hide();
    }

   },(err: HttpErrorResponse) =>
    {
      this.spinner.hide();
    if (err.status === 400) {
      Swal.fire({
        position: 'center',
        icon: 'success',
        title: err.error.message,
        showConfirmButton: false,
        timer: 1500
      })
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
        showConfirmButton: false,
        timer: 1500
      })
    }
  })
  }


  getAllRelationtType(){
    this.spinner.hide();
    let data={
      // perPage:100000,
      type:"relationship"
    }
    this._apiService.getAgentType(data).subscribe((res)=>{
        this.relationTypeData = res;
        this.relationTypeData.forEach((element:any) => {
          this.relationList1.push({title:element.relationship
            , value:element.rm_id})
          this.relationList2.push({title:element.relationship
            , value:element.rm_id})
        });

        if(this.userDetails && this.relationList1.length>0){

          console.log("vdsvdsvds",this.referance[0].reference_relation
            ,this.relationList1,this.relationList1.find((ele:any)=>ele.value == parseInt(this.referance[0].reference_relation)));
    
          this.form.patchValue({
            reference1RelationshipWithApplicant: this.relationList1.find((ele:any)=>ele.value == parseInt(this.referance[0].reference_relation)).title,
            reference2RelationshipWithApplicant: this.relationList2.find((ele:any)=>ele.value == parseInt(this.referance[1].reference_relation)).title
          })
          
        }
       

        this.spinner.hide();
    },(err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }



  back(): void {
    this.router.navigate(['/home/upload-documents'])
  }

  next() {
    this.formSumitAttempt = true;
    // console.log(this.form.value)
    if (this.form.valid) {
      this.spinner.show();
      this.isWebRequest = true;

      let data={
        appId:this.userDetails.case_id,
        stageCount:7,
        token:this.userInfo.token,
        // version:this.userInfo.version,
        reference: [
          {
              rid:this.form.value.reference1rid ? this.form.value.reference1rid : '',
              referenceName: this.form.value.reference1Name,
              // referenceRelation: this.filterRelation1.find((ele:any)=>ele.title ==this.form.value.reference1RelationshipWithApplicant).value ,
              referenceRelation: 'null' ,
              referencePhoneno: this.form.value.reference1PhoneNumber,
              referenceEmail: this.form.value.reference1Email,
              // referenceSince: this.form.value.reference1KnowingSince,
              // referenceAddressline1: this.form.value.reference1AddressLine1,
              // referenceAddressline2: this.form.value.reference1AddressLine2,
              // referenceLandmark: this.form.value.reference1Landmark,
              // referencePincode: this.form.value.reference1Pincode,
              // referenceArea: this.form.value.reference1Area,
              // referencePostoffice: this.form.value.reference1PostOffice,
              // referenceCity: this.form.value.reference1City,
              // referenceDistrict: this.form.value.reference1District,
              // referenceState: this.form.value.reference1State,
              // referenceCountry: this.form.value.reference1Country,
              referenceSince: 'null',
              referenceAddressline1: 'null',
              referenceAddressline2: 'null',
              referenceLandmark: 'null',
              referencePincode: 'null',
              referenceArea: 'null',
              referencePostoffice: 'null',
              referenceCity: 'null',
              referenceDistrict: 'null',
              referenceState: 'null',
              referenceCountry: 'null',
              residenceType: "2",
              referenceWorkingWith: this.form.value.reference1WorkingWith,
              referenceOfficeEmail: this.form.value.reference1OfficeEmail,
          },
          {
            rid:this.form.value.reference2rid ? this.form.value.reference2rid : '',
            referenceName: this.form.value.reference2Name,
            // referenceRelation: this.filterRelation2.find((ele:any)=>ele.title ==this.form.value.reference2RelationshipWithApplicant).value ,
            referenceRelation:'null',
            referencePhoneno: this.form.value.reference2PhoneNumber,
            referenceEmail: this.form.value.reference2Email,
            // referenceSince: this.form.value.reference2KnowingSince,
            // referenceAddressline1: this.form.value.reference2AddressLine1,
            // referenceAddressline2: this.form.value.reference2AddressLine2,
            // referenceLandmark: this.form.value.reference2Landmark,
            // referencePincode: this.form.value.reference2Pincode,
            // referenceArea: this.form.value.reference2Area,
            // referencePostoffice: this.form.value.reference2PostOffice,
            // referenceCity: this.form.value.reference2City,
            // referenceDistrict: this.form.value.reference2District,
            // referenceState: this.form.value.reference2State,
            // referenceCountry: this.form.value.reference2Country,
            referenceSince: 'null',
            referenceAddressline1: 'null',
            referenceAddressline2: 'null',
            referenceLandmark: 'null',
            referencePincode: 'null',
            referenceArea: 'null',
            referencePostoffice: 'null',
            referenceCity: 'null',
            referenceDistrict: 'null',
            referenceState: 'null',
            referenceCountry: 'null',
            residenceType: "2",
            referenceWorkingWith: this.form.value.reference2WorkingWith,
            referenceOfficeEmail: this.form.value.reference2OfficeEmail,
          }
  
       ],
      }

      this._apiService.addCaseDetail(data).subscribe((response:any)=>{
        if(!response.error){
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.router.navigate(['/home/financial-institution-details']);
        }else{
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
      (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
  
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
            showConfirmButton: false,
            timer: 1500
          })
        }
        this.isWebRequest = false;
      })
    }
  }

  cancel() {
    this.router.navigate(['/home'])
  }


  keyPressName(event: any) {
    const pattern = /^[a-zA-Z ]*$/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }


  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  
  navigateTo(){
    this.router.navigate(['/home'])
  }


  // keyPress(event: any) {
  //   const pattern = /[0-9\+\-\ ]/;
  //   let inputChar = String.fromCharCode(event.charCode);
  //   if (event.keyCode != 8 && !pattern.test(inputChar)) {
  //     event.preventDefault();
  //   }
  // }

}
