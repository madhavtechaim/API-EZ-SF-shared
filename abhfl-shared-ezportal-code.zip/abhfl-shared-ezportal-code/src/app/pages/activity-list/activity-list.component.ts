import { StorageService } from './../../services/storage.service';
import { ActivityFiltersComponent } from 'src/app/modals/activity-filters/activity-filters.component';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { debounceTime } from 'rxjs';
// import * as moment from 'moment';

@Component({
  selector: 'app-activity-list',
  templateUrl: './activity-list.component.html',
  styleUrls: ['./activity-list.component.scss']
})
export class ActivityListComponent implements OnInit {

      
  dayEventList: any[]=[];
  isWebRequest: boolean = false;

  filterFromDate: any;
  filterToDate: any;
  filterAgentType: any;
  filterEventTitle: any;
  filterEventType: any;
  filterEventStatus: any;
  appointmentState: any="All";
  filterData: any;
  userInfo: any;

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, public dialog: MatDialog , private storageService:StorageService, private spinner: NgxSpinnerService) { }

  ngOnInit(): void {


    this.userInfo = this.storageService.secureStorage.getItem("userinfo");

    this._apiService.filterSend.subscribe((res:any)=>{

      this.appointmentState = res.eventType
      // console.log("resresres",res);
      // if(res.eventType =='ALL'){
      //   this.appointmentState = res.eventType
      // }else if(res.eventType =='NEW APPOINTMENT'){
      //   this.appointmentState = 'New Appointment'
      // }else if(res.eventType =='FOLLOW UP'){
      //   this.appointmentState = 'Followup'
      // }else if(res.eventType =='CONVERTED'){
      //   this.appointmentState = 'Converted'
      // }else if(res.eventType =='WRONG NUMBER'){
      //   this.appointmentState = 'Wrong Number'
      // }else if(res.eventType =='NOT INTERESTED'){
      //   this.appointmentState = 'Not Interested'
      // }else if(res.eventType =='RENEWAL COLLECTED'){
      //   this.appointmentState = 'Renewal Collected'
      // }


      if(this.appointmentState == 'Follow Up'){
        this.appointmentState ='Followup';
      }


      this.filterData = {
        startDate: '',
        fromDate: res.fromDate?res.fromDate:'',
        toDate: res.toDate?res.toDate:'',
        agentType: '',
        eventTitle: '',
        eventType: '',
        eventStatus: this.appointmentState?this.appointmentState:'',
        type: res.type?res.type :'Monthly',
        searchTerm:'',
        token:this.userInfo.token,
        version:this.userInfo.version,
      }
    })
    this.getEventList(this.filterData);
  }

  search(event:any){
    // console.log(event,event.target.value
    //   );
    this.filterData.searchTerm = event.target.value
    this.filterData.token = this.userInfo.token;
    this.filterData.version = this.userInfo.version;

    

    setTimeout(() => {
      // console.log('Hello world')
      this.getEventList(this.filterData);
    }, 2000)


  }

  openFilterDialog(): void {
    const dialogRef = this.dialog.open(ActivityFiltersComponent, {
      disableClose: true,
      width: '400px',
    });

    dialogRef.afterClosed().subscribe(result => {

      if(result.status){
        this.filterData.eventStatus = result.data.eventStatus?result.data.eventStatus:[];
        this.filterData.agentType = result.data.agentType?result.data.agentType:[];
        this.filterData.eventTitle = result.data.eventTitle?result.data.eventTitle:[];
        this.filterData.fromDate = result.data.fromDate?result.data.fromDate:this.filterData.fromDate;
        this.filterData.toDate = result.data.toDate?result.data.fromDate:this.filterData.toDate;
        this.filterData.eventStatus = this.appointmentState?this.appointmentState:'All';
        this.filterData.token = this.userInfo.token;
        this.filterData.version = this.userInfo.version;


       

        this.getEventList(this.filterData);
      }else{

      }
      
      //success code here
    });
  }

  appointmentStatus(value:any){
    this.appointmentState = value;
    this.filterData.eventStatus = value;
    this.getEventList(this.filterData);
  }

  getEventList(data:any) {
    this.spinner.show();

    data.eventStatus = data.eventStatus !='All'?data.eventStatus :''

    this._apiService.getEventList(data).subscribe((res) => {
   
      if(!res.error){
        this.dayEventList=[];
        this.dayEventList = res.eventData;
        this.spinner.hide();
        if(this.dayEventList){
          // this.appointmentState = this.dayEventList[0].appointment_status
          // if(this.appointmentState != 'All'){
          //   this.dayEventList= this.dayEventList.filter((ele:any )=> ele.appointment_status == this.appointmentState)
          //   // console.log("this.dayEventList",this.dayEventList);
          // }else{

          // }
          this.dayEventList.forEach((element:any) => {
            element.start_time=moment(element.start_time, "HH:mm:ss").format("hh:mm A");
          });
        }
      }else{
        this.spinner.hide();
      }
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }

  navigateTo(){
    this.router.navigate(['/home/dsa-dashboard'])
  }

}
