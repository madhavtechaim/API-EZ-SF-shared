import { StorageService } from './../../services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { Location } from '@angular/common';


@Component({
  selector: 'app-add-event',
  templateUrl: './add-event.component.html',
  styleUrls: ['./add-event.component.scss']
})
export class AddEventComponent implements OnInit {

  form: FormGroup;
  isWebRequest: boolean = false;
  formSumitAttempt: boolean;
  respo: boolean;
  mode: string='Visit';
  duration: string='Working Days';
  status: string ='Open';
  memberList: any;
  endDate: any;
  todayDate:any = moment().format('YYYY-MM-DD');
  endTime: any='';
  min: any;
  userInfo: any;

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, public dialog: MatDialog, private storageService:StorageService , private spinner: NgxSpinnerService,private location: Location) { }

  ngOnInit(): void {
    // console.log(this.todayDate);
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    
    this.form = this._formBuilder.group({
      event: ['', [Validators.required]],
      typeOfEvent: ['', [Validators.required]],
      // mode: ['', [Validators.required]],
      // duration: ['', [Validators.required]],
      // name: ['', [Validators.required]],
      // mobile: ['', [Validators.required], Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")],
      // email: ['', [Validators.required]],
      startDate: ['',[Validators.required]],
      startTime: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      endTime: ['', [Validators.required]],
      typeOfAgents: ['', [Validators.required]],
      teamMembers: [['']],
      // status: ['', [Validators.required]],
      eventDescription: ['', [Validators.required]],
    });

    this.getMemberList();


    this.form.controls['typeOfEvent'].valueChanges.subscribe((res:any)=>{
      if(res =='Individual'){
        this.respo = true ; 
        this.form.addControl('mobile', new FormControl('',[ Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]));
        this.form.addControl('email', new FormControl('', [Validators.required,Validators.email]));
        this.form.addControl('name', new FormControl('', Validators.required));

        this.form.updateValueAndValidity();
      }else{
        this.respo = false ; 
        this.form.removeControl('mobile'); 
        this.form.removeControl('email'); 
        this.form.removeControl('name'); 
        this.form.updateValueAndValidity();
      }
    })
  }

  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }

  // addEvent() {
  //   this.router.navigate(['/home/dsa-dashboard'])
  // }

  getMemberList(){
    this._apiService.getMemberList({}).subscribe((res:any)=>{
      if(!res.error){
        // console.log("resresresresres",res);
        this.memberList = res.memberData ;
      }else{

      }
    })
  }


  chipChange(type:string,value:string){

    if(type =='Mode'){
      this.mode = value; 
    }
    if(type == 'Duration'){
      this.duration = value ;
    }
    if(type == 'Status'){
      this.status = 'Open' ;
    }
  }


  addEvent() {

    this.formSumitAttempt = true;

    // console.log(this.form);

    if (this.form.valid) {
      this.isWebRequest = true;

      this.spinner.show();


      let data = {
       eventTitle: this.form.value.event,
      eventType : this.form.value.typeOfEvent,
      eventMode : this.mode,
      eventDuration : this.duration,
      startDate : this.form.value.startDate,
      startTime : this.form.value.startTime,
      endDate : this.form.value.endDate,
      endTime : this.form.value.endTime,
      agentType : this.form.value.typeOfAgents,
      eventStatus : this.status,
      individualName : this.form.value.name?this.form.value.name:'',
      individualemailId: this.form.value.email?this.form.value.email:'',
      individualcontactNo: this.form.value.mobile?this.form.value.mobile:'',
      eventDescription : this.form.value.eventDescription,
      teamMember : this.form.value.teamMembers,
      // token:this.storageService.secureStorage.getItem('token'),
      // version:this.storageService.secureStorage.getItem('version'),
      token:this.userInfo.token,
      version:this.userInfo.version
      }


      // let data = new FormData();

      // if(this.respo){
      //   data.append('name', this.form.value.name);
      //   data.append('email', this.form.value.email);
      //   data.append('mobile', this.form.value.mobile);
      // }
      // data.append('eventTitle', this.form.value.event);
      // data.append('eventType', this.form.value.typeOfEvent);
      // data.append('eventMode', this.mode);
      // data.append('eventDuration', this.duration);
      // data.append('startDate', this.form.value.startDate);
      // data.append('startTime', this.form.value.startTime);
      // data.append('endDate', this.form.value.endDate);
      // data.append('endTime', this.form.value.endTime);
      // data.append('agentType', this.form.value.typeOfAgents);
      // data.append('eventStatus', this.status);
      // data.append('individualName', this.form.value.name);
      // data.append('individualcontactNo', this.form.value.mobile);
      // data.append('individualemailId', this.form.value.email);
      // data.append('eventDescription', this.form.value.eventDescription);
      // data.append('teamMember', this.form.value.teamMembers);

      this._apiService.addDsaEvent(data).subscribe(
        (response: any) => {
          // console.log("___SSSSS", response)
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.router.navigate(['/home/dsa-dashboard'])

        },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        }
      );
    }
  }


  changeDate(event:any){


    if(this.form.controls['endDate'].value == ''){
      this.endDate = event.target.value
    }else{
      if(event.target.value > this.form.controls['endDate'].value){
        this.form.controls['endDate'].reset();
        this.endDate = event.target.value
      }else{
       this.endDate = event.target.value
      }
    }
    this.form.controls['endDate'].patchValue(this.endDate)
  }

  changeTime(event:any){
    // console.log("eventeventevent",event.target.value);
    this.min = '2022-04-14 '+ event.target.value +':15'

    this.endTime = moment(this.min).add(1,'hours').format('HH:mm')
    
    this.form.controls['endTime'].patchValue(this.endTime)
    
  }
    
  


  cancel() {
    // this.router.navigate(['/home/dsa-dashboard'])
    this.location.back();
    
  }

  navigateTo(){
    this.router.navigate(['/home/dsa-dashboard'])
  }

  onFocusStartDatePicker(){
    console.log("-----");
  }
}