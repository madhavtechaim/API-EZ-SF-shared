import { AuthService } from 'src/app/services/auth.service';
import { StorageService } from './../../services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-address-details',
  templateUrl: './address-details.component.html',
  styleUrls: ['./address-details.component.scss']
})
export class AddressDetailsComponent implements OnInit {

  form: FormGroup;
  formSumitAttempt: boolean;
  isWebRequest: boolean = false;
  recidentTypes: any;

  officeArea: any = [];
  officeLandmark: any = [];
  officeCity: any = [];

  currentArea: any = [];
  currentLandmark: any = [];
  currentCity: any = [];

  permanantArea: any = [];
  permanantLandmark: any = [];
  permanantCity: any = [];
  adharData: any;
  userData: any;
  userDetails: any;
  addressData: any;
  permantAddress: any;
  currentAddress: any;
  officeAddress: any;
  officeC: boolean = true;
  permantC: boolean = true;
  currentC: boolean = true;
  userInfo: any;
  
  relationList1: any[] = [];
  filterRelation1:any[]=[]
  relationList2: any[] = [];
  filterRelation2:any[]=[]
  current_adhaar_address_proof: any;
  permanant_aadhar_flag: any;
  current_address_flag: any;
  office_address_flag: any;
  permanent_address_flag: any;
  permanant_adhaar_address_proof: any;



  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, public dialog: MatDialog, private storageService:StorageService, private spinner: NgxSpinnerService ,private _auth:AuthService) { }


  ngOnInit(): void {

    
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");

    this.form = this._formBuilder.group({
      //Office Address
      officeaid : [''],
      officeAddressLine1: ['', [Validators.required]],
      officeAddressLine2: ['', [Validators.required]],
      officePincode: ['', [Validators.required,Validators.pattern(/^\d{6}$/)]],
      officeArea: ['', [Validators.required]],
      officeLand: ['', [Validators.required]],
      officeCity: ['', [Validators.required]],
      officeDistrict: ['', [Validators.required]],
      officeState: ['', [Validators.required]],
      officeCountry: ['', [Validators.required]],
      // officeResidentType: ['', [Validators.required]],

      //Current Address
      currentaid :  [''],
      currentAddressLine1: ['', [Validators.required]],
      currentAddressLine2: ['', [Validators.required]],
      currentPincode: ['', [Validators.required,Validators.pattern(/^\d{6}$/)]],
      currentArea: ['', [Validators.required]],
      currentLand: ['', [Validators.required]],
      currentCity: ['', [Validators.required]],
      currentDistrict: ['', [Validators.required]],
      currentState: ['', [Validators.required]],
      currentCountry: ['', [Validators.required]],
      // currentResidentType: ['', [Validators.required,this.requireMatch.bind(this)]],
      currentResidentType: [null],

      //Permanant Address
      permanantaid : [''],
      permanantAddressLine1: ['', [Validators.required]],
      permanantAddressLine2: ['', [Validators.required]],
      permanantPincode: ['', [Validators.required,Validators.pattern(/^\d{6}$/)]],
      permanantArea: ['', [Validators.required]],
      permanantLand: ['', [Validators.required]],
      permanantCity: ['', [Validators.required]],
      permanantDistrict: ['', [Validators.required]],
      permanantState: ['', [Validators.required]],
      permanantCountry: ['', [Validators.required]],
      // permanantResidentType: ['', [Validators.required,this.requireMatch.bind(this)]],
      permanantResidentType: [null],
    });

    this.form.controls['permanantPincode'].valueChanges.subscribe((res)=>{
      if(this.form.controls['permanantPincode'].status != 'INVALID'){
      this.onEnterPermanantPincode(res,'auto','Permanant')
      }
    })

    this.form.controls['currentPincode'].valueChanges.subscribe((res)=>{
      if(this.form.controls['currentPincode'].status != 'INVALID'){
      this.onEnterPermanantPincode(res,'auto','Current')
      }
    })

    this.form.controls['officePincode'].valueChanges.subscribe((res)=>{
      if(this.form.controls['officePincode'].status != 'INVALID'){
      this.onEnterPermanantPincode(res,'auto','Office')
      }
    })


    // this.form.controls['currentResidentType'].valueChanges.subscribe((res:any)=>{
    //   this.filterRelation1 = this.relationList1.filter((x:any) => x.title.toLowerCase().includes(res.toLowerCase()));
    //   if(this.filterRelation1.length == 0){
    //     this.filterRelation1=[...this.relationList1]
    //   }
    // })

    // this.form.controls['permanantResidentType'].valueChanges.subscribe((res:any)=>{
    //   if(res){
    //     this.filterRelation2 = this.relationList2.filter((x:any) => x.title.toLowerCase().includes(res.toLowerCase()));
    //     if(this.filterRelation2.length == 0){
    //       this.filterRelation2=[...this.relationList2]
    //     }
    //   }else{
    //     this.filterRelation2=[...this.relationList2]
    //   }
      
    // })



    this.adharData = this.storageService.secureStorage.getItem('Aadhar');
    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    this.getCaseDetails();

    this.getAllResidentType();
  }


  requireMatch(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.relationList1 && this.relationList1.find((ele:any)=> ele.title == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }


  requireMatch1(control: FormControl): ValidationErrors | null {
    const selection1: any = control.value;
    // console.log("selectionselection",selection1);

    if (this.relationList2 && this.relationList2.find((ele:any)=> ele.title == selection1) == null) {
      return { requireMatch: true };
    }
    return null;
  }

  getCaseDetails(){
    this.spinner.show();
    this._apiService.getCaseDetails({token:this.userInfo.token,
     }).subscribe((res)=>{
      if(!res.error){
        this.userDetails = res.data[0]; 
        this.addressData = res.addressData ; 

        this.current_adhaar_address_proof = this.userDetails.current_adhaar_address_proof;
        this.permanant_adhaar_address_proof = this.userDetails.permanent_adhaar_address_proof;
        // this.permanant_adhaar_address_proof = 1;


        this.current_address_flag = this.userDetails.current_address_flag;
        this.permanent_address_flag = this.userDetails.permanent_address_flag;
        // this.permanent_address_flag = 0;

        this.office_address_flag = this.userDetails.office_address_flag;

        // console.log(this.current_adhaar_address_proof,this.permanant_adhaar_address_proof,this.current_address_flag,this.permanent_address_flag,this.office_address_flag);

        this.permantAddress = this.addressData.find((ele:any) => ele.address_type == 'Permanent');
        this.currentAddress = this.addressData.find((ele:any) => ele.address_type == 'Current');
        this.officeAddress = this.addressData.find((ele:any) => ele.address_type == 'Office');

        if(this.permantAddress){
          this.form.patchValue({
            permanantaid : this.permantAddress.aid ? this.permantAddress.aid:'' ,
            permanantaddressType: "Permanent",
            permanantAddressLine1 : this.permantAddress.addressline1,
            permanantAddressLine2 : this.permantAddress.addressline2 ,
            permanantLand : this.permantAddress.landmark ,
            permanantPincode : this.permantAddress.pincode ,
            permanantArea : this.permantAddress.area ,
            // permanantCity : this.permantAddress.city ,
            permanantDistrict : this.permantAddress.district ,
            permanantState : this.permantAddress.state ,
            permanantCountry : this.permantAddress.country ,
            // permanantResidentType : this.permantAddress.resident_type
       })
        }

        if(this.currentAddress){
          this.form.patchValue({
            currentaid : this.currentAddress ? this.currentAddress.aid : '',
            currentaddressType: "Current",
            currentAddressLine1 : this.currentAddress.addressline1 ,
            currentAddressLine2 : this.currentAddress.addressline2 ,
            currentLand : this.currentAddress.landmark ,
            currentPincode : this.currentAddress.pincode ,
            currentArea : this.currentAddress.area ,
            // currentCity : this.currentAddress.city ,
            currentDistrict : this.currentAddress.district ,
            currentState : this.currentAddress.state ,
            currentCountry : this.currentAddress.country ,
            // currentResidentType : this.currentAddress.resident_type
            // ,
      })
        }

        if(this.officeAddress){
          this.form.patchValue({
            officeaid : this.officeAddress.aid ? this.officeAddress.aid :'',
            officeaddressType: "Office",
            officeAddressLine1 : this.officeAddress.addressline1,
            officeAddressLine2 : this.officeAddress.addressline2 ,
            officeLand : this.officeAddress.landmark ,
            officePincode : this.officeAddress.pincode ,
            officeArea : this.officeAddress.area ,
            // officeCity : this.officeAddress.city ,
            officeDistrict : this.officeAddress.district ,
            officeState : this.officeAddress.state ,
            officeCountry : this.officeAddress.country ,
            // officeResidentType : this.officeAddress.resident_type
      })
        }

        // if(this.currentAddress && this.relationList1.length >0){
        //   this.form.patchValue({
        //     currentResidentType: this.relationList1.find((ele:any)=>ele.value == parseInt(this.currentAddress.resident_type)).title
        //   })
        // }

        // if(this.permantAddress && this.relationList2.length >0){
        //   this.form.patchValue({
        //     permanantResidentType: this.relationList2.find((ele:any)=>ele.value == parseInt(this.permantAddress.resident_type)).title
        //   })
        // }
       
       
        this.spinner.hide();
        // this.form.patchValue({panfullname: this.userDetails.panfullname ,fathersName :this.userDetails.father_name, dateOfBirth :this.userDetails.date_of_birth , gender :this.userDetails.gender
        // })
    }

   },(err: HttpErrorResponse) =>
    {
      this.spinner.hide();
    if (err.status === 400) {
      Swal.fire({
        position: 'center',
        icon: 'success',
        title: err.error.message,
        showConfirmButton: false,
        timer: 1500
      })
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
        showConfirmButton: false,
        timer: 1500
      })
    }
  })
  }





  onEnterOfficePincode(event: any) {
    // let data = event.target.value;

    this.spinner.show();

    let data= {
      // token: "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjIsImlhdCI6MTY2Mzc2OTg1NSwiZXhwIjoxNjc5NTM3ODU1fQ.9WxzOeboC2O4LYoLFYUx5Lqo8q27hjQ-8Ai05U7S9do",
      // version: 19,
      pincode:event.target.value
  }


    this._apiService.getPincodeDetails1(data).subscribe((res) => {

      if (res[0].Status == "Success") {
        this.spinner.hide();

        for (let index = 0; index < res[0].PostOffice.length; index++) {
          let area = res[0].PostOffice[index].Name;
          let landmark = res[0].PostOffice[index].Name;
          let city = res[0].PostOffice[index].Name;
          this.officeArea.push({ value: area, title: area });
          this.officeLandmark.push({ value: landmark, title: landmark });
          this.officeCity.push({ value: city, title: city });

        }

        this.form.controls['officeDistrict'].patchValue(res[0].PostOffice[0].District);
        this.form.controls['officeState'].patchValue(res[0].PostOffice[0].State);
        this.form.controls['officeCountry'].patchValue(res[0].PostOffice[0].Country);
      }
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
    })
  }


  collapse(data:any,status:any){
    if(data =='Office'){
      this.officeC = status
    }else if(data =='Current'){
      this.currentC = status
    }else{
      this.permantC = status
    }
   
  }

  onEnterCurrentPincode(event: any) {
    let data = event.target.value;
    this.spinner.show();
    this._apiService.getPincodeDetails1(data).subscribe((res) => {
      if (res[0].Status == "Success") {
        for (let index = 0; index < res[0].PostOffice.length; index++) {
          let area = res[0].PostOffice[index].Name;
          let landmark = res[0].PostOffice[index].Name;
          let city = res[0].PostOffice[index].Name;
          this.currentArea.push({ value: area, title: area });
          this.currentLandmark.push({ value: landmark, title: landmark });
          this.currentCity.push({ value: city, title: city });
        }

        this.form.controls['currentDistrict'].patchValue(res[0].PostOffice[0].District);
        this.form.controls['currentState'].patchValue(res[0].PostOffice[0].State);
        this.form.controls['currentCountry'].patchValue(res[0].PostOffice[0].Country);
        this.spinner.hide();
      }
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
    })
  }

  onEnterPermanantPincode(event: any,type:string,addressType:string) {

    // let data
    // if(type == 'manual'){
    //   data = event.target.value
    // }else{
    //   data = event
    // }
    this.spinner.show();

    let data= {
      // token: "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjIsImlhdCI6MTY2Mzc2OTg1NSwiZXhwIjoxNjc5NTM3ODU1fQ.9WxzOeboC2O4LYoLFYUx5Lqo8q27hjQ-8Ai05U7S9do",
      // version: 19,
      pincode:event
  }


  
    this._apiService.getPincodeDetails1(data).subscribe((res) => {

      
      if (!res.error) {
        // console.log("resresres",res);
        
        // for (let index = 0; index < res[0].PostOffice.length; index++) {
        //   let area = res[0].PostOffice[index].Name;
        //   let landmark = res[0].PostOffice[index].Name;
        //   let city = res[0].PostOffice[index].Name;
        //   // if(addressType =='Permanant'){
        //   //   this.permanantArea.push({ value: area, title: area });
        //   //   this.permanantLandmark.push({ value: landmark, title: landmark });
        //   //   // this.permanantCity.push({ value: city, title: city });
        //   // }else if(addressType =='Current'){
        //   //   this.currentArea.push({ value: area, title: area });
        //   //   this.currentLandmark.push({ value: landmark, title: landmark });
        //   //   // this.currentCity.push({ value: city, title: city });
        //   // }else{
        //   //   this.officeArea.push({ value: area, title: area });
        //   //   this.officeLandmark.push({ value: landmark, title: landmark });
        //   //   // this.officeCity.push({ value: city, title: city });
        //   // }
         
        // }

      

        if(addressType =='Permanant'){
          this.form.controls['permanantDistrict'].patchValue(res.data.city);
          this.form.controls['permanantState'].patchValue(res.data.state);
          this.form.controls['permanantCountry'].patchValue(res.data.country);
          this.form.controls['permanantCity'].patchValue(res.data.city);
        }else if(addressType =='Current'){
          this.form.controls['currentDistrict'].patchValue(res.data.city);
          this.form.controls['currentState'].patchValue(res.data.state);
          this.form.controls['currentCountry'].patchValue(res.data.country);
          this.form.controls['currentCity'].patchValue(res.data.city);
        }else{
          this.form.controls['officeDistrict'].patchValue(res.data.city);
          this.form.controls['officeState'].patchValue(res.data.state);
          this.form.controls['officeCountry'].patchValue(res.data.country);
          this.form.controls['officeCity'].patchValue(res.data.city);
        }
       
        this.spinner.hide();
      }else{
        if(addressType =='Permanant'){
          this.form.controls['permanantDistrict'].reset();
          this.form.controls['permanantState'].reset();
          this.form.controls['permanantCountry'].reset();
          this.form.controls['permanantCity'].reset();
        }else if(addressType =='Current'){
          this.form.controls['currentDistrict'].reset();
          this.form.controls['currentState'].reset();
          this.form.controls['currentCountry'].reset();
          this.form.controls['currentCity'].reset();
        }else{
          this.form.controls['officeDistrict'].reset();
          this.form.controls['officeState'].reset();
          this.form.controls['officeCountry'].reset();
          this.form.controls['officeCity'].reset();
        }
        this.spinner.hide();
      }
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
    })
  }

  back(): void {
    this.router.navigate(['/home/partner-details'])
  }

  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }

  next() {
    this.formSumitAttempt = true;
    // console.log(this.form.value)
    // this.router.navigate(['/home/bank-details']);
    if (this.form.valid) {
      this.spinner.show();
      this.isWebRequest = true;

      let data={ 
        appId:this.userDetails.case_id,
        stageCount:4,
        token:this.userInfo.token,
        // version:this.userInfo.version,
        permanentFlag:this.permanent_address_flag,
        officeFlag:this.office_address_flag,

        addresses:[
        {
              aid:this.form.value.currentaid,
              addressType: "Current",
              addressL1: this.form.value.currentAddressLine1,
              addressL2: this.form.value.currentAddressLine2,
              landmark: this.form.value.currentLand,
              pincode: this.form.value.currentPincode,
              area: this.form.value.currentArea,
              city: this.form.value.currentCity,
              district: this.form.value.currentDistrict,
              state: this.form.value.currentState,
              country: this.form.value.currentCountry,
              // residenceType: this.form.value.currentResidentType
              // residenceType:this.filterRelation1.find((ele:any)=>ele.title == this.form.value.currentResidentType).value
              residenceType:null
          },
          {
            aid:this.form.value.permanantaid,
            addressType: "Permanent",
            addressL1: this.form.value.permanantAddressLine1,
            addressL2: this.form.value.permanantAddressLine2,
            landmark: this.form.value.permanantLand,
            pincode: this.form.value.permanantPincode,
            area: this.form.value.permanantArea,
            city: this.form.value.permanantCity,
            district: this.form.value.permanantDistrict,
            state: this.form.value.permanantState,
            country: this.form.value.permanantCountry,
            // residenceType: this.form.value.permanantResidentType
            // residenceType:this.filterRelation2.find((ele:any)=>ele.title == this.form.value.permanantResidentType).value
            residenceType:null
        },
          {
              aid:this.form.value.officeaid,
              addressType: "Office",
              residenceType:null,
              addressL1: this.form.value.officeAddressLine1,
              addressL2: this.form.value.officeAddressLine2,
              landmark: this.form.value.officeLand,
              pincode: this.form.value.officePincode,
              area: this.form.value.officeArea,
              city: this.form.value.officeCity,
              district: this.form.value.officeDistrict,
              state: this.form.value.officeState,
              country: this.form.value.officeCountry,
              // residenceType: this.form.value.officeResidentType
          }        
      ]}
  
      this._apiService.addCaseDetail(data).subscribe((response:any)=>{
        if(!response.error){
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.spinner.hide();
          this.router.navigate(['/home/bank-details'])
        }else{
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
      (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
  
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
            showConfirmButton: false,
            timer: 1500
          })
        }
        this.isWebRequest = false;
      })
    }
    
  }

  getAllResidentType() {
    let data = {
      type: "resident_type",
      token:this.userInfo.token
    }
    // this.spinner.show();
    this._apiService.getMasters(data).subscribe((res) => {
      this.recidentTypes = res;


      this.recidentTypes.forEach((element:any) => {
        this.relationList1.push({title:element.recident_type
          , value:element.rt_id})
        this.relationList2.push({title:element.recident_type
          , value:element.rt_id})
      });


        // if(this.currentAddress && this.relationList1.length >0){
        //   this.form.patchValue({
        //     currentResidentType: this.relationList1.find((ele:any)=>ele.value == parseInt(this.currentAddress.resident_type)).title
        //   })
        // }


        // if(this.permantAddress && this.relationList2.length >0){
        //   this.form.patchValue({
        //     permanantResidentType: this.relationList2.find((ele:any)=>ele.value == parseInt(this.permantAddress.resident_type)).title
        //   })
        // }



      // this.spinner.show();
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }

  cancel() {
    this.router.navigate(['/home'])
  }

  sameToCurrent(event:any){


    if(event == true){
      if( this.form.value.currentAddressLine1 && this.form.value.currentAddressLine2 && this.form.value.currentLand && this.form.value.currentPincode  && this.form.value.currentCountry && this.form.value.currentState && this.form.value.currentDistrict && this.form.value.currentCity && this.form.value.currentArea){
  
        // if(this.currentAddress && this.currentAddress.aid){
        //   let ChangeData={
        //       caseId:this.userDetails.case_id,
        //       address_type:"Permanent",
        //       checkValue:event == true ? 1:0,
        //       rid:this.currentAddress.aid
        //     }
        //   this._apiService.sameAsCurrentAddress(ChangeData).subscribe((res:any)=>{
        //     if(!res.error){
        //       this.ngOnInit();
        //       // this.getCaseDetails();
        //     }else{
        //       this.office_address_flag =0;
        //       Swal.fire({
        //         position: 'center',
        //         icon: 'warning',
        //         title: res.message,
        //         showConfirmButton: false,
        //         timer: 1500
        //       })
        //     }
        //   }, (err: HttpErrorResponse) => {
        //     this.office_address_flag =0;
        //   if (err.status === 400) {
        //     Swal.fire({
        //       position: 'center',
        //       icon: 'error',
        //       title: err.error.message,
        //       showConfirmButton: false,
        //       timer: 1500
        //     })
        //   } else {
        //     Swal.fire({
        //       position: 'center',
        //       icon: 'error',
        //       title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
        //       showConfirmButton: false,
        //       timer: 1500
        //     })
        //   }
        // })
        // }else{
          // this.permanent_address_flag ==1 ;
          this.permanent_address_flag =1
          this.form.patchValue({
            // permanantaid : this.permantAddress.aid ? this.permantAddress.aid:'' ,
            // permanantaddressType: "Permanent",
            permanantAddressLine1 : this.form.value.currentAddressLine1,
            permanantAddressLine2 :this.form.value.currentAddressLine2 ,
            permanantLand :this.form.value.currentLand ,
            permanantPincode :this.form.value.currentPincode ,
            permanantArea :this.form.value.currentArea ,
            permanantCity :this.form.value.currentCity ,
            permanantDistrict :this.form.value.currentDistrict ,
            permanantState :this.form.value.currentState ,
            permanantCountry :this.form.value.currentCountry ,
            // permanantResidentType :this.form.value.currentResidentType
      })
        // }
      }else{
        this.permanent_address_flag = 0 ;
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: "Please fill all required fields of current address",
          showConfirmButton: false,
          timer: 1500
        })
      }
    }else{
      if(this.currentAddress && this.currentAddress.aid){
        let ChangeData={
            caseId:this.userDetails.case_id,
            address_type:"Permanent",
            checkValue:event == true ? 1:0,
            rid:this.currentAddress.aid
          }
        this._apiService.sameAsCurrentAddress(ChangeData).subscribe((res:any)=>{
          if(!res.error){
            // this.getCaseDetails();
            this.ngOnInit();
          }else{
            this.office_address_flag ==1;
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: res.message,
              showConfirmButton: false,
              timer: 1500
            })
          }
        }, (err: HttpErrorResponse) => {
          this.office_address_flag ==1;
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
            showConfirmButton: false,
            timer: 1500
          })
        }
      })
      }else{

        
        this.permanent_address_flag = 0;
        this.form.patchValue({
          permanantaid : null ,
          // permanantaddressType: "Permanent",
          permanantAddressLine1 : null,
          permanantAddressLine2 :null ,
          permanantLand :null ,
          permanantPincode :null ,
          permanantArea :null ,
          permanantCity :null ,
          permanantDistrict :null ,
          permanantState :null ,
          permanantCountry :null ,
          permanantResidentType :null
    })
      }
    }




    // console.log(event.checked);
    
    // return;

    if(event.checked){
      this.form.patchValue({
        // permanantaid : this.permantAddress.aid ? this.permantAddress.aid:'' ,
        // permanantaddressType: "Permanent",
        permanantAddressLine1 : this.form.value.currentAddressLine1,
        permanantAddressLine2 :this.form.value.currentAddressLine2 ,
        permanantLand :this.form.value.currentLand ,
        permanantPincode :this.form.value.currentPincode ,
        permanantArea :this.form.value.currentArea ,
        permanantCity :this.form.value.currentCity ,
        permanantDistrict :this.form.value.currentDistrict ,
        permanantState :this.form.value.currentState ,
        permanantCountry :this.form.value.currentCountry ,
        // permanantResidentType :this.form.value.currentResidentType
  })
    }else{
      // this.form.controls['permanantAddressLine1'].reset();
      // this.form.controls['permanantAddressLine2'].reset();
      // this.form.controls['permanantLand'].reset();
      // this.form.controls['permanantPincode'].reset();
      // this.form.controls['permanantArea'].reset();
      // this.form.controls['permanantDistrict'].reset();
      // this.form.controls['permanantState'].reset();
      // this.form.controls['permanantCountry'].reset();
      // this.form.controls['permanantResidentType'].reset();
      // this.form.controls['permanantCity'].reset();
    }
  
 } 


 sameToOffice(event:any){
  if(event== true){
    if( this.form.value.currentAddressLine1 && this.form.value.currentAddressLine2 && this.form.value.currentLand && this.form.value.currentPincode  && this.form.value.currentCountry && this.form.value.currentState && this.form.value.currentDistrict && this.form.value.currentCity && this.form.value.currentArea){

      // if(this.currentAddress && this.currentAddress.aid){
      //   let ChangeData={
      //       caseId:this.userDetails.case_id,
      //       address_type:"Office",
      //       checkValue:event== true ? 1:0,
      //       rid:this.currentAddress.aid
      //     }
      //   this._apiService.sameAsCurrentAddress(ChangeData).subscribe((res:any)=>{
      //     if(!res.error){
      //       this.getCaseDetails();
      //     }else{
      //       Swal.fire({
      //         position: 'center',
      //         icon: 'warning',
      //         title: res.message,
      //         showConfirmButton: false,
      //         timer: 1500
      //       })
      //     }
      //   }, (err: HttpErrorResponse) => {
      //   if (err.status === 400) {
      //     Swal.fire({
      //       position: 'center',
      //       icon: 'error',
      //       title: err.error.message,
      //       showConfirmButton: false,
      //       timer: 1500
      //     })
      //   } else {
      //     Swal.fire({
      //       position: 'center',
      //       icon: 'error',
      //       title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
      //       showConfirmButton: false,
      //       timer: 1500
      //     })
      //   }
      // })
      // }else{
        this.office_address_flag =1
        this.form.patchValue({
          // permanantaid : this.permantAddress.aid ? this.permantAddress.aid:'' ,
          // permanantaddressType: "Permanent",
          officeAddressLine1 : this.form.value.currentAddressLine1,
          officeAddressLine2 :this.form.value.currentAddressLine2 ,
          officeLand :this.form.value.currentLand ,
          officePincode :this.form.value.currentPincode ,
          officeArea :this.form.value.currentArea ,
          officeCity :this.form.value.currentCity ,
          officeDistrict :this.form.value.currentDistrict ,
          officeState :this.form.value.currentState ,
          officeCountry :this.form.value.currentCountry ,
          // officeResidentType :this.form.value.currentResidentType
    })
      // }
    }else{
      this.office_address_flag =0;
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: "Please fill all required fields of current address",
        showConfirmButton: false,
        timer: 1500
      })
    }
  }else{
    if(this.currentAddress && this.currentAddress.aid){
      let ChangeData={
          caseId:this.userDetails.case_id,
          address_type:"Office",
          checkValue:event == true ? 1:0,
          rid:this.currentAddress.aid
        }
      this._apiService.sameAsCurrentAddress(ChangeData).subscribe((res:any)=>{
        if(!res.error){
          // this.getCaseDetails();
          this.ngOnInit();
        }else{
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: res.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
    })
    }else{
      this.office_address_flag =0;
      this.form.patchValue({
        permanantaid : null ,
        // permanantaddressType: "Permanent",
        officeAddressLine1 : null,
        officeAddressLine2 :null ,
        officeLand :null ,
        officePincode :null ,
        officeArea :null ,
        officeCity :null ,
        officeDistrict :null ,
        officeState :null ,
        officeCountry :null ,
        officeResidentType :null
  })
    }
  }
  

  // if(this.form.value.currentAddressLine1 && this.form.value.currentAddressLine2 && this.form.value.currentLand && this.form.value.currentPincode && this.form.value.currentResidentType && this.form.value.currentCountry && this.form.value.currentState && this.form.value.currentDistrict && this.form.value.currentCity && this.form.value.currentArea){
  //   if(event.checked){
  //     this.form.patchValue({
  //       // permanantaid : this.permantAddress.aid ? this.permantAddress.aid:'' ,
  //       // permanantaddressType: "Permanent",
  //       officeAddressLine1 : this.form.value.currentAddressLine1,
  //       officeAddressLine2 :this.form.value.currentAddressLine2 ,
  //       officeLand :this.form.value.currentLand ,
  //       officePincode :this.form.value.currentPincode ,
  //       officeArea :this.form.value.currentArea ,
  //       officeCity :this.form.value.currentCity ,
  //       officeDistrict :this.form.value.currentDistrict ,
  //       officeState :this.form.value.currentState ,
  //       officeCountry :this.form.value.currentCountry ,
  //       officeResidentType :this.form.value.currentResidentType
  // })
  //   }else{
  //     // this.form.controls['permanantAddressLine1'].reset();
  //     // this.form.controls['permanantAddressLine2'].reset();
  //     // this.form.controls['permanantLand'].reset();
  //     // this.form.controls['permanantPincode'].reset();
  //     // this.form.controls['permanantArea'].reset();
  //     // this.form.controls['permanantDistrict'].reset();
  //     // this.form.controls['permanantState'].reset();
  //     // this.form.controls['permanantCountry'].reset();
  //     // this.form.controls['permanantResidentType'].reset();
  //     // this.form.controls['permanantCity'].reset();
  //   }

  // }else{
  //   Swal.fire({
  //     position: 'center',
  //     icon: 'warning',
  //     title: "Please fill all required fields of current address",
  //     showConfirmButton: false,
  //     timer: 1500
  //   })

  // }


  // console.log(event.checked);
  
  // return;

 

} 


 keyPress(event: any) {
  const pattern = /[0-9\+\-\ ]/;
  let inputChar = String.fromCharCode(event.charCode);
  if (event.keyCode != 8 && !pattern.test(inputChar)) {
    event.preventDefault();
  }
}
 
 navigateTo(){
  this.router.navigate(['/home'])
}


changeInCurrent(event:any,contr:any){

  


  // this._apiService.saveCurrentAddress().subscribe((res:any)=>{
  //   if(!res.error){
      if(this.form.value.currentAddressLine1 && this.form.value.currentAddressLine2 && this.form.value.currentLand && this.form.value.currentPincode  && this.form.value.currentCountry && this.form.value.currentState && this.form.value.currentDistrict && this.form.value.currentCity && this.form.value.currentArea){
        if(this.permanent_address_flag ==1 && this.permanant_adhaar_address_proof == 0 ){
          // this.sameToCurrent(false)
          this.permanent_address_flag = 0;
    
          this.form.patchValue({
            permanantaid :null ,
            permanantaddressType: "Permanent",
            permanantAddressLine1 : null,
            permanantAddressLine2 : null ,
            permanantLand : null ,
            permanantPincode : null ,
            permanantArea : null ,
            permanantCity : null ,
            permanantDistrict : null ,
            permanantState : null ,
            permanantCountry : null ,
            // permanantResidentType : null
       })
        }
        if(this.office_address_flag ==1){
          // this.sameToOffice(false);
          this.office_address_flag = 0 ;
    
          this.form.patchValue({
            officeaid : null ,
            // permanantaddressType: "Permanent",
            officeAddressLine1 : null,
            officeAddressLine2 :null ,
            officeLand :null ,
            officePincode :null ,
            officeArea :null ,
            officeCity :null ,
            officeDistrict :null ,
            officeState :null ,
            officeCountry :null ,
            officeResidentType :null
      })
        }
      }
    // }else{

    // }
  // })



 
 
}

}
