import { ApiService } from 'src/app/services/api.service';
import { StorageService } from './../../services/storage.service';
import { AuthService } from './../../services/auth.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  otpForm: FormGroup;
  verifyMobile:boolean=false;
  formSumitAttempt: any;
  formSumitAttemptg: any;
  isWebRequest: boolean=false;
  isWebRequest1: boolean=false;
  mobile_no: any;
  textInput:any='password';
  path: string;
  imag: any;
  count: any=0;
  privacyUrl: string;
  selectAdvisoryQueryParameters: any = null;

  constructor(private router: Router, private fb:FormBuilder , private _auth:AuthService , private storageService:StorageService , private spinner: NgxSpinnerService, private _apiService:ApiService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.privacyUrl = environment.terms_n_condition_url;
    this.path = environment.imgUrl+'uploads/dsa_front/';
    if(this.router.url.includes('/onboarding/selectadvisory')){
      this.route.params.subscribe((parameters:any) => {
        this.selectAdvisoryQueryParameters = {
          fullName: this._auth.decryptParameter(parameters.fullName,true),
          emailId: this._auth.decryptParameter(parameters.emailId,true),
          mobileNo: this._auth.decryptParameter(parameters.mobileNo,true)
        } 
        // if (parameters.hasOwnProperty('mobileNo') && parameters.hasOwnProperty('emailId') && parameters.hasOwnProperty('fullName')) {
        //   this.fromDsaApplication = false;
        // } else {
        //   this.fromDsaApplication = true;
        // }
  
      });
    }
    this.loginForm = this.fb.group({
      mobileNo:['',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      agentType:['']
    })
    this.otpForm = this.fb.group({
      OTP:['',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{6}$")]],
      captcha:['',[Validators.required]]
    })

    if(this.selectAdvisoryQueryParameters && this.selectAdvisoryQueryParameters.hasOwnProperty('mobileNo') && this.selectAdvisoryQueryParameters.mobileNo !== null){
      this.loginForm.controls['mobileNo'].patchValue(this.selectAdvisoryQueryParameters.mobileNo);
   }
  }
  
  get f() {
    return this.loginForm.controls;
  }

  get g() {
    return this.otpForm.controls;
  }


  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  isFieldValid(field: any , type:any) {
    if(type == 'mobile'){
      return (
        (!field.valid && field.touched) ||
        (!field.valid && field.untouched && this.formSumitAttempt)
      );
    }else{
      return (
        (!field.valid && field.touched) ||
        (!field.valid && field.untouched && this.formSumitAttemptg)
      );
    }
  }

  doLogin(data:any) {
    if(!data){
      this.formSumitAttempt = true;
      if(this.loginForm.valid){
        this.spinner.show();
          this.isWebRequest = true;
          let phoneNumber;
          if(this.selectAdvisoryQueryParameters && this.selectAdvisoryQueryParameters.hasOwnProperty('mobileNo')) {
            phoneNumber = this.selectAdvisoryQueryParameters.mobileNo;
          } else {
            phoneNumber = this.loginForm.value.mobileNo;
          }
          let data: any = {
            // mobileNo: this.loginForm.value.mobileNo,
            mobileNo: phoneNumber,
            type :"login-otp" ,
            advisoryFlag: this.router.url.includes('/onboarding/selectadvisory') ? true : false,
          }
          // console.log("data",data);
          if(this.selectAdvisoryQueryParameters && this.selectAdvisoryQueryParameters.hasOwnProperty('emailId') && this.selectAdvisoryQueryParameters.hasOwnProperty('fullName')){
            data.fullName = this.selectAdvisoryQueryParameters.fullName;
            data.emailId = this.selectAdvisoryQueryParameters.emailId;
          }
          this.mobile_no = this.loginForm.value.mobileNo ;
          this._auth.login(data).subscribe(
            (response: any) => {
              if(!response.error){
                this.imag = response.captcha_name;
                this.spinner.hide();
                Swal.fire({
                  position: 'center',
                  icon: 'success',
                  // title: response.message + response.OTP,
                  title: response.message,
                  showConfirmButton: false,
                  timer: 1500
                })

                this.verifyMobile =true;
                this.otpForm.controls['OTP'].patchValue(response.OTP);

              }else{
                Swal.fire({
                  position: 'center',
                  icon: 'warning',
                  title: response.message,
                  showConfirmButton: false,
                  timer: 1500
                })
                this.spinner.hide();
              }
            },
            (err: HttpErrorResponse) => {
              this.spinner.hide();
              if(err.message.includes('Http failure response')){
                Swal.fire({
                  position: 'center',
                  icon: 'error',
                  title: "Server not available, Please try after some time.",
                  showConfirmButton: false,
                  timer: 1500
                })
              }else{
                if (err.status === 400) {
                  Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: err.error.message,
                    showConfirmButton: false,
                    timer: 1500
                  })
      
                } else {
                  Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
                    showConfirmButton: false,
                    timer: 1500
                  })
                }
              }


             
              this.isWebRequest = false;
            }
          );
      }
    }else{
      this.formSumitAttemptg = true
      if (this.otpForm.valid) {
        this.spinner.show();
        this.isWebRequest1 = true;



        let data = {
          mobileNo: this.loginForm.value.mobileNo,
          otp:this.otpForm.value.OTP,
          captcha:this.otpForm.value.captcha,
          type :"login-otp" 
        }
        this._auth.OtpVerification(data).subscribe(
          (response: any) => {
            if(!response.error){
              this.storageService.secureStorage.clear();
              this._auth.userData.next(response.data[0]);

              // --------------

              this._auth.token = response.token;
              this._auth.role = response.dsa_role;
              this._auth.name = response.name;
              this._auth.code = response.code;
              this._auth.saveUserinfoToSorage({
                'empname': response.name,
                'version': response.version,
                'role': response.dsa_role,
                'token' : response.token,
                'code':response.code,
              })
              

              // --------------
              this.storageService.secureStorage.setItem('UserDetails',response.data[0]);
              // if(response.ADHAR_ENABLE){
                // this.storageService.secureStorage.setItem('AadharFlag',response.ADHAR_ENABLE)
                this.storageService.secureStorage.setItem('AadharFlag',!response.ADHAR_ENABLE)
                this.storageService.secureStorage.setItem('ITREnableFlag',response.ITR_ENABLE)
                this.storageService.secureStorage.setItem('DirectorCibilConsentFlag', response.DIRECTOR_CIBIL_CONSENT_FLAG)
              // }else{
              //   this.storageService.secureStorage.setItem('AadharFlag',false)
              // }
              
              localStorage.setItem('UserData', response.data[0]);
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: response.message,
                showConfirmButton: false,
                timer: 1500
              })
              this.router.navigate(['/home'])
            }else{
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: response.message,
                showConfirmButton: false,
                timer: 1500
              })
            }
          },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })
            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
                showConfirmButton: false,
                timer: 1500
              })
            }
            this.isWebRequest = false;
          }
        );
      }

    }
  }


  // onSubmit() {
  //   console.log(this.loginForm.controls);
  // }

  // handleSuccess(e:any) {
  //   console.log("ReCaptcha", e);
  // }


  refreshCaptch(){
    this.spinner.show();
    this._apiService.refreshCaptcha({mobileNo:this.loginForm.value.mobileNo}).subscribe((res:any)=>{
      if(!res.error){
  
        this.imag = res.captcha_name;
        this.spinner.hide();
      }else{
        this.spinner.hide();
      }
    },
    (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }

}
