import { environment } from 'src/environments/environment';
import { StorageService } from './../../services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth.service';
import * as moment from 'moment';
import { take } from 'rxjs';

@Component({
  selector: 'app-bank-details',
  templateUrl: './bank-details.component.html',
  styleUrls: ['./bank-details.component.scss']
})
export class BankDetailsComponent implements OnInit {

  form: FormGroup;
  formSumitAttempt: boolean;
  isWebRequest: boolean = false;
  adharData: any;
  userData: any;
  userDetails: any;
  bankurl: any = null;
  bankData: any;
  userInfo: any;
  today: string;
  getYear: any[] = [];
  filterYear: any[] = [];
  textInput = 'password';

  accountList: any[] = [{ title: 'Current', value: 'Current' }, { title: 'Saving', value: 'Saving' }];
  filterAccount: any = []
  Did: any = null;

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, private storageService: StorageService, private spinner: NgxSpinnerService, private _auth: AuthService) { }


  ngOnInit(): void {

    this.userInfo = this.storageService.secureStorage.getItem("userinfo");

    this.adharData = this.storageService.secureStorage.getItem('Aadhar');
    this.userData = this.storageService.secureStorage.getItem('UserDetails');

    this.form = this._formBuilder.group({
      //Office Address
      cancelledCheque: [null],
      ifscCode: ['', [Validators.required, Validators.minLength(11)]],
      accountNumber: ['', [Validators.required]],
      reaccountNumber: ['', [Validators.required]],
      bankName: ['', [Validators.required]],
      bank_branch_name: [''],
      // micrNumber: ['', [Validators.required]],
      yersOfRelationship: [''],
      accountType: ['', [Validators.required, this.requireMatch1.bind(this)]],
      accountHolder: ['', [Validators.required]],
      accountHolderPennyDrop: ['', [Validators.required]],
      // owner1: [''],
      // owner2: [''],

    });

    this.getCaseDetails();

    this.getYears();

    this.form.controls['accountNumber'].valueChanges.subscribe((res) => {

      if (res != this.userDetails.account_number && this.userDetails?.is_bank_acc_validation_check != 0) {
        this.spinner.show();
        let data = {
          case_id: this.userDetails.case_id,
          token: this.userInfo.token
        }

        this._apiService.unverifyPennyDropDetails(data).subscribe((response: any) => {
          if (!response.error) {
            this.spinner.hide();
            this.getCaseDetails()
          } else {
            this.spinner.hide();
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: response.message,
              showConfirmButton: false,
              timer: 1500
            })
          }
        },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
            this.isWebRequest = false;
          })
      }
    })


    this.form.controls['ifscCode'].valueChanges.subscribe((res) => {

      if (res != this.userDetails.ifsc_code && this.userDetails?.is_bank_acc_validation_check != 0) {
        this.spinner.show();
        let data = {
          case_id: this.userDetails.case_id,
          token: this.userInfo.token
        }

        this._apiService.unverifyPennyDropDetails(data).subscribe((response: any) => {
          if (!response.error) {
            this.spinner.hide();
            this.getCaseDetails()
          } else {
            this.spinner.hide();
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: response.message,
              showConfirmButton: false,
              timer: 1500
            })
          }
        },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
            this.isWebRequest = false;
          })
      }



      if (res && res.length == 11) {
        let data = {
          token: this.userInfo.token,
          version: this.userInfo.version,
          ifsc_code: res
        }
        this.spinner.show();

        this._apiService.getIfscData(data).subscribe((res: any) => {
          if (!res.error) {

            this.bankData = res.data

            this.form.patchValue({
              bankName: this.bankData.bank_name,
              bank_branch_name: this.bankData.branch_name
            })
            this.spinner.hide();
          } else {
            this.spinner.hide();
          }
        }, (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
        })
      } else {
        this.form.controls['bankName'].reset();
        this.form.controls['bank_branch_name'].reset();
      }
    })




    this.form.controls['accountType'].valueChanges.subscribe((res: any) => {
      if (res) {
        this.filterAccount = this.accountList.filter((x: any) => x.title.toLowerCase().includes(res.toLowerCase()));
        if (this.filterAccount.length == 0) {
          this.filterAccount = [...this.accountList]
        }
      } else {
        this.filterAccount = [...this.accountList];
      }

    })

    this.form.controls['yersOfRelationship'].valueChanges.subscribe((res: any) => {
      if (!res) {
        this.filterYear = [...this.getYear]
      } else {
        this.filterYear = this.getYear.filter((x: any) => x.value == res);
        if (this.filterYear.length == 0) {
          this.filterYear = [...this.getYear]
        }
      }





    })

  }

  requireMatch(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.getYear && this.getYear.find((ele: any) => ele.value == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }

  requireMatch1(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.accountList && this.accountList.find((ele: any) => ele.value == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }

  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }

  getBankCancellationCheck() {
    this.spinner.show();
    this._apiService.getBanckCancellationCheck({ caseId: this.userDetails.case_id }).subscribe((res: any) => {
      if (!res.error) {


        // console.log("cdscdcdcdsc",res.documentData.did);

        this.spinner.hide();

        this.Did = res.documentData[0] ? res.documentData[0].dms_id : null;

        if (res.documentData.length > 0) {
          this.bankurl = environment.imgUrl + 'uploads/dsa_front/' + res.documentData[0].path
        } else {
          this.bankurl = null
        }

      }
    })


  }

  getYears() {
    this.today = moment().format('YYYY');

    // console.log(this.today);

    for (let i = 0; i < 73; i++) {
      // console.log(i);
      this.getYear.push({ year: parseInt(this.today) - i, value: parseInt(this.today) - i })

      // console.log(parseInt(this.today)-i);

    }

    // for(let i=0 ; i < 49 ; i-- ){
    //   console.log(i);

    //   // this.getYear.push({year: parseInt(this.today)-1 , value: parseInt(this.today)-1})
    // }

  }

  getCaseDetails() {

    this.spinner.show();
    this._apiService.getCaseDetails({
      token: this.userInfo.token,
    }).subscribe((res) => {
      if (!res.error) {
        this.userDetails = res.data[0];
        // console.log("++++++++", this.userDetails)
        this.getBankCancellationCheck();

        this.form.patchValue({
          ifscCode: this.userDetails.ifsc_code, accountNumber: this.userDetails.account_number,
          bankName: this.userDetails.bank_name, bank_branch_name: this.userDetails.bank_branch_name,
          yersOfRelationship: this.userDetails.no_of_years ? parseInt(this.userDetails.no_of_years) : null,
          accountType: this.userDetails.account_type, accountHolder: this.userDetails.panfullname,
          reaccountNumber: this.userDetails.account_number,
          accountHolderPennyDrop: this.userDetails.account_holder_name_penny_drop
        })
        this.spinner.hide();
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })
  }

  uploadDoc(event: any) {
    this.spinner.show();
    const file = event.target.files[0]

    const data = new FormData();
    data.append('file', file)
    data.append('caseId', this.userDetails.case_id)

    this._apiService.uploadImage(data).subscribe((response: any) => {
      if (!response.error) {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400 || err.status === 500) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })


  }

  changeDetect(event: any) {
    if (event) {
      this.getBankCancellationCheck();
    }
  }

  back(): void {
    this.router.navigate(['/home/address-details'])
  }

  changeInIfscCode = (event: any) => {
    console.log("=======")
  }

  next() {

    this.formSumitAttempt = true;
    // console.log(this.form.value)
    if (this.form.valid) {

      if (this.userDetails.is_bank_acc_validation_check != 0) {
        this.isWebRequest = true;

        //To be change on server side
        if (this.bankurl == null && this.userDetails?.is_bank_acc_validation_check != 0 && this.userDetails?.validate_bank_acc_name_check_count < 3) {
          // if (this.bankurl != null) {

          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: 'Upload cancelled cheque document',
            showConfirmButton: false,
            timer: 1500
          })
        }
        else if (this.form.controls['accountNumber'].value != this.form.controls['reaccountNumber'].value) {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: 'a/c number mismatch , Please enter correct a/c.',
            showConfirmButton: false,
            timer: 1500
          })
        }
        else {
          this.spinner.show();
          let data = {
            cancelChequeNo: this.form.value.cancelledCheque,
            ifscCode: this.form.value.ifscCode,
            accountNo: this.form.value.accountNumber,
            bankName: this.form.value.bankName,
            bank_branch_name: this.form.value.bank_branch_name,
            micrCode: '2525652562',
            noofYears: this.form.value.yersOfRelationship,
            accountType: this.form.value.accountType,
            accountHolderName: this.form.value.accountHolder,
            accountHolderPennyDrop: this.form.value.accountHolderPennyDrop,
            owner1: null,
            // owner1: this.form.value.owner1,
            owner2: null,
            // owner2: this.form.value.owner2,
            appId: this.userDetails.case_id,
            stageCount: 5,
            token: this.userInfo.token
          }

          this._apiService.addCaseDetail(data).subscribe((response: any) => {
            if (!response.error) {
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: response.message,
                showConfirmButton: false,
                timer: 1500
              })
              this.router.navigate(['/home/upload-documents'])
            } else {
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: response.message,
                showConfirmButton: false,
                timer: 1500
              })
            }
          },
            (err: HttpErrorResponse) => {
              this.spinner.hide();
              if (err.status === 400) {
                Swal.fire({
                  position: 'center',
                  icon: 'error',
                  title: err.error.message,
                  showConfirmButton: false,
                  timer: 1500
                })

              } else {
                Swal.fire({
                  position: 'center',
                  icon: 'error',
                  title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                  showConfirmButton: false,
                  timer: 1500
                })
              }
              this.isWebRequest = false;
            })
        }
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Please validate the bank account first. ',
          showConfirmButton: false,
          timer: 1500
        })
      }

    }

  }

  cancel() {
    this.router.navigate(['/home'])
  }

  keyPressName(event: any) {
    const pattern = /^[a-zA-Z ]*$/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  navigateTo() {
    this.router.navigate(['/home'])
  }

  downloadDocuments(id: any) {
    this.spinner.show();
    this._apiService.downloadDocuments({ "DID": id }).pipe(
      take(1)
    ).subscribe((resp: any) => {

      // console.log("resp.headers",resp.headers);

      // console.log("resp.headers.get('content-disposition')",resp.headers.get('content-disposition'))



      var contentDisposition = resp.headers.get('content-disposition');
      // console.log("contentDisposition",contentDisposition);
      var filename = contentDisposition.split(';')[1].split('filename')[1].split('=')[1].trim().replaceAll('"', '');

      // console.log("filenamefilenamefilename",filename);


      // const contentDisposition = resp.headers.get('content-disposition');
      // const filename = this.getFilenameFromContentDisposition(contentDisposition);
      let downloadLink = document.createElement('a');
      downloadLink.href = window.URL.createObjectURL(resp.body);
      downloadLink.setAttribute('download', filename);
      document.body.appendChild(downloadLink);
      downloadLink.click();
      downloadLink.remove();
      this.spinner.hide();
    },
      (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
        this.isWebRequest = false;
      })
  }

  onPressValidateBankAccout = () => {
    if (!this.form.value.accountNumber == null || this.form.value.ifscCode == null || this.form.value.accountHolder == null) {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: 'Please enter Account No, IFSC Code, Account Holder Name.',
        showConfirmButton: false,
        timer: 1500
      })
    } else if (this.form.controls['accountNumber'].value != this.form.controls['reaccountNumber'].value) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'a/c number mismatch , Please enter correct a/c.',
        showConfirmButton: false,
        timer: 1500
      })
    } else {
      this.spinner.show();
      let data = {
        bank_account_no: this.form.value.accountNumber,
        bank_ifsc_code: this.form.value.ifscCode,
        case_id: this.userDetails.case_id,
        account_holder_name: this.form.value.accountHolder,
        token: this.userInfo.token
      }

      this._apiService.validateBankAcc(data).subscribe((response: any) => {
        console.log("====", response)
        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })

          this.getCaseDetails()
        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        })
    }



  }


  // private getFilenameFromContentDisposition(contentDisposition: string): string {
  //   const regex = /filename=(?<filename>[^,;]+);/g;
  //   const match = regex.exec(contentDisposition);
  //   const filename = match!.groups!.filename;
  //   return filename;
  // }

}
