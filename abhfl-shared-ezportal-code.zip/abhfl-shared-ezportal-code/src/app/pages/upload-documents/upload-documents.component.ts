import { environment } from 'src/environments/environment';
import { StorageService } from 'src/app/services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2'
import { HttpErrorResponse } from '@angular/common/http';
import { ApplicantPhotoComponent } from 'src/app/components/applicant-photo/applicant-photo.component';
import { runInThisContext } from 'vm';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth.service';
import { take } from 'rxjs';

@Component({
  selector: 'app-upload-documents',
  templateUrl: './upload-documents.component.html',
  styleUrls: ['./upload-documents.component.scss']
})
export class UploadDocumentsComponent implements OnInit {
  @ViewChild(ApplicantPhotoComponent, {static : true}) child : ApplicantPhotoComponent;
  userDetails: any;
  userData: any;
  DocList: any;
  flag: any;
  path: string;
  DocList1: any=[];
  docValue: any='Aadhar card (Resi only)';
  validateUpload: boolean=false;
  DocUserList: any = [];
  userDoc: any=[];
  directorDoc: any = [];
  userInfo: any;
  aadharFlag: any;
  selectedOption: any='Aadhar card (Resi only)';
  addressList:any=[];
  current_adhaar_address_proof: any;
  permanant_adhaar_address_proof: any;
  current_address_flag: any;
  permanent_address_flag: any;
  office_address_flag: any;
  aadharDoc: any =[];
  cFile: any;
  oFile: any;
  pFile: any;
  aadharDid: any;
  selectedOption2: any='Aadhar card (Resi only)';
  selectedOption3: any='Aadhar card (Resi only)';

  constructor(private router: Router,private _apiService:ApiService, private storageService:StorageService,private spinner: NgxSpinnerService, private _auth:AuthService) { }

  ngOnInit(): void {
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    this.aadharFlag = this.storageService.secureStorage.getItem('AadharFlag');
    this.getCaseDetails();
    this.path = environment.imgUrl +'uploads/dsa_front/';
    // this.addressList =[

    //   {name:'Office Address' , flag:false , isAddressOnCurrent:true , isUpload:true ,kycFlag:false},
    //   {name:'Current Address', flag:true, isAddressOnCurrent:true, isUpload:true, kycFlag:true},
    //   {name:'Permanent Address', flag:false, isAddressOnCurrent:true,isUpload:true ,kycFlag:false}
    // ]
  }

  // changeDoc(event:any){
  //   this.selectedOption = event.value
  //   this.docValue = event.value
  // }
  changeDoc(event:any,addressType:any){
    if(addressType=='Office'){
      this.selectedOption2 = event.value
      this.docValue = event.value
    }else if(addressType=='Current'){
      this.selectedOption = event.value
      this.docValue = event.value
    }else if(addressType=='Permanent'){
      this.selectedOption3 = event.value
      this.docValue = event.value
    }
  }


  getCaseDocType(){
    this.spinner.show();
    // caseId:this.userDetails.case_id ,
    this._apiService.getCaseDocType({
      token:this.userInfo.token,
      caseId:this.userDetails.case_id
    }).subscribe((res:any)=>{
      if(!res.error){


        // this.current_adhaar_address_proof = this.userDetails.current_adhaar_address_proof;
        // this.permanant_adhaar_address_proof = this.userDetails.permanent_adhaar_address_proof;

        // this.current_address_flag = this.userDetails.current_address_flag;
        // this.permanent_address_flag = this.userDetails.permanent_address_flag;
        // this.office_address_flag = this.userDetails.office_address_flag;

        // console.log(this.current_adhaar_address_proof,this.permanant_adhaar_address_proof,this.current_address_flag,this.permanent_address_flag,this.office_address_flag);





        this.DocList=[];
        this.DocList1=[];
        this.DocUserList=[];
        this.directorDoc=[];
        this.userDoc=[];
        this.aadharDoc=[];

        this.flag = res.address_flag
        this.DocList = res.data[0].document;
        this.DocUserList = res.data[0].document[0].file;
        this.cFile='';
        this.oFile='';
        this.pFile='';
        this.aadharDid='';


        if(this.DocUserList.length>0){

          this.DocUserList.forEach((element:any) => {
            if(element.Designation == 'Applicant'){
              this.userDoc.push(element)
            }else{
              if(res.data[0].constitution_type !='Individual'){
                this.directorDoc.push(element)
              }
            }
          });
        }

        console.log("++++++",this.userDoc)


        this.DocList = this.DocList.filter((element:any)=> element.document_type !='GST' || (element.document_type =='GST' && res.data[0].gst_verify_flag ==1?true:false));




        this.DocList.forEach((item:any, index:any) => {
          if(item.document_type != 'Aadhar Photo'  || (item.document_type == 'Address Proof' && item.file.length > 0) )  {
            if(item.document_type != 'Address Proof'){
              this.DocList1.push(item);
            }else{
              this.aadharDoc.push(item);
              this.aadharDid = this.aadharDoc[0].did;
            }
          }
        });


        this.aadharDoc[0].file.forEach((element:any) => {
          if(element.address_type == 'Current'){
            this.cFile = element;
          }else if(element.address_type =='Office'){
            this.oFile = element;
          }else if(element.address_type =='Permanent'){
            this.pFile = element;
          }
        });



        this.addressList =[
          {name:'Office Address' , flag:false , isAddressOnCurrent:this.office_address_flag ==1 ? true:false , isUpload: this.oFile , kycFlag:false,addressType:'Office'},

          {name:'Current Address', flag:true, isAddressOnCurrent: false, isUpload:this.cFile , kycFlag: this.current_adhaar_address_proof ==1 ?true:false,addressType:'Current'},

          {name:'Permanent Address', flag:false, isAddressOnCurrent:this.permanent_address_flag == 1 ? true:false,isUpload:this.pFile ,kycFlag:this.permanant_adhaar_address_proof==1 ? true:false,addressType:'Permanent'}
        ]



        // this.addressList =[
        //   {name:'Office Address' , flag:false , isAddressOnCurrent:this.office_address_flag ==1 ? true:false , isUpload: this.oFile , kycFlag:false,addressType:'Office'},
        //   {name:'Current Address', flag:true, isAddressOnCurrent: false, isUpload:this.cFile , kycFlag: false,addressType:'Current'},
        //   {name:'Permanent Address', flag:false, isAddressOnCurrent:this.permanent_address_flag == 1 ? true:false,isUpload:this.pFile ,kycFlag:true,addressType:'Permanent'}
        // ]




        // console.log("this.DocList1this.DocList1this.DocList1",this.DocList1);
        this.spinner.hide();

        // res.data[0].document[0].photo.forEach((element:any) => {
        //   this.child.callMe(this.path + element.fileName);
        // });


      }else{
        this.spinner.hide();
      }
    })
  }

  getCaseDetails(){
    this.userDetails = [];
    this.spinner.show();
    this._apiService.getCaseDetails({token:this.userInfo.token}).subscribe((res)=>{
      if(!res.error){
        this.userDetails = res.data[0];

        console.log("++++++",this.userDetails)
        this.spinner.hide();
        this.current_adhaar_address_proof = this.userDetails.current_adhaar_address_proof;
        this.permanant_adhaar_address_proof = this.userDetails.permanent_adhaar_address_proof;

        this.current_address_flag = this.userDetails.current_address_flag;
        this.permanent_address_flag = this.userDetails.permanent_address_flag;
        this.office_address_flag = this.userDetails.office_address_flag;
        this.getCaseDocType();
      }

   },(err: HttpErrorResponse) =>
    {
      this.spinner.hide();
    if (err.status === 400) {
      Swal.fire({
        position: 'center',
        icon: 'success',
        title: err.error.message,
        showConfirmButton: false,
        timer: 1500
      })
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
        showConfirmButton: false,
        timer: 1500
      })
    }
  })
  }


  changeDetect(event:any){
    if(event){
      this.getCaseDetails();
      // this.getCaseDocType();
    }

  }



  uploadDoc(event:any ,docName:any){
    this.spinner.show();
    const file = event.target.files[0]

    const data = new FormData();
    data.append(docName,file)
    data.append('caseId',this.userDetails.caseId);


    this._apiService.uploadImage(data).subscribe((response:any)=>{
      if(!response.error){
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }else{
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    },(err: HttpErrorResponse) =>
      {
        this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
    })


  }







  back(): void {
    this.router.navigate(['/home/bank-details'])
  }

  next() {

    this.validateUpload = false ;


    // this.addressList.forEach((element:any) => {
    //   if(!element.isAddressOnCurrent){
    //     if(!element.isUpload){
    //       this.validateUpload = true
    //       return;
    //     }
    //   }
    // });


    this.addressList.forEach((element:any) => {
      if(!element.kycFlag){
        if(!element.isAddressOnCurrent && !element.isUpload){
          this.validateUpload = true
          return;
        }
      }
    });


    this.DocList1.forEach((element:any,i:any) => {
      console.log("*****",element)
      // if(i == 0){
      if(element.document_type =='Address Proof'){
        if(!this.flag && this.flag.length == 0){
          this.validateUpload = true
          return;
        }else{
          return;
        }
      }else if(element.document_type !='Others'){
        if(element.file.length == 0){
          this.validateUpload = true ;
          return;
        }
      }

    });



    if(this.validateUpload){

      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: "Upload all documents",
        showConfirmButton: false,
        timer: 1500
      })
      return;

    }else{
      this.spinner.show();
      let data= {
        appId:this.userDetails.case_id,
        stageCount:6,
        token:this.userInfo.token,
        // version:this.userInfo.version,
        // consentCheck: true
       }


      this._apiService.addCaseDetail(data).subscribe((response:any)=>{
        if(!response.error){
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.router.navigate(['/home/reference-details'])
        }else{
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
      (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
            showConfirmButton: false,
            timer: 1500
          })
        }
      })







    }




    // this.router.navigate(['/home/code-of-conduct'])

  }


  deleteDocument(id:any){
    this.spinner.show();
    this._apiService.deleteDocuments({"did":id}).subscribe((res:any)=>{
      if(!res.error){
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
        this.ngOnInit();

      }else{
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    },
    (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
    })
  }

  navigateTo(){
    this.router.navigate(['/home'])
  }

  cancel() {
    this.router.navigate(['/home'])
  }



  downloadDocuments(id:any){
    this.spinner.show();
    this._apiService.downloadDocuments({"DID":id}).pipe(
      take(1)
  ).subscribe((resp:any) => {


    // const contentDisposition = resp.headers.get('content-disposition');
    // const filename = this.getFilenameFromContentDisposition(contentDisposition);

    // console.log("resp.headers",resp.headers);

    // console.log("resp.headers.get('content-disposition')",resp.headers.get('content-disposition'))



    var contentDisposition = resp.headers.get('content-disposition');
    // console.log("contentDisposition",contentDisposition);

    var filename = contentDisposition.split(';')[1].split('filename')[1].split('=')[1].trim().replaceAll('"', '');

    // console.log("filename",filename)


      let downloadLink = document.createElement('a');
      downloadLink.href = window.URL.createObjectURL(resp.body);
      downloadLink.setAttribute('download',filename);
      document.body.appendChild(downloadLink);
      downloadLink.click();
      downloadLink.remove();
      this.spinner.hide();
  }, (err: HttpErrorResponse | any) => {

    console.log(err,err['DID'],err.response);
    this.spinner.hide();
    if (err.status === 400) {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: err.error.message,
        showConfirmButton: false,
        timer: 1500
      })

    }else if (err.status === 422) {



      // Swal.fire({
      //   position: 'center',
      //   icon: 'error',
      //   title: err['DID'][0],
      //   showConfirmButton: false,
      //   timer: 1500
      // })

    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
        showConfirmButton: false,
        timer: 1500
      })
    }
  }, () => console.log('HTTP request completed.'));
  }


  // private getFilenameFromContentDisposition(contentDisposition: string): string {
  //   const regex = /filename=(?<filename>[^,;]+);/g;
  //   const match = regex.exec(contentDisposition);
  //   const filename = match!.groups!.filename;
  //   return filename;
  // }

}
