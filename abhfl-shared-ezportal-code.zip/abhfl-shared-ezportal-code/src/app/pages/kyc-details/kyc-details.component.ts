import { WaitingAadharComponent } from './../../modals/waiting-aadhar/waiting-aadhar.component';
import { environment } from 'src/environments/environment';
import { AdhaarCurrentAddressComponent } from './../../modals/adhaar-current-address/adhaar-current-address.component';
import { ApplicantPhotoComponent } from './../../components/applicant-photo/applicant-photo.component';
import { StorageService } from './../../services/storage.service';
import { MatDialog } from '@angular/material/dialog';
import { ConsentComponent } from 'src/app/modals/consent/consent.component';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { OtpComponent } from 'src/app/modals/otp/otp.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth.service';
import { threadId } from 'worker_threads';
import { take } from 'rxjs';


@Component({
  selector: 'app-kyc-details',
  templateUrl: './kyc-details.component.html',
  styleUrls: ['./kyc-details.component.scss']
})
export class KycDetailsComponent implements OnInit {
  @ViewChild(ApplicantPhotoComponent, { static: true }) child: ApplicantPhotoComponent;
  form: FormGroup;
  formSumitAttempt: boolean;
  isWebRequest: boolean = false;
  last: any;
  // checkBox: { name: string; value: string; }[];
  userDetails: any;
  userData: any;

  // dd='uploads/dsa_front/6321a7dbddfed.png';
  image: any;
  panVerify: boolean;
  adharVerify: boolean;
  adharImage: any;
  // checkBox: { name: string; value: string; ind: number; }[];
  check: any;
  checkBox: { name: string; value: any; ind: number; contr: string; }[];
  otherphoto: any;
  gstVerify: boolean;
  itrVerify: any;
  fullName: any;
  caseId: any;
  aadharNo: any;
  userInfo: any;
  aadharFlag: any;
  itrEnableFlag: any;
  otherPhoto: any;
  otherPhotoErrMsg: any;
  Did: any;
  gstUrl: any;
  fileName: any;
  docId: any;
  count: number;

  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, public dialog: MatDialog, private storageService: StorageService, private route: ActivatedRoute,  private spinner: NgxSpinnerService, private _auth:AuthService) { }


  ngOnInit(): void {

    this.userInfo = this.storageService.secureStorage.getItem("userinfo");

    this.userData = this.storageService.secureStorage.getItem('UserDetails');

    this.aadharFlag = this.storageService.secureStorage.getItem('AadharFlag');

    this.itrEnableFlag = this.storageService.secureStorage.getItem('ITREnableFlag');

    // console.log("**********************",this.itrEnableFlag);


    // console.log("this.aadharFlagthis.aadharFlag",this.aadharFlag);

    // this.aadharNo = this.storageService.secureStorage.getItem('aadharNo');

    this.caseId = this.storageService.secureStorage.getItem('CaseId')

    this.getCaseDetails();

    this.route.params.subscribe(params => {
      let isAadharVerification = params['isAadharVerification'];

      if(isAadharVerification){
        this.route.queryParams.subscribe(params => {
          let requestId = params['requestId'];
          this.openAadharVerificationModal(requestId,this.caseId,this.aadharNo);
        })
      }
    }
    )

    this.checkBox = [
      { name: 'GST', value: 'Yes', ind: 0, contr: 'gstNumber' },
      // { name: 'TRIN', value: 'Yes', ind: 1, contr: 'trinNo' },
      { name: 'MSME', value: 'Yes', ind: 2, contr: 'msmeNo' },
      // { name: 'legal', value: 'Yes', ind: 3, contr: 'legalDescription' },
      // { name: 'Adityabirla', value: 'Yes', ind: 4, contr: 'legalDescription' },
      { name: 'ITR', value: 'No', ind: 5, contr: 'ITRVerify' }
    ]
    // this.getCheckbox();

    this.form = this._formBuilder.group({
      // panCard: ['', [Validators.required, Validators.pattern(/([a-z0-9\-\_\.]+\@[\w\d\-\_]+\.[\w]+)|([\d]+)/ig)]],
      panCard: ['', [Validators.required, Validators.pattern('[A-Z]{5}[0-9]{4}[A-Z]{1}')]],
      ckycNumber: [''],
      adharCard: [''],
      gstNumber: ['', [Validators.required, Validators.minLength(15), Validators.minLength(15)]],
      // trinNo: ['', [Validators.required]],
      msmeNo: ['', [Validators.required, Validators.maxLength(20)]],
      // legalDescription: ['', [Validators.required]],
      // applicantCompany:['',[Validators.required]],
      // applicantRelation:['',[Validators.required]],
      // applicantLocation:['',[Validators.required]],
      // applicantDate:['',[Validators.required]],
      // applicantPlace:['',[Validators.required]]

      // company_date:['',[Validators.required]]
    });
    
    this.form.controls['panCard'].valueChanges.subscribe((res:any)=>{
      if(res == this.userDetails.pan_number || !this.panVerify){

      }else{
        this.changePANFlag();
      }
    })

    if(this.aadharFlag){
      this.form.removeControl('adharCard');
    }

  }

  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }

  ngAfterViewInit() {

  }

  callMyChild(dataImg: any) {
    // console.log("this.userDetails",dataImg,this.userDetails,dataImg);

    // console.log("path", dataImg,this.userDetails,dataImg);


    // this.child.callMe(dataImg);
  }

  getCaseDetails() {
    this.spinner.show();
    this._apiService.getCaseDetails({  token:this.userInfo.token
      }).subscribe((res) => {
      if (!res.error) {
        this.userDetails = res.data[0];
        // console.log("this.userDetailsthis.userDetails",this.userDetails);

        // this.storageService.secureStorage.setItem('CaseID',this.userDetails.case_id)

        // let img = this.userDetails.other_adhar_file_name;

        // if(!this.aadharFlag && this.userDetails.adhar_file_path){

        //   this.callMyChild(this.userDetails.adhar_file_path + img);
        // }
        // this.adharImage = environment.imgUrl + this.userDetails.adhar_file_path + this.userDetails.adhar_file_name;

        if (this.userDetails.other_adhar_file_name) {
          this.otherphoto = true;
        } else {
          this.otherphoto = false;
        }

        if (this.userDetails.pan_verify_flag == 0) {
          this.panVerify = false;
        } else {
          this.panVerify = true;
        }

        if (this.userDetails.adhar_verify_flag == 0) {
          this.adharVerify = false
        } else {
          this.adharVerify = true
        }

        if (this.userDetails.gst_verify_flag == 0) {
    
          this.form.controls['gstNumber'].reset();
          this.form.controls['gstNumber'].clearValidators();
          this.form.controls['gstNumber'].updateValueAndValidity();
          this.gstVerify = false;
        } else {
          
          this.form.controls['gstNumber'].addValidators([Validators.required, Validators.maxLength(20)]);
          this.form.controls['gstNumber'].updateValueAndValidity();
          this.gstVerify = true;
          this.getGstDoc();
        }
    
        if(this.userDetails.msme_applicable == 'Yes'){
          this.form.controls['msmeNo'].addValidators([Validators.required, Validators.maxLength(20)]);
          this.form.controls['msmeNo'].updateValueAndValidity();
        } else {
          this.form.controls['msmeNo'].reset();
          this.form.controls['msmeNo'].clearValidators();
          this.form.controls['msmeNo'].updateValueAndValidity();
        }
        this.spinner.hide();


        //Hide for future

        if (this.userDetails.itr_verify_flag == 0) {
          this.itrVerify = false;
        } else {
          this.itrVerify = true;
        }
      //Hide for future


        this.checkBox = [
          { name: 'GST', value: this.userDetails.gst_applicable == null ? 'Yes' : this.userDetails.gst_applicable, ind: 0, contr: 'gstNumber' },
          // { name: 'TRIN', value: this.userDetails.trin_applicable == null ? 'Yes' : this.userDetails.trin_applicable, ind: 1, contr: 'trinNo' },
          { name: 'MSME', value: this.userDetails.msme_applicable == null ? 'Yes' : this.userDetails.msme_applicable, ind: 2, contr: 'msmeNo' },
          // {name:'GST' , value: this.userDetails.gst_applicable ? this.userDetails.gst_applicable == 'Yes'? 'No': 'Yes' : 'Yes'    },
          // {name:'TRIN' , value:this.userDetails.trin_applicable ? this.userDetails.trin_applicable == 'Yes'? 'No': 'Yes' : 'Yes' },
          // {name:'MSME' , value:this.userDetails.msme_applicable ? this.userDetails.msme_applicable == 'Yes'? 'No': 'Yes' : 'Yes' },
          // { name: 'legal', value: this.userDetails.legal_option ? this.userDetails.legal_option == 'Yes' ? 'Yes' : 'No' : 'No', ind: 3, contr: 'legalDescription' },
          // { name: 'legal', value: this.userDetails.legal_option == null ?  'Yes' :this.userDetails.legal_option , ind: 3, contr: 'legalDescription' },
          // { name: 'AdityaBirla', value: this.userDetails.aditya_birla_consent == null ?  'Yes' :this.userDetails.aditya_birla_consent== 1?'Yes':'No' , ind: 4, contr: 'AdityaBirla' },
          { name: 'ITR', value: this.itrVerify, ind: 5, contr: 'ITRVerify' }
        ]



        this.checkBox.forEach((ele: any) => {
          if (ele.value == 'Yes') {
            // if (ele.name == 'legal' ) {
            //   this.form.controls[ele.contr].addValidators([Validators.required])
            // } 
            if (ele.name == 'GST') {
              this.form.controls[ele.contr].addValidators([Validators.required, Validators.minLength(15)])
            } else if (ele.name == 'MSME') {
              this.form.controls[ele.contr].addValidators([Validators.required,Validators.maxLength(20)])
            }
            // else if(ele.name == 'TRIN'){
            //   this.form.controls[ele.contr].addValidators([Validators.required]);
            // }
            // else if(ele.name == 'AdityaBirla'){
            //   // this.form.addControl('applicantCompany', new FormControl('', Validators.required));
            //   // this.form.addControl('applicantRelation', new FormControl('', Validators.required));
            //   // this.form.addControl('applicantLocation', new FormControl('', Validators.required));
            //   // this.form.addControl('applicantDate', new FormControl('', Validators.required));
            //   // this.form.addControl('applicantPlace', new FormControl('', Validators.required));
            //   // this.form.updateValueAndValidity();
            // }
          } 
          // else {

          //   // if( ele.name == 'AdityaBirla'){
          //   //   // this.form.removeControl('applicantCompany');
          //   //   // this.form.removeControl('applicantRelation');
          //   //   // this.form.removeControl('applicantLocation');
          //   //   // this.form.removeControl('applicantDate');
          //   //   // this.form.removeControl('applicantPlace');

          //   //   // this.form.updateValueAndValidity();

          //   // }else if (ele.name == 'ITR') {
          //   //   // this.form.controls[ele.contr].addValidators([Validators.required]);
          //   // } else {
          //   //   this.form.controls[ele.contr].clearValidators();
          //   //   this.form.updateValueAndValidity();
          //   // }
          //   // if (ele.name == 'ITR') {
          //   //   // this.form.controls[ele.contr].addValidators([Validators.required]);
          //   // } else {
          //   //   this.form.controls[ele.contr].clearValidators();
          //   //   this.form.updateValueAndValidity();
          //   // }
          // }
        })

        this.form.patchValue({
          panCard: this.userDetails.pan_number,
          adharCard: this.userDetails.adhar_number,
          ckycNumber: this.userDetails.ckyc_number,
          gstNumber: this.userDetails.gst_number,
          // trinNo: this.userDetails.trin_number,
          msmeNo: this.userDetails.msme_number,
          // legalDescription: this.userDetails.legal_description,
          // applicantCompany: this.userDetails.applicant_company,
          // applicantRelation: this.userDetails.applicant_relation,
          // applicantLocation: this.userDetails.applicant_location,
          // applicantDate: this.userDetails.applicant_date,
          // applicantPlace: this.userDetails.applicant_place,
        });
        this.adharImage = environment.imgUrl + this.userDetails.adhar_file_path + this.userDetails.adhar_file_name;
        this.otherPhoto = this.userDetails.other_adhar_file_name ? environment.imgUrl +this.userDetails.other_adhar_file_path + this.userDetails.other_adhar_file_name : null;
        // if(!this.aadharFlag && this.userDetails.adhar_file_path){
          this.callMyChild(this.userDetails.adhar_file_path + this.userDetails.other_adhar_file_name);
        // }

      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
    })
  }

  back(): void {
    this.router.navigate(['/home/basic-details'])
  }

  changePhotoFlag(event: any) {
    this.otherphoto = true;
    if(event){
      this.otherPhotoErrMsg = null
    }
    else{
      this.otherPhotoErrMsg = "Applicant's Photo is required"
    }
    this.spinner.show();
    this._apiService.getCaseDetails({ phoneNo: this.userData.phone_no,token:this.userInfo.token,
      version:this.userInfo.version }).subscribe((res) => {
      if (!res.error) {
        this.spinner.hide();
        this.userDetails = res.data[0];

        let img = this.userDetails.other_adhar_file_name
        this.otherPhoto = environment.imgUrl +this.userDetails.other_adhar_file_path + img;
        // this.callMyChild(this.userDetails.adhar_file_path + img);
        // this.callMyChild(this.userDetails.adhar_file_path + other_adhar_file_name);
      }
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
    })

  }



  changePANFlag() {

    // caseId: this.userDetails.case_id
    this.spinner.show();
    this._apiService.unverifyPAN({ token:this.userInfo.token ,caseId: this.userDetails.case_id }).subscribe((res:any) => {
      if (!res.error) {
        this.spinner.hide();
        // Swal.fire({
        //   position: 'center',
        //   icon: 'success',
        //   title: res.message,
        //   showConfirmButton: false,
        //   timer: 1500
        // })
        // this.getCaseDetails();

        //Hide for future
        // this.itrVerify = false;
        this.panVerify = false;
        this.getCaseDetails();
      }else{
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
    })

  }


  navigateTo(){
    this.router.navigate(['/home'])
  }




  next() {

    this.formSumitAttempt = true;
    if(!this.otherPhoto && (this.userDetails.constitution_type == 'Individual' || this.userDetails.constitution_type == 'Proprietor')){
      this.otherPhotoErrMsg = "Applicant's Photo is required"
      return true;
    }
    else{
      this.otherPhotoErrMsg = null
    }

    if (!this.panVerify) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Verify PAN ',
        showConfirmButton: false,
        timer: 1500
      })
      return;
    }
    else if (!this.adharVerify && !this.aadharFlag && (this.userDetails.constitution_type == 'Individual'||this.userDetails.constitution_type == 'Proprietor')) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Verify  Adhar',
        showConfirmButton: false,
        timer: 1500
      })
      return;
    } else if (!this.gstVerify && this.checkBox[0].value == 'Yes') {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Verify  GST',
        showConfirmButton: false,
        timer: 1500
      })
      return;
    }else if (this.gstVerify && this.checkBox[0].value == 'Yes' && !this.gstUrl) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Upload GST document',
        showConfirmButton: false,
        timer: 1500
      })
      return;
    }
    //Uncomment when ITR need to enable
    else if (!this.itrVerify) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Verify ITR',
        showConfirmButton: false,
        timer: 1500
      })
      return;
    }


    if (this.form.valid) {


      this.isWebRequest = true;
      this.last = this.storageService.secureStorage.getItem('LastParameter');

      if (!this.panVerify) {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: 'Verify PAN ',
          showConfirmButton: false,
          timer: 1500
        })
        return;
      }
      else if (!this.adharVerify && !this.aadharFlag && (this.userDetails.constitution_type == 'Individual'||this.userDetails.constitution_type == 'Proprietor')) {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: 'Verify  Adhar',
          showConfirmButton: false,
          timer: 1500
        })
        return;
      } else if (!this.gstVerify && this.checkBox[0].value == 'Yes') {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: 'Verify  GST',
          showConfirmButton: false,
          timer: 1500
        })
        return;
      }
      //Uncomment when ITR need to enable
      else if (!this.itrVerify) {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: 'Verify ITR',
          showConfirmButton: false,
          timer: 1500
        })
        return;
      }
      else if (!this.otherphoto && !this.aadharFlag && (this.userDetails.constitution_type == 'Individual'||this.userDetails.constitution_type == 'Proprietor')) {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: 'Upload Applicant Photo',
          showConfirmButton: false,
          timer: 1500
        })
        return;
      } {

        this.spinner.show();
        let relationData =null;

        // if(this.checkBox[4].value){
        // relationData={
        //     // applicantCompany : this.form.value.applicantCompany,
        //     // applicantRelation: this.form.value.applicantRelation,
        //     // applicantLocation : this.form.value.applicantLocation,
        //     // applicantDate:this.form.value.applicantDate,
        //     // applicantPlace:this.form.value.applicantPlace,


        //   }


        // }



        let data = {
          appId: this.userDetails.case_id,
          panNumber: this.form.value.panCard,
          ckycNumber: "51165651651",
          aadharNo: this.form.value.adharCard,
          gstNumber: this.form.value.gstNumber,
          // trinNo: this.form.value.trinNo,
          msmeNo: this.form.value.msmeNo,
          // legalDescription: this.form.value.legalDescription,
          gstApplicable: this.checkBox[0].value,
          // trinApplicable: this.checkBox[1].value,
          msmeApplicable: this.checkBox[1].value,
          // legalOption: this.checkBox[3].value,
          stageCount: 2,
          token:this.userInfo.token,
          version:this.userInfo.version,
          // ...relationData
          // ... this.last
        }




        this._apiService.addCaseDetail(data).subscribe((response: any) => {
          if (!response.error) {
            this.spinner.hide();
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: response.message,
              showConfirmButton: false,
              timer: 1500
            })
            this.router.navigate(['/home/partner-details'])
          } else {
            this.spinner.hide();
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: response.message,
              showConfirmButton: false,
              timer: 1500
            })
          }
        },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
                showConfirmButton: false,
                timer: 1500
              })
            }

            this.isWebRequest = false;
          })
      }
    }
  }


  cancel() {
    this.router.navigate(['/home'])
  }

  // consentDialog(type: string, title: string, messeage: string, control: string): void {

  //   // if(type == 'TRI'){
  //   //   this.checkBox.find(ele =>{ if(ele.name == type){
  //   //     ele.value = ele.value =='Yes' ? 'No' : 'Yes'
  //   //     if(ele.value == 'No'){
  //   //       this.form.controls[control].reset()
  //   //       this.form.controls[control].clearValidators();
  //   //     }else{
  //   //       this.form.controls[control].addValidators([Validators.required,Validators.pattern(/^\d{12}$/)]);
  //   //     }
  //   //     this.form.controls[control].updateValueAndValidity();
  //   //   }});
  //   // }else{

  //   // if (type == 'ITR' && !this.panVerify) {
  //   //   Swal.fire({
  //   //     position: 'center',
  //   //     icon: 'warning',
  //   //     title: "Verify PAN first",
  //   //     showConfirmButton: false,
  //   //     timer: 1500
  //   //   })
  //   //   return;
  //   // }

  //   ;


  //   this.check = this.checkBox.find(ele => ele.name == type);

  //   if(type=='ITR'){
  //     this.check.value = this.check?'No':'Yes'
  //   }

  //   let itrData
  //   if (this.check.value == 'No') {

  //     if (type == 'ITR') {
  //       itrData = {
  //         email: this.userDetails.email_id,
  //         mobile: this.userDetails.phone_number,
  //         panName: this.fullName ? this.fullName : this.userDetails.panfullname,
  //         pan: this.form.controls['panCard'].value,
  //         caseId: this.userDetails.case_id,
  //         itr_verify_flag: 1
  //       }
  //     }

  //     const dialogRef = this.dialog.open(ConsentComponent, {
  //       disableClose: true,
  //       width: '400px',
  //       data: { title: title, messeage: messeage, itr: itrData ? itrData : '' },
  //     });

  //     dialogRef.afterClosed().subscribe(result => {
  //       if (result) {
  //         this.checkBox.find(ele => {
  //           if (ele.name == type) {
  //             ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //             if (ele.value == 'No') {
  //               this.form.controls[control].reset();
  //               this.form.controls[control].clearValidators();
  //             } else {

  //               if (type == 'legal') {
  //                 this.form.controls[control].addValidators([Validators.required])
  //               } else if (type == 'GST') {
  //                 this.form.controls[control].addValidators([Validators.required, Validators.minLength(15)]);
  //               } else if (ele.name == 'MSME') {
  //                 this.form.controls[control].addValidators([Validators.required, Validators.pattern("[0-9]{12}")]);
  //               }

  //               //  this.form.controls[control].addValidators([Validators.required,Validators.pattern(/^\d{12}$/)]);
  //             }
  //             if (ele.name == 'ITR') {
  //               this.itrVerify = true;
  //             } else {
  //               this.form.controls[control].updateValueAndValidity();
  //             }
  //           }
  //         });

  //       }
  //     });

  //   } else {
  //     this.checkBox.find(ele => {
  //       if (ele.name == type) {
  //         ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //         if (ele.value == 'No') {
  //           this.form.controls[control].reset()
  //           this.form.controls[control].clearValidators();
  //         } else {
  //           if (type == 'legal') {
  //             this.form.controls[control].addValidators([Validators.required])
  //           } else if (type == 'GST') {
  //             this.form.controls[control].addValidators([Validators.required, Validators.minLength(15)]);
  //           } else if (ele.name == 'MSME') {
  //             this.form.controls[control].addValidators([Validators.required, Validators.pattern("[0-9]{12}")]);
  //           }
  //         }
  //         this.form.controls[control].updateValueAndValidity();
  //       }
  //     });
  //   }
  //   // }
  // }

  openOTPDialog(title: string, message: string): void {



  if( this.form.value.adharCard != "") {
    this.spinner.show();
      this._apiService.verifyAadhar({
        name: this.storageService.secureStorage.getItem('Pan').name,
        adharNumber: this.form.value.adharCard
      }).subscribe((response: any) => {
        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })

          this.storageService.secureStorage.setItem('Adhar', response.data.result)
          let data = {
            name: this.storageService.secureStorage.getItem('Pan').name,
            adharNumber: this.form.value.adharCard,
            accessKey: response.data.result.accessKey,
            caseId: this.userDetails.case_id
          }

          // let data ={
          //   name:"Yugal Vasant Patil",
          //   adharNumber:590206438038,
          //   accessKey:"1fb3d32c-8c38-44c4-8f24-50a74d3e246e",
          //   caseId:this.userDetails.case_id
          // }
          const dialogRef = this.dialog.open(OtpComponent, {
            disableClose: true,
            width: '400px',
            data: { title: title, messeage: message, inputValue: data },
          });

          dialogRef.afterClosed().subscribe(result => {
            //success code here
            if (result) {
              this.openCurrentAddressDialog('Set Adhaar as current Address', 'Is Adhaar  your current address ?');
              this.adharVerify = true;
              // this.getCaseDetails();
            }
          });
        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }

      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
              showConfirmButton: false,
              timer: 1500
            })
          }
        })

    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: 'Please enter pan number first.',
        showConfirmButton: false,
        timer: 1500
      })
    }
  }


  openAadharVerificationModal(Id:any,caseId:any,aadharId:any){

    const dialogRef = this.dialog.open(WaitingAadharComponent, {
      disableClose: true,
      width: '400px',
      data: { title: 'Aadhar Verification', messeage: 'Please wait ... We are verifying your identity',  requestId : Id ,caseId : caseId , aadharId :aadharId}

      // , caseId : this.userDetails.case_id
    });

    dialogRef.afterClosed().subscribe(result => {
      //success code here
      if (result) {
        this.openCurrentAddressDialog('Set Adhaar  Address', 'Please select the address');
        this.adharVerify = true;
        // this.getCaseDetails();
      }
    });

  }

//   openOTPDialogWaiting(title: string, message: string): void {

// this.spinner.show();
//     this._apiService.verifyAadhar({token:this.userInfo.token}).subscribe((response: any) => {
//       if (!response.error) {
// this.spinner.hide();

//         Swal.fire({
//           position: 'center',
//           icon: 'success',
//           title: response.message,
//           showConfirmButton: false,
//           timer: 1500
//         })

//         let redirectUrl = response.data.result.link


//         this.storageService.secureStorage.setItem('CaseId',this.userDetails.case_id );
//         // this.storageService.secureStorage.setItem('aadharNo', this.form.controls['adharCard'].value );

//         // this.router.navigate([redirectUrl]);
//         window.location = redirectUrl;

//       } else {
// this.spinner.hide();

//         Swal.fire({
//           position: 'center',
//           icon: 'warning',
//           title: response.message,
//           showConfirmButton: false,
//           timer: 1500
//         })
//       }

//     },
//       (err: HttpErrorResponse) => {
// this.spinner.hide();

//         if (err.status === 400) {
//           Swal.fire({
//             position: 'center',
//             icon: 'error',
//             title: err.error.message,
//             showConfirmButton: false,
//             timer: 1500
//           })

//         } else {
//           Swal.fire({
//             position: 'center',
//             icon: 'error',
//             title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
//             showConfirmButton: false,
//             timer: 1500
//           })
//         }
//       })



//     // if(this.form.controls['adharCard'].status !='INVALID'){
//     //   this._apiService.verifyAadhar(null).subscribe((response: any) => {
//     //     if (!response.error) {
//     //       Swal.fire({
//     //         position: 'center',
//     //         icon: 'success',
//     //         title: response.message,
//     //         showConfirmButton: false,
//     //         timer: 1500
//     //       })

//     //       let redirectUrl = response.data.result.link


//     //       this.storageService.secureStorage.setItem('CaseId',this.userDetails.case_id );
//     //       this.storageService.secureStorage.setItem('aadharNo', this.form.controls['adharCard'].value );

//     //       // this.router.navigate([redirectUrl]);
//     //       window.location = redirectUrl;

//     //     } else {
//     //       Swal.fire({
//     //         position: 'center',
//     //         icon: 'warning',
//     //         title: response.message,
//     //         showConfirmButton: false,
//     //         timer: 1500
//     //       })
//     //     }

//     //   },
//     //     (err: HttpErrorResponse) => {
//     //       if (err.status === 400) {
//     //         Swal.fire({
//     //           position: 'center',
//     //           icon: 'error',
//     //           title: err.error.message,
//     //           showConfirmButton: false,
//     //           timer: 1500
//     //         })

//     //       } else {
//     //         Swal.fire({
//     //           position: 'center',
//     //           icon: 'error',
//     //           title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
//     //           showConfirmButton: false,
//     //           timer: 1500
//     //         })
//     //       }
//     //     })
//     // }else{
//     //   Swal.fire({
//     //     position: 'center',
//     //     icon: 'warning',
//     //     title: "Enter valid aadhar number",
//     //     showConfirmButton: false,
//     //     timer: 1500
//     //   })
//     // }





//   }



  openOTPDialogWaiting(title: string, message: string): void {

    this.spinner.show();
        this._apiService.verifyAadharDigilocker({token:this.userInfo.token , caseId:this.userDetails.case_id }).subscribe((response: any) => {
          if (!response.error) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: response.message,
              showConfirmButton: false,
              timer: 1500
            })

            let redirectUrl = response.link;

            this.storageService.secureStorage.setItem('CaseId',this.userDetails.case_id );
            // window.location = redirectUrl;
            window.open(redirectUrl,'_blank');
            this.count =0
             const myTimer= setInterval((i:any)=>{

                this.count= this.count+1;


                this._apiService.verifyAdharFlagCheck({token:this.userInfo.token , caseId:this.userDetails.case_id,type:"applicant",
                directorId:"" }).subscribe((res:any)=>{
                  if (!res.error){
                    if(res.adhar_flag == 1){
                      clearInterval(myTimer);
                      this.spinner.hide();
                      this.openCurrentAddressDialog('Set Adhaar  Address', 'Please select the address');
                      this.adharVerify = true;
                    }else if(res.adhar_error_Flag == 1){
                      clearInterval(myTimer);
                      this.spinner.hide();
                      Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        title: res.adhar_error,
                        showConfirmButton: false,
                        timer: 1500
                      })
                    }
                  }else{

                  }
                }, (err: HttpErrorResponse) => {

            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
                showConfirmButton: false,
                timer: 1500
              })
            }
          })

                if(this.count > 23){
                  clearInterval(myTimer);
                  Swal.fire({
                    position: 'center',
                    icon: 'warning',
                    title: "Not getting adhar response, please try again or connect with IT team.",
                    showConfirmButton: false,
                    timer: 1500
                  })
                  this.spinner.hide();
                }
              },5000)

          } else {
    this.spinner.hide();

            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: response.message,
              showConfirmButton: false,
              timer: 1500
            })
          }

        },
          (err: HttpErrorResponse) => {
    this.spinner.hide();

            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
                showConfirmButton: false,
                timer: 1500
              })
            }
          })



        // if(this.form.controls['adharCard'].status !='INVALID'){
        //   this._apiService.verifyAadhar(null).subscribe((response: any) => {
        //     if (!response.error) {
        //       Swal.fire({
        //         position: 'center',
        //         icon: 'success',
        //         title: response.message,
        //         showConfirmButton: false,
        //         timer: 1500
        //       })

        //       let redirectUrl = response.data.result.link


        //       this.storageService.secureStorage.setItem('CaseId',this.userDetails.case_id );
        //       this.storageService.secureStorage.setItem('aadharNo', this.form.controls['adharCard'].value );

        //       // this.router.navigate([redirectUrl]);
        //       window.location = redirectUrl;

        //     } else {
        //       Swal.fire({
        //         position: 'center',
        //         icon: 'warning',
        //         title: response.message,
        //         showConfirmButton: false,
        //         timer: 1500
        //       })
        //     }

        //   },
        //     (err: HttpErrorResponse) => {
        //       if (err.status === 400) {
        //         Swal.fire({
        //           position: 'center',
        //           icon: 'error',
        //           title: err.error.message,
        //           showConfirmButton: false,
        //           timer: 1500
        //         })

        //       } else {
        //         Swal.fire({
        //           position: 'center',
        //           icon: 'error',
        //           title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
        //           showConfirmButton: false,
        //           timer: 1500
        //         })
        //       }
        //     })
        // }else{
        //   Swal.fire({
        //     position: 'center',
        //     icon: 'warning',
        //     title: "Enter valid aadhar number",
        //     showConfirmButton: false,
        //     timer: 1500
        //   })
        // }





      }









  openCurrentAddressDialog(title: string, message: string): void {

    const dialogRef = this.dialog.open(AdhaarCurrentAddressComponent, {
      disableClose: true,
      width: '400px',
      data: { title: title, messeage: message, inputValue: this.userDetails.case_id },
    });

    dialogRef.afterClosed().subscribe(result => {
      //success code here

      // this.router.navigate(['/home/kyc-details'])
      this.getCaseDetails();
      // if(result){
      //   this.getCaseDetails();
      // }
    });




    // if (this.form.value.adharCard != "") {
    //   this._apiService.verifyAadhar({ name:this.storageService.secureStorage.getItem('Pan').name,
    //   adharNumber:this.form.value.adharCard}).subscribe((response:any)=>{
    //     if(!response.error){
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'success',
    //         title: response.message,
    //         showConfirmButton: false,
    //         timer: 1500
    //       })


    //       this.storageService.secureStorage.setItem('Adhar',response.data.result)
    //       // let data ={
    //       //   name:this.storageService.secureStorage.getItem('Pan').name,
    //       //   adharNumber:this.form.value.adharCard,
    //       //   accessKey:response.data.result.accessKey,
    //       //   caseId:this.userDetails.case_id
    //       // }

    //       let data ={
    //         name:"Yugal Vasant Patil",
    //         adharNumber:590206438038,
    //         accessKey:"1fb3d32c-8c38-44c4-8f24-50a74d3e246e",
    //         caseId:this.userDetails.case_id
    //       }
    //       const dialogRef = this.dialog.open(OtpComponent, {
    //         disableClose: true,
    //         width: '400px',
    //         data: { title: title, messeage: message,inputValue:data },
    //       });

    //       dialogRef.afterClosed().subscribe(result => {
    //         //success code here
    //         if(result){
    //           this.getCaseDetails();
    //         }
    //       });
    //     }else{
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'warning',
    //         title: response.message,
    //         showConfirmButton: false,
    //         timer: 1500
    //       })
    //     }

    //   },(err: HttpErrorResponse) => {
    //     if (err.status === 400) {
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'error',
    //         title: err.error.message,
    //         showConfirmButton: false,
    //         timer: 1500
    //       })

    //     } else {
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'error',
    //         title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
    //         showConfirmButton: false,
    //         timer: 1500
    //       })
    //     }
    // })

    // } else {
    //   Swal.fire({
    //     position: 'center',
    //     icon: 'error',
    //     title: 'Please enter pan number first.',
    //     showConfirmButton: false,
    //     timer: 1500
    //   })
    // }



  }







  onPressVerifyPanCard(): void {

    if (this.form.controls['panCard'].status != 'INVALID') {
      // console.log("***", this.form.value.panCard);
      this.spinner.show();
      this._apiService.VerifyPan({token:this.userInfo.token, panNumber: this.form.value.panCard, caseId: this.userDetails.case_id }).subscribe((response: any) => {
        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.storageService.secureStorage.setItem('Pan', response.data.result);

          this.panVerify = true;
          this.userDetails.panfullname = response.data.result.name;
          this.fullName = response.data.result.name;

          // this.getCaseDetails();
        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      }, (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
            showConfirmButton: false,
            timer: 1500
          })
        }
      })



    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: 'Please enter correct pan number first.',
        showConfirmButton: false,
        timer: 1500
      })
    }
  }
  // BRKPG5687D


  veifyGst() {
    if (this.form.controls['gstNumber'].status != 'INVALID') {
      // console.log("***", this.form.value.panCard);
      if(!this.panVerify){
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: "Please verify PAN first",
          showConfirmButton: false,
          timer: 1500
        })
        return;
      }

      this.spinner.show();
      this._apiService.verifyGst({
        gstNumber: this.form.value.gstNumber,
        token:this.userInfo.token,
        version:this.userInfo.version,
        caseId: this.userDetails.case_id, gstApplicable: 'Yes'
      }).subscribe((response: any) => {
        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.storageService.secureStorage.setItem('Gst', response.data.result);
          this.checkBox[0].value = 'Yes';
          this.gstVerify = true;

          // this.getCaseDetails();
        } else {
          this.spinner.hide();
          // this.checkBox[0].value = 'No';
          // this.gstVerify = false;
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
              showConfirmButton: false,
              timer: 1500
            })
          }
        })
    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: 'Please enter correct gst number.',
        showConfirmButton: false,
        timer: 1500
      })
    }
  }



  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }





  // consentDialog(type: string, title: string, messeage: string, control: string): void {


  //   // if(type =='GST' && !this.panVerify){
  //   //   Swal.fire({
  //   //     position: 'center',
  //   //     icon: 'warning',
  //   //     title: "Please verify PAN first",
  //   //     showConfirmButton: false,
  //   //     timer: 1500
  //   //   })
  //   //   return;
  //   // }


  //   this.check = this.checkBox.find(ele => ele.name == type);

  //   if(type =='GST' || type =='TRIN'  || type =='MSME' ){



  //     if(this.check.value == 'Yes'){

  //       const dialogRef = this.dialog.open(ConsentComponent, {
  //         disableClose: true,
  //         width: '400px',
  //         data: { title: title, messeage: messeage },
  //       });

  //       dialogRef.afterClosed().subscribe(result => {
  //         if (result) {



  //           this.checkBox.find(ele => {
  //             if (ele.name == type) {
  //               ele.value = ele.value == 'Yes' ? 'No' : 'Yes';
  //               if (ele.value == 'No') {
  //                 let consentData ={
  //                   caseId: this.userDetails.case_id,
  //                   consentType: type,
  //                   option:ele.value,
  //                   value:"",
  //                   checked:ele.value =='Yes' ? 1:0,
  //                   token:this.userInfo.token,
  //                   version:this.userInfo.version}
  //                 this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                     if(!res.error){
  //                       this.form.controls[control].reset();
  //                       this.form.controls[control].clearValidators();
  //                       this.form.controls[control].updateValueAndValidity();
  //                     }
  //                 })

  //               } else {

  //                 let consentData ={
  //                   caseId: this.userDetails.case_id,
  //                   consentType: type,
  //                   option:ele.value,
  //                   value:"",
  //                   checked:ele.value =='Yes' ? 1:0,
  //                   token:this.userInfo.token,
  //                   version:this.userInfo.version}

  //                   if (type == 'GST') {
  //                     this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                       if(!res.error){
  //                         this.form.controls[control].addValidators([Validators.required, Validators.minLength(15)]);
  //                         this.form.controls[control].updateValueAndValidity();
  //                       }
  //                   })

  //                 } else if (ele.name == 'MSME') {
  //                   this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                     if(!res.error){
  //                       this.form.controls[control].addValidators([Validators.required, Validators.maxLength(20)]);
  //                       this.form.controls[control].updateValueAndValidity();
  //                     }
  //                 })
  //                 } else if(ele.name == 'TRIN'){

  //                   this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                     if(!res.error){
  //                       this.form.controls[control].addValidators([Validators.required]);
  //                       this.form.controls[control].updateValueAndValidity();
  //                     }
  //                 })
  //                 }
  //               }

  //             }
  //           });

  //         }
  //       });

  //     }else{
  //       // this.form.controls[control].reset()
  //       // this.form.controls[control].clearValidators()


  //       this.checkBox.find(ele => {
  //         if (ele.name == type) {
  //           ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //           if (ele.value == 'No') {
  //             let consentData ={
  //               caseId: this.userDetails.case_id,
  //               consentType: type,
  //               option:ele.value,
  //               value:"",
  //               checked:ele.value =='Yes' ? 1:0,
  //               token:this.userInfo.token,
  //               version:this.userInfo.version}
  //             this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                 if(!res.error){
  //                   this.form.controls[control].reset();
  //                   this.form.controls[control].clearValidators();
  //                   this.form.controls[control].updateValueAndValidity();
  //                 }
  //             })
  //           } else {
  //             //   if (type == 'GST') {
  //             //   this.form.controls[control].addValidators([Validators.required, Validators.minLength(15)]);
  //             // } else if (ele.name == 'MSME') {
  //             //   this.form.controls[control].addValidators([Validators.required, Validators.pattern("[0-9]{12}")]);
  //             // } else if(ele.name == 'TRIN'){
  //             //   this.form.controls[control].addValidators([Validators.required]);
  //             // }
  //             let consentData ={
  //               caseId: this.userDetails.case_id,
  //               consentType: type,
  //               option:ele.value,
  //               value:"",
  //               checked:ele.value =='Yes' ? 1:0,
  //               token:this.userInfo.token,
  //               version:this.userInfo.version}

  //               if (type == 'GST') {
  //                 this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                   if(!res.error){
  //                     this.form.controls[control].addValidators([Validators.required, Validators.minLength(15)]);
  //                     this.form.controls[control].updateValueAndValidity();
  //                   }
  //               })

  //             } else if (ele.name == 'MSME') {
  //               this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                 if(!res.error){
  //                   this.form.controls[control].addValidators([Validators.required, Validators.maxLength(20)]);
  //                   this.form.controls[control].updateValueAndValidity();
  //                 }
  //             })
  //             } else if(ele.name == 'TRIN'){

  //               this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                 if(!res.error){
  //                   this.form.controls[control].addValidators([Validators.required]);
  //                   this.form.controls[control].updateValueAndValidity();
  //                 }
  //             })
  //             }
  //           }
  //           // this.form.controls[control].updateValueAndValidity();
  //         }
  //       });
  //     }
  //   }

  //   if(type =='legal'){

  //     if(this.check.value == 'Yes'){
  //       const dialogRef = this.dialog.open(ConsentComponent, {
  //         disableClose: true,
  //         width: '400px',
  //         data: { title: title, messeage: messeage },
  //       });



  //       dialogRef.afterClosed().subscribe(result => {
  //         if (result) {
  //           this.checkBox.find(ele => {
  //             if (ele.name == type) {
  //               ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //               if (ele.value == 'No') {

  //                 let consentData ={
  //                   caseId: this.userDetails.case_id,
  //                   consentType: "Legal",
  //                   option:ele.value,
  //                   value:"",
  //                   checked:ele.value =='Yes' ? 1:0,
  //                   token:this.userInfo.token,
  //                   version:this.userInfo.version}
  //                 this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                     if(!res.error){
  //                       this.form.controls[control].reset();
  //                       this.form.controls[control].clearValidators();
  //                       this.form.controls[control].updateValueAndValidity();
  //                     }
  //                 })
  //               } else {
  //                 let consentData ={
  //                   caseId: this.userDetails.case_id,
  //                   consentType: "Legal",
  //                   option:ele.value,
  //                   value:"",
  //                   checked:ele.value =='Yes' ? 1:0,
  //                   token:this.userInfo.token,
  //                   version:this.userInfo.version}
  //                 this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                     if(!res.error){
  //                       this.form.controls[control].addValidators([Validators.required]);
  //                       this.form.controls[control].updateValueAndValidity();
  //                     }
  //                 })
  //               }
  //               // this.form.controls[control].updateValueAndValidity();
  //             }
  //           });

  //         }
  //       });
  //     }else{
  //       this.checkBox.find(ele => {
  //         if (ele.name == type) {
  //           ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //           if (ele.value == 'No') {

  //             let consentData ={
  //               caseId: this.userDetails.case_id,
  //               consentType: "Legal",
  //               option:ele.value,
  //               value:"",
  //               checked:ele.value =='Yes' ? 1:0,
  //               token:this.userInfo.token,
  //               version:this.userInfo.version}

  //               this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                 if(!res.error){
  //                    this.form.controls[control].reset();
  //                     this.form.controls[control].clearValidators();
  //                     this.form.controls[control].updateValueAndValidity();
  //                 }
  //             })

  //           } else {

  //             let consentData ={
  //               caseId: this.userDetails.case_id,
  //               consentType: "Legal",
  //               option:ele.value,
  //               value:"",
  //               checked:ele.value =='Yes' ? 1:0,
  //               token:this.userInfo.token,
  //               version:this.userInfo.version}

  //               this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                 if(!res.error){
  //                   this.form.controls[control].addValidators([Validators.required]);
  //                   this.form.controls[control].updateValueAndValidity();
  //                 }
  //             })
  //               // this.form.controls[control].addValidators([Validators.required]);
  //           }
  //           // this.form.controls[control].updateValueAndValidity();
  //         }
  //       });
  //     }
  //   }

  //   if(type =='AdityaBirla'){
  //     if(this.check.value == 'No'){
  //     this.form.addControl('applicantRelation', new FormControl('', Validators.required));
  //     this.form.addControl('applicantLocation', new FormControl('', Validators.required));
  //     this.form.addControl('applicantCompany', new FormControl('', Validators.required));
  //     this.form.addControl('applicantDate', new FormControl('', Validators.required));
  //     this.form.addControl('applicantPlace', new FormControl('', Validators.required));
  //     this.form.updateValueAndValidity();

  //       const dialogRef = this.dialog.open(ConsentComponent, {
  //         disableClose: true,
  //         width: '400px',
  //         data: { title: title, messeage: messeage }
  //       });

  //       dialogRef.afterClosed().subscribe(result => {
  //         if (result) {
  //           this.checkBox.find(ele => {
  //             if (ele.name == type) {
  //               ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //               if (ele.value == 'No') {

  //                 let consentData ={
  //                   caseId: this.userDetails.case_id,
  //                   consentType: "relation",
  //                   option:ele.value,
  //                   value:"",
  //                   checked:ele.value =='Yes' ? 1:0,
  //                   token:this.userInfo.token,
  //                   version:this.userInfo.version}
  //                 this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                     if(!res.error){

  //                       this.form.removeControl('applicantRelation');
  //                       this.form.removeControl('applicantLocation');
  //                       this.form.removeControl('applicantCompany');
  //                       this.form.removeControl('applicantDate');
  //                       this.form.removeControl('applicantPlace');

  //                       this.form.updateValueAndValidity();


  //                       // this.form.controls['company_name'].clearValidators();
  //                       // this.form.controls['relation'].clearValidators();
  //                       // this.form.controls['location'].clearValidators();
  //                       // this.form.controls['company_date'].clearValidators();
  //                       // this.form.controls[control].reset();
  //                       // this.form.controls[control].clearValidators();
  //                       // this.form.updateValueAndValidity();
  //                     }
  //                 })
  //               } else {
  //                 let consentData ={
  //                   caseId: this.userDetails.case_id,
  //                   consentType: "relation",
  //                   option:ele.value,
  //                   value:"",
  //                   checked:ele.value =='Yes' ? 1:0,
  //                   token:this.userInfo.token,
  //                   version:this.userInfo.version}
  //                 this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                     if(!res.error){


  //                       // this.form.removde('applicantCompany', new FormControl('', Validators.required));

  //                       // this.form.controls['applicantCompany'].updateValueAndValidity();
  //                       this.form.addControl('applicantRelation', new FormControl('', Validators.required));
  //                       this.form.addControl('applicantLocation', new FormControl('', Validators.required));
  //                       this.form.addControl('applicantCompany', new FormControl('', Validators.required));
  //                       this.form.addControl('applicantDate', new FormControl('', Validators.required));
  //                       this.form.addControl('applicantPlace', new FormControl('', Validators.required));
  //                       this.form.updateValueAndValidity();

  //                     }
  //                 })
  //               }
  //               // this.form.controls[control].updateValueAndValidity();
  //             }
  //           });

  //         }else{
  //           this.form.removeControl('applicantRelation');
  //           this.form.removeControl('applicantLocation');
  //           this.form.removeControl('applicantCompany');
  //           this.form.removeControl('applicantDate');
  //           this.form.removeControl('applicantPlace');

  //           this.form.updateValueAndValidity();
  //         }
  //       });
  //     }else{
  //       this.checkBox.find(ele => {
  //         if (ele.name == type) {
  //           ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //           if (ele.value == 'No') {

  //             let consentData ={
  //               caseId: this.userDetails.case_id,
  //               consentType: "relation",
  //               option:ele.value,
  //               value:"",
  //               checked:ele.value =='Yes' ? 1:0,
  //               token:this.userInfo.token,
  //               version:this.userInfo.version}

  //               this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                 if(!res.error){
  //                   this.form.removeControl('applicantCompany');
  //                   this.form.removeControl('applicantRelation');
  //                   this.form.removeControl('applicantLocation');
  //                   this.form.removeControl('applicantDate');
  //                   this.form.removeControl('applicantPlace');

  //                   this.form.updateValueAndValidity();

  //                 }
  //             })

  //           } else {

  //             let consentData ={
  //               caseId: this.userDetails.case_id,
  //               consentType: "relation",
  //               option:ele.value,
  //               value:"",
  //               checked:ele.value =='Yes' ? 1:0,
  //               token:this.userInfo.token,
  //               version:this.userInfo.version}

  //               this._apiService.updateConsent(consentData).subscribe((res:any)=>{

  //                 if(!res.error){
  //                   this.form.addControl('applicantCompany', new FormControl('', Validators.required));
  //                   this.form.addControl('applicantRelation', new FormControl('', Validators.required));
  //                   this.form.addControl('applicantLocation', new FormControl('', Validators.required));
  //                   this.form.addControl('applicantDate', new FormControl('', Validators.required));
  //                   this.form.addControl('applicantPlace', new FormControl('', Validators.required));
  //                   this.form.updateValueAndValidity();
  //                 }
  //             })
  //           }
  //         }
  //       });
  //     }
  //   }




  //   // if(type =='legal'){
  //   //   if(this.check.value == 'No'){
  //   //     const dialogRef = this.dialog.open(ConsentComponent, {
  //   //       disableClose: true,
  //   //       width: '400px',
  //   //       data: { title: title, messeage: messeage },
  //   //     });

  //   //     dialogRef.afterClosed().subscribe(result => {
  //   //       if (result) {
  //   //         this.checkBox.find(ele => {
  //   //           if (ele.name == type) {
  //   //             ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //   //             if (ele.value == 'No') {

  //   //               let consentData ={
  //   //                 caseId: this.userDetails.case_id,
  //   //                 consentType: "Legal",
  //   //                 option:ele.value,
  //   //                 value:"",
  //   //                 checked:ele.value =='Yes' ? 1:0,
  //   //                 token:this.userInfo.token,
  //   //                 version:this.userInfo.version}
  //   //               this._apiService.updateConsent(consentData).subscribe((res:any)=>{
  //   //
  //   //                   if(!res.error){
  //   //                     this.form.controls[control].reset();
  //   //                     this.form.controls[control].clearValidators();
  //   //                   }
  //   //               })
  //   //             } else {
  //   //               let consentData ={
  //   //                 caseId: this.userDetails.case_id,
  //   //                 consentType: "Legal",
  //   //                 option:ele.value,
  //   //                 value:"",
  //   //                 checked:ele.value =='Yes' ? 1:0,
  //   //                 token:this.userInfo.token,
  //   //                 version:this.userInfo.version}
  //   //               this._apiService.updateConsent(consentData).subscribe((res:any)=>{
  //   //
  //   //                   if(!res.error){
  //   //                     this.form.controls[control].addValidators([Validators.required]);
  //   //                   }
  //   //               })
  //   //             }
  //   //             this.form.controls[control].updateValueAndValidity();
  //   //           }
  //   //         });

  //   //       }
  //   //     });
  //   //   }else{
  //   //     this.checkBox.find(ele => {
  //   //       if (ele.name == type) {
  //   //         ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //   //         if (ele.value == 'No') {

  //   //           let consentData ={
  //   //             caseId: this.userDetails.case_id,
  //   //             consentType: "Legal",
  //   //             option:ele.value,
  //   //             value:"",
  //   //             checked:ele.value =='Yes' ? 1:0,
  //   //             token:this.userInfo.token,
  //   //             version:this.userInfo.version}

  //   //             this._apiService.updateConsent(consentData).subscribe((res:any)=>{
  //   //
  //   //               if(!res.error){

  //   //                  this.form.controls[control].reset();
  //   //                   this.form.controls[control].clearValidators();
  //   //               }
  //   //           })

  //   //         } else {

  //   //           let consentData ={
  //   //             caseId: this.userDetails.case_id,
  //   //             consentType: type,
  //   //             option:ele.value,
  //   //             value:"",
  //   //             checked:ele.value =='Yes' ? 1:0,
  //   //             token:this.userInfo.token,
  //   //             version:this.userInfo.version}

  //   //             this._apiService.updateConsent(consentData).subscribe((res:any)=>{
  //   //
  //   //               if(!res.error){
  //   //                 this.form.controls[control].addValidators([Validators.required]);
  //   //               }
  //   //           })
  //   //             // this.form.controls[control].addValidators([Validators.required]);
  //   //         }
  //   //         this.form.controls[control].updateValueAndValidity();
  //   //       }
  //   //     });
  //   //   }
  //   // }


  //   if(type =='ITR'){
  //     if(this.panVerify){
  //       let itrData = {
  //         email: this.userDetails.email_id,
  //         mobile: this.userDetails.phone_number,
  //         panName: this.fullName ? this.fullName : this.userDetails.panfullname,
  //         pan: this.form.controls['panCard'].value,
  //         caseId: this.userDetails.case_id,
  //         itr_verify_flag: 1,
  //         token:this.userInfo.token,
  //         version:this.userInfo.version,
  //       }

  //    const dialogRef = this.dialog.open(ConsentComponent, {
  //       disableClose: true,
  //       width: '400px',
  //       data: { title: title, messeage: messeage, itr: itrData ? itrData : '' },
  //     });

  //       dialogRef.afterClosed().subscribe(result => {
  //       if (result) {
  //         this.itrVerify = true;
  //       }
  //     });

  //     }else{
  //       Swal.fire({
  //         position: 'center',
  //         icon: 'warning',
  //         title: "Please verify PAN first",
  //         showConfirmButton: false,
  //         timer: 1500
  //       })
  //     }


  //   }



  //   // this.check = this.checkBox.find(ele => ele.name == type);

  //   // if(type=='ITR'){
  //   //   this.check.value = this.check?'No':'Yes'
  //   // }

  //   // let itrData
  //   // if (this.check.value == 'No') {

  //   //   if (type == 'ITR') {
  //   //     itrData = {
  //   //       email: this.userDetails.email_id,
  //   //       mobile: this.userDetails.phone_number,
  //   //       panName: this.fullName ? this.fullName : this.userDetails.panfullname,
  //   //       pan: this.form.controls['panCard'].value,
  //   //       caseId: this.userDetails.case_id,
  //   //       itr_verify_flag: 1
  //   //     }
  //   //   }

  //   //   const dialogRef = this.dialog.open(ConsentComponent, {
  //   //     disableClose: true,
  //   //     width: '400px',
  //   //     data: { title: title, messeage: messeage, itr: itrData ? itrData : '' },
  //   //   });

  //   //   dialogRef.afterClosed().subscribe(result => {
  //   //     if (result) {
  //   //       this.checkBox.find(ele => {
  //   //         if (ele.name == type) {
  //   //           ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //   //           if (ele.value == 'No') {
  //   //             this.form.controls[control].reset();
  //   //             this.form.controls[control].clearValidators();
  //   //           } else {

  //   //             if (type == 'legal') {
  //   //               this.form.controls[control].addValidators([Validators.required])
  //   //             } else if (type == 'GST') {
  //   //               this.form.controls[control].addValidators([Validators.required, Validators.minLength(15)]);
  //   //             } else if (ele.name == 'MSME') {
  //   //               this.form.controls[control].addValidators([Validators.required, Validators.pattern("[0-9]{12}")]);
  //   //             }

  //   //             //  this.form.controls[control].addValidators([Validators.required,Validators.pattern(/^\d{12}$/)]);
  //   //           }
  //   //           if (ele.name == 'ITR') {
  //   //             this.itrVerify = true;
  //   //           } else {
  //   //             this.form.controls[control].updateValueAndValidity();
  //   //           }
  //   //         }
  //   //       });

  //   //     }
  //   //   });

  //   // } else {
  //   //   this.checkBox.find(ele => {
  //   //     if (ele.name == type) {
  //   //       ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
  //   //       if (ele.value == 'No') {
  //   //         this.form.controls[control].reset()
  //   //         this.form.controls[control].clearValidators();
  //   //       } else {
  //   //         if (type == 'legal') {
  //   //           this.form.controls[control].addValidators([Validators.required])
  //   //         } else if (type == 'GST') {
  //   //           this.form.controls[control].addValidators([Validators.required, Validators.minLength(15)]);
  //   //         } else if (ele.name == 'MSME') {
  //   //           this.form.controls[control].addValidators([Validators.required, Validators.pattern("[0-9]{12}")]);
  //   //         }
  //   //       }
  //   //       this.form.controls[control].updateValueAndValidity();
  //   //     }
  //   //   });
  //   // }
  //   // }
  // }


  changeDetect(event:any){
    if(event){
      this.getCaseDetails();
      // this.getCaseDocType();
    }

  }

  downloadDocuments(id:any){
    this.spinner.show();
    this._apiService.downloadDocuments({"DID":id}).pipe(
      take(1)
  ).subscribe((resp:any) => {

    var contentDisposition = resp.headers.get('content-disposition');
    var filename = contentDisposition.split(';')[1].split('filename')[1].split('=')[1].trim().replaceAll('"', '');
      let downloadLink = document.createElement('a');
      downloadLink.href = window.URL.createObjectURL(resp.body);
      downloadLink.setAttribute('download',filename);
      document.body.appendChild(downloadLink);
      downloadLink.click();
      downloadLink.remove();
      this.spinner.hide();
  } , (err: HttpErrorResponse) => {
    this.spinner.hide();
    if (err.status === 400) {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: err.error.message,
        showConfirmButton: false,
        timer: 1500
      })

    } else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
        showConfirmButton: false,
        timer: 1500
      })
    }
  });
  }

  deleteDocument(id:any){
    this.spinner.show();
    this._apiService.deleteDocuments({"did":id}).subscribe((res:any)=>{
      if(!res.error){
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
        // this.ngOnInit();
        this.getCaseDetails();

      }else{
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    },
    (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
    })
  }


  getGstDoc(){
      this.spinner.show();
      this._apiService.getGstDoc({ caseId: this.userDetails.case_id }).subscribe((res: any) => {
        if (!res.error) {

          this.spinner.hide();
            this.Did = res.documentData[0]?res.documentData[0].dms_id:null;
            this.docId = res.documentData[0]?res.documentData[0].id:null;
            if (res.documentData.length > 0) {
            this.fileName= res.documentData[0].name ;
            this.gstUrl = environment.imgUrl + 'uploads/dsa_front/' + res.documentData[0].path
          } else {
            this.gstUrl = null
          }

        }else{
          this.spinner.show();
        }
      } , (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
            showConfirmButton: false,
            timer: 1500
          })
        }
      })



  }

  consentDialog(type: string, title: string, messeage: string, control: string): void {
    this.check = this.checkBox.find(ele => ele.name == type);
    if(type =='GST' || type =='MSME' ){
      if(this.check.value == 'Yes'){
        this.checkBox.find(ele => {
              if (ele.name == type) {
                ele.value = ele.value == 'Yes' ? 'No' : 'Yes';
                if (ele.value == 'No') {
                  let consentData ={
                    caseId: this.userDetails.case_id,
                    consentType: type,
                    option:ele.value,
                    value:"",
                    checked:ele.value =='Yes' ? 1:0,
                    token:this.userInfo.token,
                    version:this.userInfo.version}
                  this._apiService.updateConsent(consentData).subscribe((res:any)=>{

                      if(!res.error){
                        this.form.controls[control].reset();
                        this.form.controls[control].clearValidators();
                        this.form.controls[control].updateValueAndValidity();
                      }
                  })

                } else {

                  let consentData ={
                    caseId: this.userDetails.case_id,
                    consentType: type,
                    option:ele.value,
                    checked:ele.value =='Yes' ? 1:0,
                    value:"",
                    token:this.userInfo.token,
                    version:this.userInfo.version}
                    
                    if (type == 'GST') {
                      consentData.checked = this.userDetails.gst_verify_flag;
                      this._apiService.updateConsent(consentData).subscribe((res:any)=>{

                        if(!res.error){
                          this.form.controls[control].addValidators([Validators.required, Validators.minLength(15)]);
                          this.form.controls[control].updateValueAndValidity();
                        }
                    })

                  } else if (ele.name == 'MSME') {
                    consentData.checked = this.userDetails.msme_applicable == 'Yes'? 1: 0;
                    this._apiService.updateConsent(consentData).subscribe((res:any)=>{

                      if(!res.error){
                        this.form.controls[control].addValidators([Validators.required, Validators.maxLength(20)]);
                        this.form.controls[control].updateValueAndValidity();
                      }
                  })
                  }
                }

              }
            });

      }else{
       

        this.checkBox.find(ele => {
          if (ele.name == type) {
            ele.value = ele.value == 'Yes' ? 'No' : 'Yes'
            if (ele.value == 'No') {
              let consentData ={
                caseId: this.userDetails.case_id,
                consentType: type,
                option:ele.value,
                value:"",
                checked:ele.value =='Yes' ? 1:0,
                token:this.userInfo.token,
                version:this.userInfo.version}
              this._apiService.updateConsent(consentData).subscribe((res:any)=>{

                  if(!res.error){
                    this.form.controls[control].reset();
                    this.form.controls[control].clearValidators();
                    this.form.controls[control].updateValueAndValidity();
                  }
              })
            } else {
              let consentData ={
                caseId: this.userDetails.case_id,
                consentType: type,
                option:ele.value,
                value:"",
                checked:ele.value =='Yes' ? 1:0,
                token:this.userInfo.token,
                version:this.userInfo.version
              }

                if (type == 'GST') {
                  consentData.checked = this.userDetails.gst_verify_flag;
                  this._apiService.updateConsent(consentData).subscribe((res:any)=>{

                    if(!res.error){
                      this.form.controls[control].addValidators([Validators.required, Validators.minLength(15)]);
                      this.form.controls[control].updateValueAndValidity();
                    }
                })

              } else if (ele.name == 'MSME') {
                consentData.checked = this.userDetails.msme_applicable == 'Yes'? 1: 0;
                this._apiService.updateConsent(consentData).subscribe((res:any)=>{

                  if(!res.error){
                    this.form.controls[control].addValidators([Validators.required, Validators.maxLength(20)]);
                    this.form.controls[control].updateValueAndValidity();
                  }
              })
              } 
            }
          }
        });
      }
    }

    if(type =='ITR'){
      
      if(this.panVerify){
        let itrData = {
          email: this.userDetails.email_id,
          mobile: this.userDetails.phone_number,
          panName: this.fullName ? this.fullName : this.userDetails.panfullname,
          pan: this.form.controls['panCard'].value,
          caseId: this.userDetails.case_id,
          itr_verify_flag: 1,
          token:this.userInfo.token,
          version:this.userInfo.version,
        }

          this.spinner.show();
          this._apiService.getITRVerify({...itrData}).subscribe((res:any)=>{
            if(!res.error){
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: res.message,
                showConfirmButton: false,
                timer: 1500
              })
            }else{
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: res.message,
                showConfirmButton: false,
                timer: 1500
              })
            }
          },(err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })
    
            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
    
        });
          this.itrVerify = true;

      }else{
        this.itrVerify = false;
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: "Please verify PAN first",
          showConfirmButton: false,
          timer: 1500
        })
      }


    }


  }


}