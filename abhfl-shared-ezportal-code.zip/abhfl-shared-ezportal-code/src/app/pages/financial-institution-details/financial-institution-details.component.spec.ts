import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialInstitutionDetailsComponent } from './financial-institution-details.component';

describe('FinancialInstitutionDetailsComponent', () => {
  let component: FinancialInstitutionDetailsComponent;
  let fixture: ComponentFixture<FinancialInstitutionDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinancialInstitutionDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialInstitutionDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
