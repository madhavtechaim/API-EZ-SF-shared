import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { StorageService } from './../../services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-financial-institution-details',
  templateUrl: './financial-institution-details.component.html',
  styleUrls: ['./financial-institution-details.component.scss'],
})
export class FinancialInstitutionDetailsComponent implements OnInit {
  form: FormGroup;
  formSubmitAttempt: boolean;
  personaChannelList: any[] = [
    { title: 'Property Broker', value: 'Property Broker' },
    { title: 'Financial Planner', value: 'Financial Planner' },
    { title: 'Insurance Agent', value: 'Insurance Agent' },
    { title: 'Loan Advisor', value: 'Loan Advisor' },
    { title: 'CA', value: 'CA' },
    { title: 'Others', value: 'Others' },
  ];
  numberOfFIList: any[] = [
    { title: '0', value: '0' },
    { title: '1', value: '1' },
    { title: '2', value: '2' },
    { title: '3', value: '3' },
    { title: '4', value: '4' },
    { title: '5', value: '5' },
    { title: '6', value: '6' },
    { title: '7', value: '7' },
    { title: '8', value: '8' },
    { title: '9', value: '9' },
    { title: '10 and above', value: '10 and above' },
  ];
  isOthersVisible: boolean = false;
  financialInstitutionCount: any = null;
  fICount: any;
  isWebRequest: boolean = false;
  addCaseDetailRequest: {
    appId: any;
    token: any;
    persona_of_channel: any;
    other_persona: any;
    experience_in_selling_hl: any;
    monthly_business_amount_in_crores: any;
    number_of_financial_institutions: any;
    financial_institution_name_1: any;
    financial_institution_name_2: any;
    financial_institution_name_3: any;
    stageCount: any;
  };
  userDetails: any;
  userInfo: any;
  userData: any;
  financialInstitutionDetails: any;
  isDisabled: boolean = false;

  constructor(
    private router: Router,
    private _formBuilder: FormBuilder,
    private spinner: NgxSpinnerService,
    private storageService: StorageService,
    public _apiService: ApiService,
  ) {}

  ngOnInit(): void {
    this.userInfo = this.storageService.secureStorage.getItem('userinfo');
    this.userData = this.storageService.secureStorage.getItem('UserDetails');

    this.form = this._formBuilder.group({
      persona_of_channel: ['', [Validators.required]],
      other_persona: [''],
      experience_in_selling_hl: ['', [Validators.required, Validators.max(60), Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      monthly_business_amount_in_crores: ['', [Validators.required, Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      number_of_financial_institutions: ['', [Validators.required]],
      fIName1: [''],
      fIName2: [''],
      fIName3: [''],
    });

    this.form.controls['persona_of_channel'].valueChanges.subscribe(
      (res: any) => {
        if (res === 'Others') {
          this.isOthersVisible = true;
          this.form.controls['other_persona'].addValidators([
            Validators.required,
          ]);
          this.form.controls['other_persona'].updateValueAndValidity();
        } else {
          this.isOthersVisible = false;
          this.form.controls['other_persona'].reset();
          this.form.controls['other_persona'].clearValidators();
          this.form.controls['other_persona'].updateValueAndValidity();
          this.form.controls['other_persona'].clearValidators();
        }
      }
    );

    this.form.controls[
      'number_of_financial_institutions'
    ].valueChanges.subscribe((value: any) => {
      if (+value === 0) {
        this.financialInstitutionCount = 0;
        this.form.controls['fIName1'].reset();
        this.form.controls['fIName1'].clearValidators();
        this.form.controls['fIName1'].updateValueAndValidity();
        this.form.controls['fIName1'].clearValidators();
        this.form.controls['fIName2'].reset();
        this.form.controls['fIName2'].clearValidators();
        this.form.controls['fIName2'].updateValueAndValidity();
        this.form.controls['fIName2'].clearValidators();
        this.form.controls['fIName3'].reset();
        this.form.controls['fIName3'].clearValidators();
        this.form.controls['fIName3'].updateValueAndValidity();
        this.form.controls['fIName3'].clearValidators();
      } else if (+value === 1) {
        this.financialInstitutionCount = 1;
        this.form.controls['fIName1'].addValidators([Validators.required]);
        this.form.controls['fIName1'].updateValueAndValidity();
      } else if (+value === 2) {
        this.financialInstitutionCount = 2;
        this.form.controls['fIName1'].addValidators([Validators.required]);
        this.form.controls['fIName1'].updateValueAndValidity();
        this.form.controls['fIName2'].addValidators([Validators.required]);
        this.form.controls['fIName2'].updateValueAndValidity();
      } else {
        this.financialInstitutionCount = 3;
        this.form.controls['fIName1'].addValidators([Validators.required]);
        this.form.controls['fIName1'].updateValueAndValidity();
        this.form.controls['fIName2'].addValidators([Validators.required]);
        this.form.controls['fIName2'].updateValueAndValidity();
        this.form.controls['fIName3'].addValidators([Validators.required]);
        this.form.controls['fIName3'].updateValueAndValidity();
      }
      this.fICount =
        this.financialInstitutionCount === 0
          ? ''
          : this.financialInstitutionCount;
    });
    this.getCaseDetails();
  }

  getCaseDetails() {
      this.spinner.show();
      this._apiService.getCaseDetails({token:this.userInfo.token}).subscribe((res)=>{
        if(!res.error){
          this.userDetails = res.data[0];
          this.financialInstitutionDetails = res.financialInstitutionData[0];

          if(res.financialInstitutionData.length>0){
            this.form.patchValue({
              persona_of_channel: this.financialInstitutionDetails.persona_of_channel,
              other_persona:this.financialInstitutionDetails.other_persona,
              experience_in_selling_hl:this.financialInstitutionDetails.experience_in_selling_hl,
              monthly_business_amount_in_crores:this.financialInstitutionDetails.monthly_business_amount_in_crores,
              number_of_financial_institutions:this.financialInstitutionDetails.number_of_financial_institutions,
              fIName1:this.financialInstitutionDetails.financial_institution_name_1,
              fIName2:this.financialInstitutionDetails.financial_institution_name_2,
              fIName3:this.financialInstitutionDetails.financial_institution_name_3,
            });
            this.isDisabled = true;
          } else {
            this.isDisabled = false;
          }
          this.spinner.hide();
      }else{
        this.isDisabled = false;
        this.spinner.hide();
      }
     },(err: HttpErrorResponse) =>
      {
        this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
    })
  }

  navigateTo() {
    this.router.navigate(['/home']);
  }

  cancel() {
    this.router.navigate(['/home']);
  }

  back(): void {
    this.router.navigate(['/home/reference-details']);
  }

  next() {
    this.formSubmitAttempt = true;
    if (this.form.invalid) {
      return;
    }

    if (this.form.valid) {
      this.spinner.show();
      this.isWebRequest = true;
      this.addCaseDetailRequest = {
        appId: this.userDetails.case_id,
        token: this.userInfo.token,
        stageCount: 8,
        persona_of_channel: this.form.value.persona_of_channel,
        other_persona: this.form.value.other_persona,
        experience_in_selling_hl: this.form.value.experience_in_selling_hl,
        monthly_business_amount_in_crores:
          this.form.value.monthly_business_amount_in_crores,
        number_of_financial_institutions:
          this.form.value.number_of_financial_institutions,
        financial_institution_name_1: this.form.value.fIName1,
        financial_institution_name_2: this.form.value.fIName2,
        financial_institution_name_3: this.form.value.fIName3,
      };

      this._apiService.addCaseDetail(this.addCaseDetailRequest).subscribe((response:any)=>{
        if(!response.error){
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          });
          this.router.navigate(['/home/bureau-details']);
        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          });
        }
      },
      (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
            showConfirmButton: false,
            timer: 1500
          })
        }
        this.isWebRequest = false;
      });
    }
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid && field.untouched && this.formSubmitAttempt)
    );
  }

  get f(): any {
    return this.form.controls;
  }
}
