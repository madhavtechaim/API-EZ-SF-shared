import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { StorageService } from 'src/app/services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import { TrainingComponent } from 'src/app/modals/training/training.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormControl } from '@angular/forms';
import { MatCalendar } from '@angular/material/datepicker';

@Component({
  selector: 'app-training-module',
  templateUrl: './training-module.component.html',
  styleUrls: ['./training-module.component.scss']
})
export class TrainingModuleComponent implements OnInit {
  years: any = this.generateYearsFrom2020();
  userData: any;
  selectedYear: any = new Date().getFullYear();
  categoryData: any[] = [];
  categoryList: any[] = [];
  path: string;
  languageType: any = 'English'
  CatergoyId: any = 'All';
  completeCount: any;
  mandatoryCount: any;
  overlay: boolean = false;
  checked: any = false;
  completeFlag: boolean = false;
  temp: any[];
  step: any = 0;
  userInfo: any;
  defaultLanguage: any = "English";
  isLanguageFix: any = false;
  allContents: any;

  constructor(private _apiService: ApiService, private storageService: StorageService, public dialog: MatDialog, private spinner: NgxSpinnerService, private router: Router) {

  }

  ngOnInit(): void {
    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    this.userInfo = this.storageService.secureStorage.getItem("userinfo")

    this.path = environment.imgUrl

    this.getCategory('');
    this.changeList(this.languageType, 'auto', this.CatergoyId);
  }

  getCategory(Search: any) {
    this.spinner.show();
    const data = new FormData();
    data.append('version', this.storageService.secureStorage.getItem('version'));
    data.append('role', this.userData.partner_type);
    data.append('mobile', this.userData.phone_no);
    data.append('token', this.userInfo.token);
    data.append('version', this.userInfo.version);
    data.append('year', this.selectedYear);

    this._apiService.getTrainingCategories(data).subscribe((response: any) => {
      if (!response.error) {

        if (response.isCompleted) {
          this.completeFlag = true;
        } else {
          this.completeFlag = false;
        }
        this.categoryData = response.data;
        this.temp = this.categoryData

        this.spinner.hide();
      } else {
        this.spinner.hide();
      }
    }, ((err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    }))

  }

  setStep(value: any) {

    this.step = value;
  }

  changeList(lagType: any, status: any, catId: any) {

    this.spinner.show();
    if (status == 'auto') {
      this.languageType = lagType
    } else {
      this.languageType = lagType.target.value;
    }


    const data = new FormData();
    data.append('version', this.storageService.secureStorage.getItem('version'));
    data.append('role', this.userData.partner_type);
    data.append('mobile', this.userData.phone_no);
    data.append('token', this.userInfo.token);
    data.append('version', this.userInfo.version);
    data.append('year', this.selectedYear);


    this._apiService.getTrainingCategoryList(data).subscribe((response: any) => {
      if (!response.error) {
        if (response.language != null) {
          this.isLanguageFix = true
          this.languageType = this.defaultLanguage = response.language
        }



        this.categoryList = [];
        
        this.categoryList = response.data.filter((ele: any) => ele.language == this.languageType);

        this.completeCount = this.categoryList.filter((x: any) => x.language == this.languageType && x.status === 'Completed').length
        this.mandatoryCount = this.categoryList.filter((x: any) => x.language == this.languageType && x.isMandatory === 1).length


        if (this.completeCount == this.mandatoryCount && this.categoryList.length > 0) {
          this.overlay = true;

        } else {
          this.overlay = false;
          if (catId == 'All') {
            this.CatergoyId = 'All';
          } else {
            this.CatergoyId = catId;
            this.categoryList = this.categoryList.filter((ele: any) => ele.category_id == catId);
          }
        }
        this.spinner.hide();
      } else {
        this.spinner.hide();
      }
    }, ((err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }

    }))
  }

  understand(event: any) {


    this.checked = event.checked
  }

  changeStatus(value: any, status: any) {
    // this.spinner.show();
    const data = new FormData();
    data.append('role', this.userData.partner_type);
    data.append('mobile', this.userData.phone_no);
    data.append('document_id', value);
    data.append('status', status);
    data.append('token', this.userInfo.token);
    data.append('version', this.userInfo.version);
    data.append('year', this.selectedYear);



    this._apiService.updateTrainingDocument(data).subscribe((response: any) => {
      if (!response.error) {
        //  this.categoryList = response.data;

        this.categoryList.find((ele: any) => {
          if (ele.id == value) {
            ele.status == status
          }
        })


        this.changeList(this.languageType, 'auto', this.CatergoyId);
        this.spinner.hide();
      }
    }, ((err: HttpErrorResponse) => {
      // this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }

    }))
  }


  changeStatusOnCategory(id: any) {
    this.categoryList = this.categoryList.filter((ele: any) => ele.category_id == id);
  }


  search(event: any) {


    if (event.target.value) {
      this.categoryData = this.categoryData.filter((ele: any) => ele.category_name.toLowerCase().includes(event.target.value.toLowerCase()))
      // x.toLowerCase().includes(word)
    } else {
      this.categoryData = this.temp;
    }

  }
  // In your component.ts
  closeDialog() {
    this.overlay = false; // Or any logic to hide the overlay
  }


  onSubmit() {
    this.spinner.show();
    const data = new FormData();
    data.append('version', this.storageService.secureStorage.getItem('version'));
    data.append('role', this.userData.partner_type);
    data.append('mobile', this.userData.phone_no);
    data.append('token', this.userInfo.token);
    data.append('version', this.userInfo.version);
    data.append('year', this.selectedYear);

    this._apiService.trainingCenterComplete(data).subscribe((response: any) => {
      if (!response.error) {
        this.completeFlag = response.isCompleted;
        this.overlay = false;
        this.spinner.hide();
        this.getCategory('');
        this.changeList(this.languageType, 'auto', this.CatergoyId);
      } else  {
        this.completeFlag = response.isCompleted;
        this.overlay = true;
        this.spinner.hide();
      }
    }, ((err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })


      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }

    }))


  }

  navigateTo() {
    this.router.navigate(['/home'])
  }

  generateYearsFrom2020() {
    const startYear = 2020;
    const currentYear = new Date().getFullYear();
    const years: number[] = [];

    for (let year = startYear; year <= currentYear; year++) {
        years.push(year);
    }

    return years;
  }

  onYearChange(event: any) {
    this.selectedYear = event.value;
    this.ngOnInit();
  }
}
