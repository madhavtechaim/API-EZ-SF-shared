import { StorageService } from 'src/app/services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-dsa-dashboard',
  templateUrl: './dsa-dashboard.component.html',
  styleUrls: ['./dsa-dashboard.component.scss']
})
export class DsaDashboardComponent implements OnInit {
  date: any = new Date();
  hour: any = new Date().getHours();
  minute: any = new Date().getMinutes();
  second: any = new Date().getSeconds();

  form: FormGroup;
  formSumitAttempt: boolean;
  isWebRequest: boolean = false;
  eventCounts: any;
  eventCountsKeys: any;
  dayEventList: any;
  eventCountFilter: any = "Monthly";
  partnerCountFilter: any = "Monthly";
  range: boolean=false;
  rangeFrom: any;
  rangeTo: any;
  greeTingMessage: string;


  selectedDate: any = new Date();
  currentDate: any = new Date();
  monthDays: any = [];
  currentMonth: any = new Date().getMonth();
  currentYear: any = new Date().getFullYear();
  moment: any = moment;
  el: HTMLElement;
  partnerCounts: any;
  partnerCountsKeys: any[]=[];
  weekDays: any = [];
  userData: any;
  partneCounts: any;
  partneCountsKeys: any[]=[];
  time: number = 0;
  display: any;
  interval: any;
  eventShow: boolean=false;
  partnerFlag: boolean=false;
  filter: any;
  rangeFromP: any;
  rangeToP: any;
  userInfo: any;
  partCountFilter: any= 'Monthly';
  rangeP: boolean;
  partnerDataList: any;
  partnerDataList1:any;
  dayEventFilterList: any;
  // partnerDataList: { type: any; token: any; version: any; rangeFrom: any; rangeTo: any; };

  tariningCountKeys: any[] = [];
  trainingCounts: any;


  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, private storageService:StorageService, private spinner: NgxSpinnerService) { }


  ngOnInit(): void {

    this.userInfo = this.storageService.secureStorage.getItem("userinfo")


    this.time = 0;
  
    this.startTimer();
    this.userData = this.storageService.secureStorage.getItem('DSAUserDetails');
    this.getAllEventDashboardCount({type:this.eventCountFilter});
    this.getEventList();
    this.addWeekDays();
    this.getPartnerApplicationCount(this.partnerCountFilter)
    // this.getAllPartnerOnbordingCount('');

    if (this.hour < 12) {
      this.greeTingMessage = "GOOD MORNING";
    } else if (this.hour < 17) {
      this.greeTingMessage = "GOOD AFTERNOON";
    } else {
      this.greeTingMessage = "GOOD EVENING";
    }


  //   this.partneCountsKeys=[
  //     "UNDER REVIEW",
  //     "AGREEMENT IN PROGESS",
  //     "ONBOARDING",
  //     "QUERIES"]

  //  this.partneCounts={
  //     "UNDER REVIEW" : 0,
  //     "AGREEMENT IN PROGESS" : 0,
  //     "ONBOARDING" : 0,
  //     "QUERIES" :0
  //  }   

    this.partnerCountsKeys=[
        "INTERESTED",
        "APPLICATION"
      ]

      this.partnerCounts={
        "INTERESTED":0,
        "APPLICATION":0
      }

    this.eventCountsKeys=[
      "ALL",
      "FOLLOW UP",
      "CONVERTED",
      "WRONG NUMBER",
      "NOT INTERESTED",
      "NEW APPOINTMENT",
      "RENEWAL COLLECTED"
    ]

    this.eventCounts={
      "ALL" : 0,
      "FOLLOW UP" : 0,
      "CONVERTED" : 0,
      "WRONG NUMBER" : 0,
      "NOT INTERESTED" : 0,
      "NEW APPOINTMENT" : 0,
      "RENEWAL COLLECTED": 0
    }
    

   
  }



  startTimer() {
    clearInterval(this.interval);
    // console.log("=====>");
    this.interval = setInterval(() => {
      if (this.time === 0) {
        this.time++;
      } else {
        this.time++;
      }
      this.display = this.transform(this.time)
    }, 1000);
  }

  transform(value: number): string {
    const minutes: number = Math.floor(value / 60);
    return minutes + ':' + (value - minutes * 60);
  }



  addWeekDays = () => {

    let weekDates = []
    for (let index = 0; index < 7; index++) {
      weekDates.push(moment(this.currentDate).add(index, 'day'))
    }
    this.weekDays = weekDates;
  }

  onChangeMonth = (val: any) => {
    this.currentDate = moment(this.currentDate).add(val, 'M')
    this.currentMonth = moment(this.currentDate).format('MM');
    this.currentMonth = this.currentMonth - 1;
    this.currentYear = moment(this.currentDate).format('YYYY');
    this.monthDays = []
    this.addWeekDays();
  }

  onChangeWeek = (val: any) => {
    if (val == true) {
      let datesArray = [];
      let lastDateOfCurrentWeek = this.weekDays[this.weekDays.length - 1]
      for (let index = 1; index <= 7; index++) {
        datesArray.push(moment(lastDateOfCurrentWeek).add(index, 'day'))
      }
      this.selectedDate = datesArray[0]
      this.weekDays = datesArray;
      this.getEventList()
    } else {
      let datesArray = [];
      let lastDateOfCurrentWeek = this.weekDays[0];
      for (let index = 1; index <= 7; index++) {
        datesArray.push(moment(lastDateOfCurrentWeek).add(-index, 'day'));
      }
      datesArray.reverse();
      this.selectedDate = datesArray[0]
      this.weekDays = datesArray;
      this.getEventList()
    }
  }


  onSelectDate = (date: any) => {
    this.selectedDate = date
    this.getEventList();
  }

  addPartner(): void {
    this.router.navigate(['/home/add-partner'])
  }

  addIncentiveCorner(): void {
    this.router.navigate(['/home/incentive-corner'])
  }

  addEvent(): void {
    this.router.navigate(['/home/add-event'])
  }

  eventDetails(data:any): void {
    this.storageService.secureStorage.setItem('updateEvent',data);
    this.router.navigate(['/home/event-details'])
  }

  openPartnerList(data:any) {
    this.partnerDataList.type = data ;
    this._apiService.patnerSend.next({...this.partnerDataList});
    this.router.navigate(['/home/partner-list'])
  }

  openActivityList(data:any) {
    this.filter.eventType = data ;
    this._apiService.filterSend.next(this.filter);
    this.router.navigate(['/home/activity-list'])
  }

  onChangeActivityDashboardFilter = (filter: any) => {

    // console.log("___", filter);
    this.eventCountFilter = filter.target.value;
    if(this.eventCountFilter == 'Range'){
      this.range = true;
      
    }else{
      this.range = false;
      this.rangeFrom ='';
      this.rangeTo ='';
      let data = {
        type: this.eventCountFilter,
        token : this.userInfo.token,
        version : this.userInfo.version
      }
      this.getAllEventDashboardCount(data);
      
    }
  }





  onChangePartnerDashboardFilter(filter: any) {
  

    // console.log("___", filter);
    this.partCountFilter = filter.target.value;
    if(this.partCountFilter == 'Range'){
      this.rangeP = true;
      
    }else{
      this.rangeP = false;
      this.rangeFrom ='';
      this.rangeTo ='';
      let data = {  
        filterType: this.partCountFilter,
        // token:this.storageService.secureStorage.getItem('token'),
        // version:this.storageService.secureStorage.getItem('version'),
        token : this.userInfo.token,
        version : this.userInfo.version
      }

      this.getPartnerApplicationCount(data)

      
    }
  }



  // getPartnerApplicationCountOld(data:any){
  //   this.spinner.show();


  //   data={
  //     type:"Range",
  //     fromDate:"",
  //     toDate:"",
  //     token : this.userInfo.token,
  //     version : this.userInfo.version
  //   }

  //   this.getAllPartnerOnbordingCount(data);



  //     this.partnerDataList={
  //       filterType :  this.partCountFilter,
  //       token : this.userInfo.token,
  //       version : this.userInfo.version,
  //       rangeFrom :this.rangeFrom?this.rangeFrom:'',
  //       rangeTo  :this.rangeTo?this.rangeTo:'',
  //     }



  //     this.partnerDataList1={
  //       type :  this.partCountFilter,
  //       token : this.userInfo.token,
  //       version : this.userInfo.version,
  //       fromDate :this.rangeFrom?this.rangeFrom:'',
  //       toDate  :this.rangeTo?this.rangeTo:'',
  //     }


      

  //   this.getAllPartnerOnbordingCount(this.partnerDataList1);

  //   this._apiService.getPartnerApplicationCount(this.partnerDataList1).subscribe((res) => {
  //     if(res){
  //       this.partneCounts = res.data
  //       this.partneCountsKeys = Object.keys(res.data);
  //     }
  //     this.spinner.hide();
  //   }, (err: HttpErrorResponse) => {
  //     this.spinner.hide();

  //     if (err.status === 400) {
  //       Swal.fire({
  //         position: 'center',
  //         icon: 'success',
  //         title: err.error.message,
  //         showConfirmButton: false,
  //         timer: 1500
  //       })

  //     } else {
  //       this.spinner.hide();
  //       Swal.fire({
  //         position: 'center',
  //         icon: 'error',
  //         title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
  //         showConfirmButton: false,
  //         timer: 1500
  //       })
  //     }
  //     this.isWebRequest = false;
  //   })

  // }

  getPartnerApplicationCount(data: any) {
    this.spinner.show();


    data = {
      type: "Range",
      fromDate: "",
      toDate: "",
      token: this.userInfo.token,
      version: this.userInfo.version
    }

    this.getAllPartnerOnbordingCount(data);



    this.partnerDataList = {
      filterType: this.partCountFilter,
      token: this.userInfo.token,
      version: this.userInfo.version,
      rangeFrom: this.rangeFrom ? this.rangeFrom : '',
      rangeTo: this.rangeTo ? this.rangeTo : '',
    }



    this.partnerDataList1 = {
      type: this.partCountFilter,
      token: this.userInfo.token,
      version: this.userInfo.version,
      fromDate: this.rangeFrom ? this.rangeFrom : '',
      toDate: this.rangeTo ? this.rangeTo : '',
    }




    this.getAllPartnerOnbordingCount(this.partnerDataList1);

    this._apiService.getPartnerApplicationCount(this.partnerDataList1).subscribe((res) => {
      if (res) {
        this.partneCounts = res.data
        this.partneCountsKeys = Object.keys(res.data);
      }
      this.spinner.hide();
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();

      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })

    this._apiService.getpartnercaseDashboardList(this.partnerDataList1).subscribe((res) => {
      if (res) {
        console.log("res:::::::::", res);
        this.trainingCounts = res.annualTrainingData[0]
        this.tariningCountKeys = Object.keys(res.annualTrainingData[0]);
      }
    console.log("traininG::::::::::::::;", this.trainingCounts);
      this.spinner.hide();
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();

      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })



  }

  getAllEventDashboardCount(data:any) {
  
    this.spinner.show();
    this.eventShow=false
    data.token = this.userInfo.token;
    data.version = this.userInfo.version;
    // data.version = this.storageService.secureStorage.getItem('version');
    
    this._apiService.getEventDashboardCount(data).subscribe((res) => {
      this.filter=''
      this.filter = data ;
      this.eventCounts = res.data
      this.eventCountsKeys = Object.keys(res.data);

      
      this.spinner.hide();
      
      this.eventShow = true;
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }



  getAllPartnerOnbordingCount(data:any) {
    this.spinner.show();
    this.partnerFlag = false;


    // data.token = this.storageService.secureStorage.getItem('token');
      // data.token = this.storageService.secureStorage.getItem('token');
    // data.version = this.storageService.secureStorage.getItem('version');

    // this._apiService.getAllPartnerOnbord(data)
    
    this._apiService.getPartnerCaseApplicationCount(data).subscribe(response => {
      this.partnerCounts = response.applicationData[0]
      this.partnerCountsKeys = Object.keys(response.applicationData[0]);
 
      this.partnerFlag = true;
      this.spinner.hide();
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }

  dateRange(event:any,type:any){

    if(type =='from'){
      this.rangeFrom = event.target.value;
      if(this.rangeFrom > this.rangeTo){
        this.rangeTo =''
      }

    }else{
      this.rangeTo = event.target.value
    }
    if(this.rangeFrom && this.rangeTo){
      let data = {
        type: 'Range',
        fromDate:this.rangeFrom,
        toDate:this.rangeTo
      }
      this.getPartnerApplicationCount(data);
    }
    

  }


  dateRangeP(event:any,type:any){

    if(type =='from'){
      this.rangeFromP = event.target.value;
      if(this.rangeFromP > this.rangeToP){
        this.rangeToP='';
      }
    }else{
      this.rangeToP = event.target.value
    }
    if(this.rangeFromP && this.rangeToP){
      let data = {
        type: 'Range',
        fromDate:this.rangeFromP,
        toDate:this.rangeToP
      }
      this.getAllEventDashboardCount(data);
      
    }
    

  }




  getEventList() {
    this.spinner.show();
    let data = {
      startDate: moment(this.selectedDate).format("YYYY-MM-DD"),
      fromDate: "",
      toDate: "",
      agentType: "",
      eventTitle: "",
      eventType: "",
      eventStatus: "",
      token : this.userInfo.token,
      version : this.userInfo.version
    }

    this._apiService.getEventList(data).subscribe((res) => {

      this.dayEventList = res.eventData;
      this.spinner.hide();
      // this.eventFilter();

      // res.eventData.forEach(element => {
      //   element.start_time=moment(element.start_time).format('hh:mm A');
      // });

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }

openTrainingList(data:any) {
    this.partnerDataList.type = data ;
    this._apiService.patnerSend.next({...this.partnerDataList});
    this.router.navigate(['/home/training-approval'])
  }


  // eventFilter(){
  //   if(this.dayEventList.length>0){
  //     setInterval(()=>{
  //       console.log(this.dayEventList);
        
  //       this.dayEventFilterList = this.dayEventList.filter((ele:any)=> ele.start_time > moment(this.selectedDate).format("HH:mm:ss")
  //       );
  //       console.log("this.dayEventFilterListthis.dayEventFilterList",this.dayEventFilterList);
  //     },1000*60*5)
  //   }
  // }


}


