import { environment } from 'src/environments/environment';
import { StorageService } from './../../services/storage.service';
import { AuthService } from './../../services/auth.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2'
import { ApiService } from 'src/app/services/api.service';
import { NgxSpinnerService } from 'ngx-spinner';
import * as CryptoJS from 'crypto-js';
import { OAuthService } from 'angular-oauth2-oidc';
import { JwksValidationHandler } from 'angular-oauth2-oidc-jwks';
import { ValuesService } from 'src/app/services/values.service';

@Component({
  selector: 'app-ad-login',
  templateUrl: './ad-login.component.html',
  styleUrls: ['./ad-login.component.scss']
})
export class AdLoginComponent implements OnInit {
  textInput: any = 'password'

  //   loginForm: FormGroup;
  //   formSumitAttempt: boolean;
  //   isWebRequest: boolean = false;

  //   constructor(private router: Router, private _formBuilder: FormBuilder, private _auth: AuthService, private storageService: StorageService, public _apiService: ApiService, private spinner: NgxSpinnerService) { }


  //   ngOnInit(): void {
  //     this.loginForm = this._formBuilder.group({
  //       adId: ['', [Validators.required]]
  //     })
  //   }

  //   get f() {
  //     return this.loginForm.controls;
  //   }

  //   isFieldValid(field: any) {
  //     return (
  //       (!field.valid && field.touched) ||
  //       (!field.valid &&
  //         field.untouched && this.formSumitAttempt)
  //     );
  //   }

  //   onPressLogin = () => {
  //     this.formSumitAttempt = true;
  //     if (this.loginForm.valid) {
  //       this.spinner.show();
  //       // console.log("----")
  //       this.isWebRequest = true;

  //       let data = {
  //         // "userId": "AD101"
  //         userId: this.loginForm.value.adId
  //       }
  //       this._apiService.dsaAdLogin(data).subscribe((res) => {
  //         this.storageService.secureStorage.clear();
  //         this._auth.userData.next(res);
  //         this.storageService.secureStorage.setItem('DSAUserDetails', res);
  //         this.storageService.secureStorage.setItem('token',res.token);
  //         this.storageService.secureStorage.setItem('version',res.version);


  //         // console.log(this.storageService.secureStorage.getItem('version'),this.storageService.secureStorage.getItem('token'));



  //         localStorage.setItem('UserData', res);
  //         this.spinner.hide();
  //         Swal.fire({
  //           position: 'center',
  //           icon: 'success',
  //           title: "Login Success",
  //           showConfirmButton: false,
  //           timer: 1500
  //         })
  //         this.router.navigate(['/home/dsa-dashboard'])

  //       }, (err: HttpErrorResponse) => {
  //         this.spinner.hide();
  //         if (err.status === 400) {
  //           Swal.fire({
  //             position: 'center',
  //             icon: 'success',
  //             title: err.error.message,
  //             showConfirmButton: false,
  //             timer: 1500
  //           })

  //           } else {
  //             Swal.fire({
  //               position: 'center',
  //               icon: 'error',
  //               title: err.error.message ? err.error.message: 'Server error' ,
  //               showConfirmButton: false,
  //               timer: 1500
  //             })
  //           }
  //           this.isWebRequest = false;
  //         })
  //     }
  //   }

  // }



  loginForm: FormGroup;
  otpForm: FormGroup;
  verifyMobile: boolean = false;
  formSumitAttempt: any;
  formSumitAttemptg: any;
  isWebRequest: boolean = false;
  isWebRequest1: boolean = false;
  mobile_no: any;
  loading: boolean;
  redirecting: boolean;
  privacyUrl: string;

  constructor(private router: Router, private fb: FormBuilder, private _auth: AuthService, private storageService: StorageService, private spinner: NgxSpinnerService, private oauthService: OAuthService, private valuesService: ValuesService) {
    // this.router.events.subscribe((val) => {
    //   console.log("============================", val instanceof NavigationEnd);
    //   // if (val instanceof NavigationEnd) {
    //   //   console.log("route changes=========", window.location.href.substring(window.location.href.indexOf('id_token=') + 9, window.location.href.indexOf('&state=')))
    //   //   if (window.location.href.includes('id_token=')) {
    //   //     this.checkLogin(window.location.href.substring(window.location.href.indexOf('id_token=') + 9, window.location.href.indexOf('&state=')));
    //   //   }else{
    //   //     this.initializeOAuthService();
    //   //     this.loadData(); 
    //   //   }
    //   // }
    // })





    router.events.subscribe((val) => {
      //console.log("============================", val instanceof NavigationEnd);
      if (val instanceof NavigationEnd) {
        //console.log("route changes=========", window.location.href.substring(window.location.href.indexOf('id_token=') + 9, window.location.href.indexOf('&state=')))
        if (window.location.href.includes('id_token=')) {

          // this.checkLogin(window.location.href.substring(window.location.href.indexOf('id_token=') + 9, window.location.href.indexOf('&state=')));
          this.checkLogin(window.location.href.substring(window.location.href.indexOf('id_token=') + 9, window.location.href.indexOf('&scope=')));
        }
        if (window.location.href.includes('onboarding=')) {
          this.router.navigate(['/onboarding'])
        }
      }
    })
  }

  ngOnInit(): void {
    this.privacyUrl = environment.terms_n_condition_url;
    this.loginForm = this.fb.group({
      userId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    })
    // this.otpForm = this.fb.group({
    //   OTP:['',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{6}$")]]
    // })

    this.initializeOAuthService();
    this.loadData();


  }

  get f() {
    return this.loginForm.controls;
  }

  get g() {
    return this.otpForm.controls;
  }


  // keyPress(event: any) {
  //   const pattern = /[0-9\+\-\ ]/;
  //   let inputChar = String.fromCharCode(event.charCode);
  //   if (event.keyCode != 8 && !pattern.test(inputChar)) {
  //     event.preventDefault();
  //   }
  // }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid && field.untouched && this.formSumitAttempt)
    );

  }

  // doLogin() {

  //     this.formSumitAttempt = true;
  //     if(this.loginForm.valid){
  //       this.spinner.show();
  //       // console.log(this.form.value)
  //         this.isWebRequest = true;

  //         let data = {
  //           mobileNo: this.loginForm.value.mobileNo,
  //           type :"login-otp" 
  //         }
  //         this.mobile_no = this.loginForm.value.mobileNo ;
  //         this._auth.login(data).subscribe(
  //           (response: any) => {
  //             if(!response.error){
  //               this.spinner.hide();
  //               Swal.fire({
  //                 position: 'center',
  //                 icon: 'success',
  //                 // title: response.message + response.OTP,
  //                 title: response.message,
  //                 showConfirmButton: false,
  //                 timer: 1500
  //               })
  //               this.verifyMobile =true;
  //             }else{
  //               Swal.fire({
  //                 position: 'center',
  //                 icon: 'warning',
  //                 title: response.message,
  //                 showConfirmButton: false,
  //                 timer: 1500
  //               })
  //               this.spinner.hide();
  //             }
  //           },
  //           (err: HttpErrorResponse) => {
  //             this.spinner.hide();
  //             if (err.status === 400) {
  //               Swal.fire({
  //                 position: 'center',
  //                 icon: 'error',
  //                 title: err.error.message,
  //                 showConfirmButton: false,
  //                 timer: 1500
  //               })

  //             } else {
  //               Swal.fire({
  //                 position: 'center',
  //                 icon: 'error',
  //                 title: err.error.message ? err.error.message: 'Server error' ,
  //                 showConfirmButton: false,
  //                 timer: 1500
  //               })
  //             }
  //             this.isWebRequest = false;
  //           }
  //         );
  //     }
  //   }


  loginAction() {
    this.formSumitAttempt = true;
    if (this.loginForm.valid) {

      this.isWebRequest = true;
      this.redirecting = false;
      this.loading = true;

      // let encKey = environment.encKey;
      // let text = this.loginForm.value.userId;

      // var encryptedUNText = CryptoJS.AES.encrypt(text, encKey).toString();
      // var encryptedPassText = CryptoJS.AES.encrypt(this.loginForm.value.password, encKey).toString();

      let user = {
        userId: this.loginForm.value.userId,
        password: this.loginForm.value.password,
      }
      this.spinner.show();
      this._auth.loginUser(user).subscribe(
        (response: any) => {

          if (!response.dsa_role) {
            this.spinner.hide();
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: "Invalid credentials",
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            this._auth.token = response.token;
            this._auth.role = response.dsa_role;
            this._auth.name = response.name;
            this._auth.code = response.code;
            this._auth.saveUserinfoToSorage({
              'empname': response.name,
              'version': response.version,
              'role': response.dsa_role,
              'token': response.token,
              'email': response.email,
              'code': response.code,
            })

            // console.log("----",response);

            // this.storageService.secureStorage.setItem('UserDetails',response.data[0]);

            this.loading = false;
            this.isWebRequest = false;
            this.loading = false;
            this.redirecting = true;
            this.spinner.hide();
            if (response.Applications.length > 1) {
              this.router.navigate(['/ad-login']);
            } else {
              // this.router.navigate([response.Applications[0].route]);
              this.router.navigate(['/home/dsa-dashboard'])
            }
          }
        },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          }
          this.isWebRequest = false;
          // setTimeout(() => { this.responseMsg = '' }, 3000)
          this.loading = false;
        }
      );
    }
  }

  // ADFS
  // initializeOAuthService() {
  //   this.spinner.show();
  //   //UAT
  //   // this.oauthService.configure({
  //   //   // redirectUri: 'https://10.21.240.170',
  //   //   redirectUri: 'https://ezflouat.insideabc.com',
  //   //   // redirectUri: 'http://localhost:4200',
  //   //   clientId: '7e07c433-b3a1-4b4b-9c56-e62583e3dd77',
  //   //   requireHttps: false,
  //   //   loginUrl: 'https://login.adityabirlacapital.com/adfs/oauth2/authorize/',
  //   //   issuer: environment.adfsUrl,
  //   //   scope: "openid profile",
  //   //   responseType: 'id_token',
  //   //   oidc: true,
  //   //   jwks: {
  //   //     keys: [
  //   //       {
  //   //         kty: "RSA",
  //   //         use: "sig",
  //   //         alg: "RS256",
  //   //         kid: "a2UozDsYOmN4nwAZq52XjA_vjNc",
  //   //         x5t: "a2UozDsYOmN4nwAZq52XjA_vjNc",
  //   //         n: "sZV1fU-K_s8HExLpIvH5NK46NIoBopCMfXnTt5Q_G3GrewGSEG1v6tOCc1zB9duqaEf56C8ZVr39k18gyUtzE_J7WOt5uUOWQqDAN5KeCk30PfOIBLpxnNeMb8hn7ECNFMX1jsJpt46BvQwo607TvUeDuxVW7FtCWzxX1QC7vFAm-oezQsJJPrkoxkESXtHGolw2xI2qpQ4c0qe4UWTk0HqfM_w5zdv3CkbZu5YIsybvy8OvIDg_dQOqjbSKi9d9FlWa-Vyz_WQhXCT_2T0UVMgtvfzuHJRyf-nnxXqLOIHGlOCQznGfTUPrzxz6_2Q6l38SZt_Q8wLpL9guuk0t1Q",
  //   //         e: "AQAB",
  //   //         x5c: [
  //   //           "MIIC9DCCAdygAwIBAgIQd/Khmq/CDbBBipBxehxNqDANBgkqhkiG9w0BAQsFADA2MTQwMgYDVQQDEytBREZTIFNpZ25pbmcgLSBsb2dpbi5hZGl0eWFiaXJsYWNhcGl0YWwuY29tMB4XDTIxMDIyMTEwNTMzMVoXDTI2MDIyMjEwNTMzMVowNjE0MDIGA1UEAxMrQURGUyBTaWduaW5nIC0gbG9naW4uYWRpdHlhYmlybGFjYXBpdGFsLmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALGVdX1Piv7PBxMS6SLx+TSuOjSKAaKQjH1507eUPxtxq3sBkhBtb+rTgnNcwfXbqmhH+egvGVa9/ZNfIMlLcxPye1jreblDlkKgwDeSngpN9D3ziAS6cZzXjG/IZ+xAjRTF9Y7CabeOgb0MKOtO071Hg7sVVuxbQls8V9UAu7xQJvqHs0LCST65KMZBEl7RxqJcNsSNqqUOHNKnuFFk5NB6nzP8Oc3b9wpG2buWCLMm78vDryA4P3UDqo20iovXfRZVmvlcs/1kIVwk/9k9FFTILb387hyUcn/p58V6iziBxpTgkM5xn01D688c+v9kOpd/Embf0PMC6S/YLrpNLdUCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAIAlIN5rqQHQWftTGJncYKzc8IvEzL/8SuDlA+QTgoderDdwDSd5w3RkEQqv83WB2warbfmbFh35PlyRDKV0ZlQjxJWqIXwC7LUjkdLaF4TdzgUm/M8YBoJV6PZUQTx2WSKi9+gbBKZfTSlXiuAieRl749ZyLKj3gukDCUjOMhKDJAWQ9XFmmD7ad95FysSOpiul8PVkKhdQy9lSPskvPcKPrUtaQsOeHZYEAGaQOw2P2sOl8imXIXPbTaMwcSV0hguytfGM4NzMcSmzANTPXFOA5Bo1A2/wfl/ig6IKpslY7FMBNCViVvqQbFY3dpDETcRv/IJ7a089uWaUp+afndA=="
  //   //         ]
  //   //       }
  //   //     ]
  //   //   },
  //   //   logoutUrl: 'https://login.adityabirlacapital.com/adfs/oauth2/logout',
  //   //   postLogoutRedirectUri: location.protocol + '//' +
  //   //     location.hostname + (location.port ? ':' + location.port : '')
  //   // });


  //   //Production 
  //   // this.oauthService.configure({
  //   //   redirectUri: 'https://ezportal.adityabirlacapital.com',
  //   //   clientId: 'efe6531e-b8b1-4d23-ac73-68d00ff0dea5',
  //   //   requireHttps: false,
  //   //   loginUrl: 'https://login.adityabirlacapital.com/adfs/oauth2/authorize/',
  //   //   issuer: environment.adfsUrl,
  //   //   scope: "openid profile",
  //   //   responseType: 'id_token',
  //   //   oidc: true,
  //   //   jwks: {
  //   //     keys: [
  //   //       {
  //   //         kty: "RSA",
  //   //         use: "sig",
  //   //         alg: "RS256",
  //   //         kid: "a2UozDsYOmN4nwAZq52XjA_vjNc",
  //   //         x5t: "a2UozDsYOmN4nwAZq52XjA_vjNc",
  //   //         n: "sZV1fU-K_s8HExLpIvH5NK46NIoBopCMfXnTt5Q_G3GrewGSEG1v6tOCc1zB9duqaEf56C8ZVr39k18gyUtzE_J7WOt5uUOWQqDAN5KeCk30PfOIBLpxnNeMb8hn7ECNFMX1jsJpt46BvQwo607TvUeDuxVW7FtCWzxX1QC7vFAm-oezQsJJPrkoxkESXtHGolw2xI2qpQ4c0qe4UWTk0HqfM_w5zdv3CkbZu5YIsybvy8OvIDg_dQOqjbSKi9d9FlWa-Vyz_WQhXCT_2T0UVMgtvfzuHJRyf-nnxXqLOIHGlOCQznGfTUPrzxz6_2Q6l38SZt_Q8wLpL9guuk0t1Q",
  //   //         e: "AQAB",
  //   //         x5c: [
  //   //           "MIIC9DCCAdygAwIBAgIQd/Khmq/CDbBBipBxehxNqDANBgkqhkiG9w0BAQsFADA2MTQwMgYDVQQDEytBREZTIFNpZ25pbmcgLSBsb2dpbi5hZGl0eWFiaXJsYWNhcGl0YWwuY29tMB4XDTIxMDIyMTEwNTMzMVoXDTI2MDIyMjEwNTMzMVowNjE0MDIGA1UEAxMrQURGUyBTaWduaW5nIC0gbG9naW4uYWRpdHlhYmlybGFjYXBpdGFsLmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALGVdX1Piv7PBxMS6SLx+TSuOjSKAaKQjH1507eUPxtxq3sBkhBtb+rTgnNcwfXbqmhH+egvGVa9/ZNfIMlLcxPye1jreblDlkKgwDeSngpN9D3ziAS6cZzXjG/IZ+xAjRTF9Y7CabeOgb0MKOtO071Hg7sVVuxbQls8V9UAu7xQJvqHs0LCST65KMZBEl7RxqJcNsSNqqUOHNKnuFFk5NB6nzP8Oc3b9wpG2buWCLMm78vDryA4P3UDqo20iovXfRZVmvlcs/1kIVwk/9k9FFTILb387hyUcn/p58V6iziBxpTgkM5xn01D688c+v9kOpd/Embf0PMC6S/YLrpNLdUCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAIAlIN5rqQHQWftTGJncYKzc8IvEzL/8SuDlA+QTgoderDdwDSd5w3RkEQqv83WB2warbfmbFh35PlyRDKV0ZlQjxJWqIXwC7LUjkdLaF4TdzgUm/M8YBoJV6PZUQTx2WSKi9+gbBKZfTSlXiuAieRl749ZyLKj3gukDCUjOMhKDJAWQ9XFmmD7ad95FysSOpiul8PVkKhdQy9lSPskvPcKPrUtaQsOeHZYEAGaQOw2P2sOl8imXIXPbTaMwcSV0hguytfGM4NzMcSmzANTPXFOA5Bo1A2/wfl/ig6IKpslY7FMBNCViVvqQbFY3dpDETcRv/IJ7a089uWaUp+afndA=="
  //   //         ]
  //   //       }
  //   //     ]
  //   //   },
  //   //   logoutUrl: 'https://login.adityabirlacapital.com/adfs/oauth2/logout',
  //   //   postLogoutRedirectUri: location.protocol + '//' +
  //   //     location.hostname + (location.port ? ':' + location.port : '')
  //   // });

  //   this.oauthService.configure({
  //     redirectUri: 'https://ezportal.adityabirlacapital.com',
  //     clientId: 'efe6531e-b8b1-4d23-ac73-68d00ff0dea5',
  //     requireHttps: false,
  //     loginUrl: 'https://login.adityabirlacapital.com/adfs/oauth2/authorize/',
  //     issuer: environment.adfsUrl,
  //     scope: "openid profile",
  //     responseType: 'id_token',
  //     oidc: true,
  //     jwks: {
  //       keys: [
  //         {
  //           kty: "RSA",
  //           use: "sig",
  //           alg: "RS256",
  //           kid: "a2UozDsYOmN4nwAZq52XjA_vjNc",
  //           x5t: "a2UozDsYOmN4nwAZq52XjA_vjNc",
  //           n: "sZV1fU-K_s8HExLpIvH5NK46NIoBopCMfXnTt5Q_G3GrewGSEG1v6tOCc1zB9duqaEf56C8ZVr39k18gyUtzE_J7WOt5uUOWQqDAN5KeCk30PfOIBLpxnNeMb8hn7ECNFMX1jsJpt46BvQwo607TvUeDuxVW7FtCWzxX1QC7vFAm-oezQsJJPrkoxkESXtHGolw2xI2qpQ4c0qe4UWTk0HqfM_w5zdv3CkbZu5YIsybvy8OvIDg_dQOqjbSKi9d9FlWa-Vyz_WQhXCT_2T0UVMgtvfzuHJRyf-nnxXqLOIHGlOCQznGfTUPrzxz6_2Q6l38SZt_Q8wLpL9guuk0t1Q",
  //           e: "AQAB",
  //           x5c: [
  //             "MIIC9DCCAdygAwIBAgIQd/Khmq/CDbBBipBxehxNqDANBgkqhkiG9w0BAQsFADA2MTQwMgYDVQQDEytBREZTIFNpZ25pbmcgLSBsb2dpbi5hZGl0eWFiaXJsYWNhcGl0YWwuY29tMB4XDTIxMDIyMTEwNTMzMVoXDTI2MDIyMjEwNTMzMVowNjE0MDIGA1UEAxMrQURGUyBTaWduaW5nIC0gbG9naW4uYWRpdHlhYmlybGFjYXBpdGFsLmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALGVdX1Piv7PBxMS6SLx+TSuOjSKAaKQjH1507eUPxtxq3sBkhBtb+rTgnNcwfXbqmhH+egvGVa9/ZNfIMlLcxPye1jreblDlkKgwDeSngpN9D3ziAS6cZzXjG/IZ+xAjRTF9Y7CabeOgb0MKOtO071Hg7sVVuxbQls8V9UAu7xQJvqHs0LCST65KMZBEl7RxqJcNsSNqqUOHNKnuFFk5NB6nzP8Oc3b9wpG2buWCLMm78vDryA4P3UDqo20iovXfRZVmvlcs/1kIVwk/9k9FFTILb387hyUcn/p58V6iziBxpTgkM5xn01D688c+v9kOpd/Embf0PMC6S/YLrpNLdUCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAIAlIN5rqQHQWftTGJncYKzc8IvEzL/8SuDlA+QTgoderDdwDSd5w3RkEQqv83WB2warbfmbFh35PlyRDKV0ZlQjxJWqIXwC7LUjkdLaF4TdzgUm/M8YBoJV6PZUQTx2WSKi9+gbBKZfTSlXiuAieRl749ZyLKj3gukDCUjOMhKDJAWQ9XFmmD7ad95FysSOpiul8PVkKhdQy9lSPskvPcKPrUtaQsOeHZYEAGaQOw2P2sOl8imXIXPbTaMwcSV0hguytfGM4NzMcSmzANTPXFOA5Bo1A2/wfl/ig6IKpslY7FMBNCViVvqQbFY3dpDETcRv/IJ7a089uWaUp+afndA=="
  //           ]
  //         }
  //       ]
  //     },
  //     logoutUrl: 'https://login.adityabirlacapital.com/adfs/oauth2/logout',
  //     postLogoutRedirectUri: location.protocol + '//' +
  //       location.hostname + (location.port ? ':' + location.port : '')
  //   });

  //   this.oauthService.setupAutomaticSilentRefresh();
  //   this.oauthService.timeoutFactor = 0.9;

  //   this.oauthService.tokenValidationHandler = new JwksValidationHandler();
  //   this.oauthService.setStorage(localStorage);

  //   if (!this.oauthService.hasValidAccessToken()) {
  //     // console.log("NPA ========", !this._auth.getUserInfoSorage(),this.oauthService.hasValidAccessToken());

  //     if (!this._auth.getUserInfoSorage()) {

  //       this.oauthService.tryLogin()
  //         .then((data) => {
  //           // console.log("NPA data========", data);
  //           // console.log("NPA this.oauthService.hasValidAccessToken()========", this.oauthService.hasValidAccessToken());

  //           if (!this.oauthService.hasValidAccessToken()) {
  //             // this.oauthService.initImplicitFlow();

  //             // 2. SILENT LOGIN:
  //             // Try to log in via silent refresh because the IdServer
  //             // might have a cookie to remember the user, so we can
  //             // prevent doing a redirect:
  //             this.oauthService.silentRefresh()
  //               .catch(result => {
  //                 // console.log("NPA this.result.hasValidAccessToken()========", result);

  //                 // Subset of situations from https://openid.net/specs/openid-connect-core-1_0.html#AuthError
  //                 // Only the ones where it's reasonably sure that sending the
  //                 // user to the IdServer will help.
  //                 const errorResponsesRequiringUserInteraction = [
  //                   'interaction_required',
  //                   'login_required',
  //                   'account_selection_required',
  //                   'consent_required',
  //                 ];
  //                 // console.log("NPA result && result.reason && errorResponsesRequiringUserInteraction.indexOf(result.reason.error) >= 0========", (!result.reason), result && result.reason && errorResponsesRequiringUserInteraction.indexOf(result.reason.error) >= 0);

  //                 if ((result && result.reason && errorResponsesRequiringUserInteraction.indexOf(result.reason.error) >= 0) || (!result.reason)) {

  //                   // 3. ASK FOR LOGIN:
  //                   // At this point we know for sure that we have to ask the
  //                   // user to log in, so we redirect them to the IdServer to
  //                   // enter credentials:
  //                   if (!window.location.href.includes('id_token=')) {
  //                     this.spinner.hide();

  //                     this.oauthService.initImplicitFlow();
  //                   }
  //                 }
  //               });

  //           }
  //         });
  //     } else {
  //       this.spinner.hide();

  //     }
  //   }
  // }

  // CyberArk
  initializeOAuthService() {
    this.spinner.show();
    
    // UAT
    this.oauthService.configure({
      // redirectUri: 'https://10.21.240.170',
      redirectUri: 'https://ezportal.adityabirlacapital.com/',
      // redirectUri: 'https://ezflo.adityabirlacapital.com',
      clientId: 'a3d1b54b-48df-47e0-aa8b-a277094aa632',
      requireHttps: false,
      loginUrl: 'https://aaq4824.id.cyberark.cloud/OAuth2/Authorize/abhflezportalprod',
      issuer: environment.cyberArkUrl,
      scope: "openid profile",
      responseType: 'id_token',
      oidc: true,
      jwks: {
        "keys": [
          {
            "kty": "RSA",
            "use": "sig",
            "alg": "RS256",
            "kid": "97CBE7F0BD6E58BA574B82E480C8361F10745143",
            // "x5t": "97CBE7F0BD6E58BA574B82E480C8361F10745143",
            "n": "rW3r8pBx8v_ow0F7JP6Dbd48N8_GWR_fbmaOWI0zn1py7g3jQnF1krkEtdS6rzBxmKbRTS_rVosqIp2Rl0r05G2SHbKrEzHMhFF-hcYJC7JFKWjMBGRKDNjQSR5H1-ycBN6WeonqX1AcvVYdpCd1i2-kIL_ZybRmg0n2iaAVTqcvHaehL6GNMwRTCM6reXUfLfFG1X48IusDy7Qz27Pw5H5z8siyF_t4yVevfZAfGUI5B_aB7FjDtQeMjkb-hqFQUGctE8HoHGNIQ8t87r8jRjPK4M7He6T2w8LZ-XI9msUdFe86hMov13MYDPrxnvjy9K4PQsp-6-udLyqh_BP7Nw",
            "e": "AQAB",
            // x5c: [
            //   "MIIDkzCCAn2gAwIBAgIQVGHEKnpLWUeh239cDntfnzALBgkqhkiG9w0BAQswJDEiMCAGA1UEAwwZQ3liZXJBcmsgQ3VzdG9tZXIgQUFRNDgyNDAeFw0yMjEwMDIwODU0MTJaFw0zOTAxMDEwMDAwMDBaMDIxMDAuBgNVBAMMJ0FBUTQ4MjQgQXBwbGljYXRpb24gU2lnbmluZyBDZXJ0aWZpY2F0ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK1t6/KQcfL/6MNBeyT+g23ePDfPxlkf325mjliNM59acu4N40JxdZK5BLXUuq8wcZim0U0v61aLKiKdkZdK9ORtkh2yqxMxzIRRfoXGCQuyRSlozARkSgzY0EkeR9fsnATelnqJ6l9QHL1WHaQndYtvpCC/2cm0ZoNJ9omgFU6nLx2noS+hjTMEUwjOq3l1Hy3xRtV+PCLrA8u0M9uz8OR+c/LIshf7eMlXr32QHxlCOQf2gexYw7UHjI5G/oahUFBnLRPB6BxjSEPLfO6/I0YzyuDOx3uk9sPC2flyPZrFHRXvOoTKL9dzGAz68Z748vSuD0LKfuvrnS8qofwT+zcCAwEAAaOBtjCBszATBgorBgEEAYKmcAEJBAUMAzEuMDAXBgorBgEEAYKmcAEDBAkMB0FBUTQ4MjQwKwYDVR0jBCQwIoAgYZnRbtScRLTvgdB3WcX1wBwy9QWL83WxJNQ153v9IHkwKQYDVR0OBCIEIE/gh25xx2FQ+6s572JEC63IUWVOxBJskOaRjKjEYJBDMA4GA1UdDwEB/wQEAwIFoDAbBgorBgEEAYKmcAEEBA0MC0FwcGxpY2F0aW9uMAsGCSqGSIb3DQEBCwOCAQEAmu43q06BKMuTQKgBP57CkY8ANTwyXKX7hTDg60c+df1FJi9RLmv2g1yzYctPjldYU8QGHZFWNqk9ORVg63GTN40o/SnKOY7CyOdtZeK3aTItNLAhB4mzFe6FyCpSNvcWoVW+UrEcTyMla78C87r7p0PhqcS6cXYdBvuyHtxHXaitJQt19IiKCY316c6LZtWUTs45iDo0+kWDFEm6FFYBw5TXtJCKeZnO2oDmo4Wdac3GVJKJccTpp1I3bdVYk+jtIzsE0hg0HsA+A/XJ6HapBj60ilsnsoilXgoLPkJ6aMCe2v8FM5HRhcn/zfPce756V5kT5fwv63RZqxgdD3MDzA=="
            // ]
          }
        ]
      },
      logoutUrl: 'https://login.adityabirlacapital.com/adfs/oauth2/logout',
      postLogoutRedirectUri: location.protocol + '//' +
        location.hostname + (location.port ? ':' + location.port : '')
    });

    this.oauthService.setupAutomaticSilentRefresh();
    this.oauthService.timeoutFactor = 0.9;

    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.setStorage(localStorage);

    if (!this.oauthService.hasValidAccessToken()) {
      // console.log("NPA ========", !this._auth.getUserInfoSorage(),this.oauthService.hasValidAccessToken());

      if (!this._auth.getUserInfoSorage()) {

        this.oauthService.tryLogin()
          .then((data) => {
            // console.log("NPA data========", data);
            // console.log("NPA this.oauthService.hasValidAccessToken()========", this.oauthService.hasValidAccessToken());

            if (!this.oauthService.hasValidAccessToken()) {
              // this.oauthService.initImplicitFlow();

              // 2. SILENT LOGIN:
              // Try to log in via silent refresh because the IdServer
              // might have a cookie to remember the user, so we can
              // prevent doing a redirect:
              this.oauthService.silentRefresh()
                .catch((result:any) => {
                  // console.log("NPA this.result.hasValidAccessToken()========", result);

                  // Subset of situations from https://openid.net/specs/openid-connect-core-1_0.html#AuthError
                  // Only the ones where it's reasonably sure that sending the
                  // user to the IdServer will help.
                  const errorResponsesRequiringUserInteraction = [
                    'interaction_required',
                    'login_required',
                    'account_selection_required',
                    'consent_required',
                  ];
                  // console.log("NPA result && result.reason && errorResponsesRequiringUserInteraction.indexOf(result.reason.error) >= 0========", (!result.reason), result && result.reason && errorResponsesRequiringUserInteraction.indexOf(result.reason.error) >= 0);

                  if ((result && result.reason && errorResponsesRequiringUserInteraction.indexOf(result.reason.error) >= 0) || (!result.reason)) {

                    // 3. ASK FOR LOGIN:
                    // At this point we know for sure that we have to ask the
                    // user to log in, so we redirect them to the IdServer to
                    // enter credentials:
                    if (!window.location.href.includes('id_token=')) {
                      this.spinner.hide();

                      this.oauthService.initImplicitFlow();
                    }
                  }
                });

            }
          });
      } else {
        this.spinner.hide();

      }
    }
  }

  public loadData() {
    this.valuesService.getValues()
      ?.subscribe((res: any) => {
      })
  }

  checkLogin(token: any) {
    let data = {
      token: token,
    }
    this.spinner.show();

    this._auth.checkLoginwithToken(data).subscribe((response: any) => {

      if (response.dsa_role != 'RM' || response.dsa_role == null) {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: "User not Authorised!",
          showConfirmButton: false,
          timer: 1500
        })
      } else {

        this._auth.token = response.token;
        this._auth.role = response.dsa_role;
        this._auth.name = response.name;
        this._auth.saveUserinfoToSorage({
          'empname': response.name,
          'version': response.version,
          'role': response.dsa_role,
          'token': response.token,
          'email': response.email,
          'code': response.code,
        })
        this.loading = false;
        this.isWebRequest = false;
        this.loading = false;
        this.redirecting = true;
        this.spinner.hide();
        this.router.navigate(['/home/dsa-dashboard'])
      }
    },
      (err: HttpErrorResponse) => {
        this.spinner.hide();

        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
          // this._webService.showalert('Server error', 'error');;
        }
      });

  }
}

