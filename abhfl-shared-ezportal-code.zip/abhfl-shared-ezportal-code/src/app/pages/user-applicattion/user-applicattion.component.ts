import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiService } from 'src/app/services/api.service';
import { AuthService } from 'src/app/services/auth.service';
import { StorageService } from 'src/app/services/storage.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2'
import { take } from 'rxjs';

@Component({
  selector: 'app-user-applicattion',
  templateUrl: './user-applicattion.component.html',
  styleUrls: ['./user-applicattion.component.scss']
})
export class UserApplicattionComponent implements OnInit {

  formSumitAttempt: any=false;
  address: any;
  applicationData: any;
  userInfo: any;
  directorData: any;
  addressData: any;
  referenceData: any;
  permantAddress: any;
  currentAddress: any;
  officeAddress: any;
  DocList: any[]=[];
  DocUserList: any[]=[];
  directorDoc: any[]=[];
  userDoc: any[]=[];
  flag: any;
  DocList1: any[]=[];
  path: string;

  constructor( private fb:FormBuilder, private _auth:AuthService,public _apiService:ApiService, private storageService:StorageService,private spinner: NgxSpinnerService, private router:Router) { }

  ngOnInit(): void {
    this.path = environment.imgUrl +'uploads/dsa_front/'
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    this.getApplicationData();

    // console.log("data",this.data);

  }

  getApplicationData(){
    this._apiService.getApplication({ token:this.userInfo.token}).subscribe((res) => {
    
      if (!res.error ) {
        this.spinner.hide();
        this.applicationData = res.data[0];
        this.directorData = res.directorData;
        this.addressData = res.addressData;
        this.referenceData = res.referenceData;
        this.permantAddress = this.addressData.find((ele:any) => ele.address_type == 'Permanent');
        this.currentAddress = this.addressData.find((ele:any) => ele.address_type == 'Current');
        this.officeAddress = this.addressData.find((ele:any) => ele.address_type == 'Office');

        this.getCaseDocType();

        // console.log("this.applicationDatathis.applicationDatathis.applicationData",this.applicationData);
      }


    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }


  getCaseDocType(){
    this.spinner.show();
    // caseId:this.userDetails.case_id ,
    this._apiService.getCaseDocType({ 
      token:this.userInfo.token,
      caseId:this.applicationData.case_id
    }).subscribe((res:any)=>{
      if(!res.error){

        this.DocList=[];
        this.DocList1=[];
        this.DocUserList=[];
        this.directorDoc=[];
        this.userDoc=[];
    
        this.flag = res.address_flag
        this.DocList = res.data[0].document;
        this.DocUserList = res.data[0].document[0].file;

        this.DocUserList.forEach((element:any) => {
          if(element.Designation == 'Applicant'){
            this.userDoc.push(element)
          }else{
            if(res.data[0].constitution_type !='Individual'){
              this.directorDoc.push(element)
            }
          }
        });

        this.DocList.forEach((item:any, index:any) => {
          if(item.document_type != 'Aadhar Photo' || (item.document_type == 'Address Proof' && item.file.length > 0) )  {
            this.DocList1.push(item);
          }
        });

        // console.log("this.DocList1this.DocList1this.DocList1",this.DocList1);
        this.spinner.hide();

        // res.data[0].document[0].photo.forEach((element:any) => {
        //   this.child.callMe(this.path + element.fileName);
        // });


      }else{
        this.spinner.hide();
      }
    })
  }


  navigateTo(){
    this.router.navigate(['/home'])
  }



  downloadDocuments(id:any){
    this.spinner.show();
    this._apiService.downloadDocuments({"DID":id}).pipe(
      take(1)
  ).subscribe((resp:any) => {

    // const contentDisposition = resp.headers.get('content-disposition');
    // const filename = this.getFilenameFromContentDisposition(contentDisposition);

    // console.log("resp.headers",resp.headers);
    
    var contentDisposition = resp.headers.get('content-disposition');
    var filename = contentDisposition.split(';')[1].split('filename')[1].split('=')[1].trim().replaceAll('"', '');

      let downloadLink = document.createElement('a');
      downloadLink.href = window.URL.createObjectURL(resp.body);
      downloadLink.setAttribute('download',filename);
      document.body.appendChild(downloadLink);
      downloadLink.click();
      downloadLink.remove();
      this.spinner.hide();
  });
  }


}
