import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserApplicattionComponent } from './user-applicattion.component';

describe('UserApplicattionComponent', () => {
  let component: UserApplicattionComponent;
  let fixture: ComponentFixture<UserApplicattionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserApplicattionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserApplicattionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
