import { environment } from './../../../environments/environment.prod';
import { StorageService } from './../../services/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';
import { MatDialog } from '@angular/material/dialog';
import { ActivityFiltersComponent } from 'src/app/modals/activity-filters/activity-filters.component';
import { ViewQueryComponent } from 'src/app/modals/view-query/view-query.component';
import { RaisedQueryComponent } from 'src/app/modals/raised-query/raised-query.component';
import { EventService } from 'src/app/services/events.service';
import { from, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
@Component({
  selector: 'app-incentive-queries',
  templateUrl: './incentive-queries.component.html',
  styleUrls: ['./incentive-queries.component.scss']
})
export class IncentiveQueriesComponent implements OnInit {
  ExternalQueryOpen: any;
  ExternalQueryInProgress: any;
  ExternalQueryResolved: any;
  queryData: any;
  type: any='Reopen';
  applicationstepIndicator: any = 1;
  comment: any=null;
  file: any=[];
  userData: any;
  applicationData: any;
  userInfo: any;
  filePath: string;
  completed: any;
  inProgress: any;
  action: any;
  queryList: any=[];
  docId: string;
  id: any;
  sub: any;
  constructor(private eventService: EventService,private route: ActivatedRoute,public dialog: MatDialog , private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, public storageService:StorageService, private spinner: NgxSpinnerService ) { }

  ngOnInit(): void {

    
    this.eventService.activityAddComment.pipe(takeUntil(this.ngUnsubscribe)).subscribe(
      (payload: any) => {
        console.log("----payloadpayloadpayload---->",payload);
        this.getcaseQueryCount();
        this.getdocumentqueryList();
        if (payload) {
          if (window.location.href.toString().includes('')) {
            this.getcaseQueryCount();
            this.getdocumentqueryList();
          }
          payload.flag = false;
        }
      })


    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id'];
     console.log("==ifffff=>", this.sub , this.id);
  ;
   });
    this.docId='D102';
    this.filePath = environment.imgUrl;
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
   // this.getCaseData();
  this.getcaseQueryCount();
  this.getdocumentqueryList();
    // this.getcaseApplicationandQueryDetails();
    // this.getcaseQueryDetails(this.type);
  }

  private ngUnsubscribe = new Subject();

  ngOnDestroy() {
    this.ngUnsubscribe.next(true);
    this.ngUnsubscribe.complete();
  }
  getType(type:any)
  {
    this.type=type;
    this.getdocumentqueryList();
    this.getcaseQueryCount();
   // this.getcaseQueryDetails(type)
  }


  
  openFilterDialog(item:any): void {
    const dialogRef = this.dialog.open(ViewQueryComponent, {
      data: {'item':item,'id':this.docId,type:this.type},
     //  width:'80%', 
      panelClass:'large-css1'
     /*  data1:this.docId, */
    //  maxWidth: '100vw',
      /* width:'80%', */
     /*  height: '400px',
      width: '600px', */
    /* height: '96%',
      minWidth: '95%',
      closeOnNavigation: true,
      disableClose: true, */
     /*  maxWidth: '100vw',
      maxHeight: '100vh',
      height: '100%',
      width: '100%',
      disableClose: true, */
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        dialogRef.close();
        this.getcaseQueryCount();
        this.getdocumentqueryList();
      }
  
    });
    
  }
  raisedQuery(): void {
    const dialogRef = this.dialog.open(RaisedQueryComponent, {
      data:this.docId,
      disableClose: true,
      panelClass:'small-css'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        dialogRef.close();
        this.getcaseQueryCount();
        this.getdocumentqueryList();
      }
  
    });
  }
  getCaseData(){
 
//this.spinner.show();
      let data = {
        // caseId: 20,.
        token:this.userInfo.token,
        version:this.userInfo.version,
        // phoneNo: this.userInfo.phone_no
      }
     
      this._apiService.getApplication(data).subscribe((res) => {
  
        
        if (res.error == true) {
          this.spinner.hide();
          this.applicationstepIndicator = 1
        } else {
          this.spinner.hide();
          this.applicationData = res;
          this.getcaseApplicationandQueryDetails();
          this.getcaseQueryDetails(this.type);
         
        }
  
        // this.getcaseApplicationandQueryDetails();
        // this.getcaseQueryDetails(this.type);
  
      }, (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
  
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title:err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
            showConfirmButton: false,
            timer: 1500
          })
        }
        // this.isWebRequest = false;
      })

  }






  getcaseApplicationandQueryDetails() {
   // this.spinner.show();
    let data = {
      ApplicationID: this.applicationData.data[0].new_case_id,
      token:this.storageService.secureStorage.getItem('token'),
      version:this.storageService.secureStorage.getItem('version')
    }
    this._apiService.getcaseApplicationandQueryDetails(data).subscribe((res) => {
      if (res.error == true) {
        this.spinner.hide();
        this.applicationstepIndicator = 1
      } else {
        this.spinner.hide();
        this.ExternalQueryOpen = res.applicationData[0].ExternalQueryOpen;
        this.ExternalQueryInProgress = res.applicationData[0].ExternalQueryInProgress;
        this.ExternalQueryResolved = res.applicationData[0].ExternalQueryResolved;
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title:err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }



  getcaseQueryDetails(types:any) {
    this.type=types
  //  this.spinner.show();
    let data = {
      ApplicationID: this.applicationData.data[0].new_case_id,
      token:this.userInfo.token,
      version:this.userInfo.version,
      documentID:this.docId
    }
    this._apiService.getincentiveQueryDetails(data).subscribe((res) => {
      if (res.error == true) {
        this.spinner.hide();
        this.applicationstepIndicator = 1
      } else {
        this.spinner.hide();
        this.queryData = res.queryData;

        console.log( this.queryData, this.queryData);
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title:err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }


  getcaseQueryCount() {
    this.spinner.show();
// data={"fromDate":"2022-01-05","toDate":"2023-01-04","partnerType":"","eventTitle":"","eventType":"","type":"Queries","searchTerm":"","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjE4ODMsImlhdCI6MTY3Mjc0MTkzMSwiZXhwIjoxNjg4NTA5OTMxfQ.5vgwYu8W0Bdax5pi5reHUwv3ARCE4qy5XuVpttO3PoI","version":19,"filterType":"Range"}
    // data.type = data.type !='All'?data.type :''
    let data = {
      token:this.userInfo.token,//'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjE4ODMsImlhdCI6MTY3NjAzNDYyMCwiZXhwIjoxNjkxODAyNjIwfQ.eDbRh9dh8sPtdflgEnXfqjzKhFF61cgjMkRbkBuBJao',//this.storageService.secureStorage.getItem('token'),
      version:this.userInfo.version,//this.storageService.secureStorage.getItem('version'),
      documentID:this.docId
    }
    this._apiService.getincentiveQueryDetails(data).subscribe((res) => {
      // console.log(">>.>.>", res)
      this.queryData = res;
      console.log(">>.>.>", this.queryData);
    
      this.completed=this.queryData.completed,
      this.inProgress=this.queryData.inProgress,
      this.action=this.queryData.action,

      this.spinner.hide();

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }

    })
  }

  
  getdocumentqueryList() {
    this.spinner.show();
// data={"fromDate":"2022-01-05","toDate":"2023-01-04","partnerType":"","eventTitle":"","eventType":"","type":"Queries","searchTerm":"","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjE4ODMsImlhdCI6MTY3Mjc0MTkzMSwiZXhwIjoxNjg4NTA5OTMxfQ.5vgwYu8W0Bdax5pi5reHUwv3ARCE4qy5XuVpttO3PoI","version":19,"filterType":"Range"}
    // data.type = data.type !='All'?data.type :''
    let data = 
    {
    token:this.userInfo.token,//"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjE4ODMsImlhdCI6MTY3NjAzNDYyMCwiZXhwIjoxNjkxODAyNjIwfQ.eDbRh9dh8sPtdflgEnXfqjzKhFF61cgjMkRbkBuBJao",
    version:this.userInfo.version,
    type :this.type,
    documentId: this.docId
}
    this._apiService.getdocumentqueryList(data).subscribe((res) => {
      // console.log(">>.>.>", res)
      this.queryList = res.queryData;
      this.completed=this.queryData.completed,
      this.inProgress=this.queryData.inProgress,
      this.action=this.queryData.action,

      this.spinner.hide();

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }

    })
  }

  

  
  getcaseQueryCount1() {
  //  this.spinner.show();
    let data = {
      ApplicationID: this.applicationData.data[0].new_case_id,
      token:this.storageService.secureStorage.getItem('token'),
      version:this.storageService.secureStorage.getItem('version'),
      documentID:"D101"
    }
    this._apiService.getincentiveQueryDetails(data).subscribe((res) => {
      if (res.error == true) {
        this.spinner.hide();
        this.applicationstepIndicator = 1
      } else {
        this.spinner.hide();
        this.queryData = res.queryData;

        console.log( this.queryData, this.queryData);
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title:err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }


  changeComment(event:any)
  {
    this.comment=event.target.value
  }

  updatecaseQueryDetails(item:any) {
    // console.log('this.comment ================ ',this.comment,item,this.file)
  
    if(this.comment =="" || this.comment == null)
    {
      {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Please enter comment',
          showConfirmButton: false,
          timer: 1500
        })
       }
    }
    else {
      
      if(item.QueryType == 'Document' && this.file.length == 0)
      {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'Please upload document.',
            showConfirmButton: false,
            timer: 1500
          })
        
      }
      else {


        // let data = {
        //   ApplicationID: "D2022082400002",
        //   QueryNo: qid,
        //   QueryType: "External",
        //   UpdatedText: this.comment,
        //   DMSId:"1111"
        // }
        this.spinner.show();

        const dataUp = new FormData();
        dataUp.append('file',this.file)
        dataUp.append('ApplicationID', this.applicationData.data[0].new_case_id)
        // dataUp.append('QueryNo',item.QueryNo)
        dataUp.append('QueryNo',item.QueryNo) 
        // token:this.userInfo.token,
        // version:this.userInfo.version,
        dataUp.append('QueryType','External') 
        dataUp.append('DMSId','1111')
        dataUp.append('UpdatedText',this.comment)
        dataUp.append('NewQueryNo',item.NewQueryNo)
        dataUp.append( 'documentType',item.QueryType)
        dataUp.append( 'token',this.userInfo.token)
        dataUp.append( 'version',this.userInfo.version)
       


        this._apiService.updatecaseQueryDetails(dataUp).subscribe((res) => {
          if (res.error == true) {
            this.spinner.hide();
            this.applicationstepIndicator = 1
          } else {

            this.spinner.hide();
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: res.message,
              showConfirmButton: false,
              timer: 1500
            })

            this.getcaseApplicationandQueryDetails();
            this.getcaseQueryDetails(this.type);
          }

        }, (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title:err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
              showConfirmButton: false,
              timer: 1500
            })
          }
          // this.isWebRequest = false;
        })
      }
    }
      
  }

  
  uploadDoc(event:any){

    if(event.target.files[0].size > 5242880){
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: "Document size should be up to 5MB",
        showConfirmButton: false,
        timer: 1500
      })
      this.spinner.hide();
      return;
    }
    
    if(event.target.files[0].type == 'image/png' || event.target.files[0].type == 'image/jpeg' || event.target.files[0].type == 'image/jpg' ||event.target.files[0].type == 'application/pdf' || event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || event.target.files[0].type == 'vnd.ms-excel' || event.target.files[0].type == 'application/msword'|| event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'){
      this.file = event.target.files[0]
      console.log("----a",this.file)
    }else{
      // this.spinner.hide();
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Please upload pdf, jpg , jpeg ,doc,excel or  png image',
        showConfirmButton: false,
        timer: 1500
      })
    }

    
    
    // console.log("filefilefile",this.file);
  }

  navigateTo(){
    this.router.navigate(['/home'])
  }

  formatBytes(bytes:any, decimals = 2) {
    if (!+bytes) return '0 Bytes'

    const k = 1024
    const dm = decimals < 0 ? 0 : decimals
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']

    const i = Math.floor(Math.log(bytes) / Math.log(k))

    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`
}
  

}
