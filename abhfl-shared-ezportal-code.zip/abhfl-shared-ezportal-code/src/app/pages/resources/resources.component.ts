import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { StorageService } from 'src/app/services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import { TrainingComponent } from 'src/app/modals/training/training.component';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'app-resources',
  templateUrl: './resources.component.html',
  styleUrls: ['./resources.component.scss']
})
export class ResourcesComponent implements OnInit {
  userData: any;
  categoryData: any[]=[];
  categoryList: any[]=[];
  path: string;
  languageType :any = 'English'
  CatergoyId: any='All';
  completeCount: any;
  mandatoryCount: any;
  overlay: boolean;
  checked: any =false;
  completeFlag: boolean;
  temp: any[];
  step: any=0;
  userInfo: any;
  defaultLanguage:any="English";
  isLanguageFix:any=false;
  allContents:any;

  constructor(private _apiService:ApiService,private storageService:StorageService,public dialog: MatDialog, private spinner: NgxSpinnerService, private router:Router) { }

  ngOnInit(): void {
    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    this.userInfo = this.storageService.secureStorage.getItem("userinfo")

    this.path = environment.imgUrl

    // console.log("this.userDatathis.userData",this.userData);
    this.getCategory('');
    this.changeList(this.languageType,'auto',this.CatergoyId);
  }

  getCategory(Search:any){
    this.spinner.show();
    const data= new FormData();
     data.append('version', this.storageService.secureStorage.getItem('version'));
     data.append('role', this.userData.partner_type);
     data.append('mobile', this.userData.phone_no);
     data.append('token', this.userInfo.token);
     data.append('version', this.userInfo.version);

    this._apiService.getCategories(data).subscribe((response:any)=>{
      if(!response.error){
       
        // console.log("responseresponse",response);
        if(response.isCompleted){
          this.completeFlag = true ;
        }else{
          this.completeFlag = false ;
        }
        this.categoryData = response.data;
        this.temp = this.categoryData

        // console.log("this.categoryDatathis.categoryDatathis.categoryData",this.categoryData);
        this.spinner.hide();
      }else{
        this.spinner.hide();
      }
    },( (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    }))

  }

  setStep(value:any){
    // console.log(value);
    
    this.step = value ;
  }

  changeList(lagType:any,status:any,catId:any){
    this.spinner.show();
    if(status =='auto'){
      this.languageType = lagType
    }else{
      this.languageType = lagType.target.value;
    }
   
    // console.log("lagType,status,catId",lagType,status,catId);

    const data= new FormData();
     data.append('version', this.storageService.secureStorage.getItem('version'));
     data.append('role', this.userData.partner_type);
     data.append('mobile', this.userData.phone_no);
     data.append('token', this.userInfo.token);
     data.append('version', this.userInfo.version);

    this._apiService.getCategoryList(data).subscribe((response:any)=>{
      if(!response.error){
          if(response.language!=null){
            this.isLanguageFix=true
          this.languageType = this.defaultLanguage=response.language
      }



// console.log("..,.,mnb",response.language)
        this.categoryList=[];
        // this.categoryList = response.data;
        // response.data.map((content:any)=>{
        //   if(content.language==this.defaultLanguage){
        //     this.categoryList.push(content)
        //   }
        // })
        // this.allContents = response.data;
        this.categoryList = response.data.filter((ele:any)=> ele.language == this.languageType);
        // console.log("0000000000",this.languageType, this.categoryList)

        this.completeCount = this.categoryList.filter((x:any) => x.language == this.languageType && x.status === 'Completed').length
        this.mandatoryCount = this.categoryList.filter((x:any) => x.language == this.languageType && x.isMandatory === 1).length

        // console.log("this.completeCountthis.completeCount",this.completeCount,this.mandatoryCount);
        
        if(this.completeCount == this.mandatoryCount && this.categoryList.length > 0){
          this.overlay = true;

        }else{
          if(catId =='All'){
            this.CatergoyId = 'All';
          }else{
            this.CatergoyId = catId;
            this.categoryList = this.categoryList.filter((ele:any)=> ele.category_id == catId);
          }
        }
        this.spinner.hide();
      }else{
        this.spinner.hide();
      }
    },( (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }

    }))
  }

  understand(event:any){

    // console.log(event.checked);
    
    this.checked = event.checked
  }

  changeStatus(value:any,status:any){
    // this.spinner.show();
    const data= new FormData();
    data.append('role', this.userData.partner_type);
    data.append('mobile', this.userData.phone_no);
    data.append('document_id', value);
    data.append('status', status);
    data.append('token', this.userInfo.token);
     data.append('version', this.userInfo.version);



   this._apiService.updateResourceDocument(data).subscribe((response:any)=>{
     if(!response.error){
      //  this.categoryList = response.data;
       
       this.categoryList.find((ele:any) =>{
         if(ele.id == value){
           ele.status == status
          }
        })
        // console.log("Changeeeee",this.categoryList);

      
       this.changeList(this.languageType,'auto',this.CatergoyId);
       this.spinner.hide();
     }
   },( (err: HttpErrorResponse) => {
    // this.spinner.hide();
     if (err.status === 400) {
       Swal.fire({
         position: 'center',
         icon: 'success',
         title: err.error.message,
         showConfirmButton: false,
         timer: 1500
       })
      
     } else {
       Swal.fire({
         position: 'center',
         icon: 'error',
         title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
         showConfirmButton: false,
         timer: 1500
       })
     }

   }))
  }


  changeStatusOnCategory(id:any){
    this.categoryList = this.categoryList.filter((ele:any) => ele.category_id == id);
  }


  search(event:any){
    // console.log("cdscdscdscds",event.target.value);

    
    if(event.target.value){
    // this.categoryData = this.categoryData.filter((ele:any) => ele.category_name.toLowerCase() == event.target.value.toLowerCase() )
    this.categoryData = this.categoryData.filter((ele:any) => ele.category_name.toLowerCase().includes(event.target.value.toLowerCase()) )
    // x.toLowerCase().includes(word)
    }else{
     this.categoryData =  this.temp ;
    }

  }

  onSubmit(){
    this.spinner.show();
    const data= new FormData();
    data.append('version', this.storageService.secureStorage.getItem('version'));
    data.append('role', this.userData.partner_type);
    data.append('mobile', this.userData.phone_no);
    data.append('token', this.userInfo.token);
    data.append('version', this.userInfo.version);

    this._apiService.resourceCenterComplete(data).subscribe((response:any)=>{
     if(!response.error){
        // console.log("Changeeeee",response);
        this.spinner.hide();
        this.getCategory('');
        this.changeList(this.languageType,'auto',this.CatergoyId);
     }
   },( (err: HttpErrorResponse) => {
    this.spinner.hide();
     if (err.status === 400) {
       Swal.fire({
         position: 'center',
         icon: 'success',
         title: err.error.message,
         showConfirmButton: false,
         timer: 1500
       })

      
     } else {
       Swal.fire({
         position: 'center',
         icon: 'error',
         title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
         showConfirmButton: false,
         timer: 1500
       })
     }

   }))

    
  }

  navigateTo(){
    this.router.navigate(['/home'])
  }


}
