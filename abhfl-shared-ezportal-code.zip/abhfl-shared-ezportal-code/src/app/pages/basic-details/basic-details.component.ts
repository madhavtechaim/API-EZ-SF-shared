import { StorageService } from './../../services/storage.service';
import { AuthService } from './../../services/auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import Swal from 'sweetalert2'
import { MatDialog } from '@angular/material/dialog';
import { OtpComponent } from 'src/app/modals/otp/otp.component';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-basic-details',
  templateUrl: './basic-details.component.html',
  styleUrls: ['./basic-details.component.scss']
})
export class BasicDetailsComponent implements OnInit {
  ddd: string | null;
  userData: any;

  form: FormGroup;
  formSumitAttempt: boolean;
  isWebRequest: boolean = false;
  partnerTypeData: any;
  userDetails: any;
  emailVerify: boolean;
  mobileVerify: boolean;
  branchArray: any[] = [];
  userInfo: any;

  partnerList: any[] = [{ title: 'Referal Partner', value: 'Referal Partner' }, { title: 'Direct Selling Agent (DSA)', value: 'DSA' }];
  constitutionList: any[] = [{ title: 'Individual', value: 'Individual' }, { title: 'Proprietor', value: 'Proprietor' }, { title: 'Partnership /LLP', value: 'Partnership' }, { title: 'PVT', value: 'PVT' }, { title: 'HUF', value: 'HUF' }, { title: 'Public', value: 'Public' }];
  businessActivity: any[] = [
    { title: "Retail shop", value: "Retail shop" },
    { title: "Kirana", value: "Kirana" },
    { title: "Any other Business activities", value: "Any other Business activities" },
  ];
  personaOfChannelData: any[] = [
    { title: "Property Broker", value: "Property Broker" },
    { title: "Financial Planner", value: "Financial Planner" },
    { title: "Insurance Agent", value: "Insurance Agent" },
    { title: "Loan Advisor", value: "Loan Advisor" },
    { title: "CA", value: "CA" },
    { title: "Others", value: "Others" },
  ];
  topFisNameData: any[] = [
    { title: "0", value: 0 },
    { title: "1", value: 1 },
    { title: "2", value: 2 },
    { title: "3", value: 3 },
  ]

  filteredPartner: any[];
  filteredConstitution: any[];
  filteredAdvisory: any[];
  selectAdvisoryTypes: any[] = [
    {
      title: 'Select Advisory',
      value: 'Select Advisory'
    }
  ]
  isSelectAdvisory: boolean = false;
  branchList: any[] = [];
  filteredBranch: any[] = [];
  // filteredBankMaster: any = [];
  // bankMasterList: any = [];
  // businessActivities: any[] = [];
  // personaOfChannelDataList: any[] = [];
  // topFISNameDataList: any[] = [];
  // selectedFisName: any = 0;
  // selectedWithOtherBusinessDo: string;
  maxCount: any;
  constructor(private router: Router, private _formBuilder: FormBuilder, public _apiService: ApiService, public dialog: MatDialog, private storageService: StorageService, private _auth: AuthService, private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    this.form = this._formBuilder.group({
      fullName: ['', [Validators.required]],
      phoneNumber: [
        '',
        [Validators.required, Validators.pattern('[1-9]{1}[0-9]{9}')],
      ],
      emailAddress: ['', [Validators.required, Validators.email]],
      partnerType: ['', [Validators.required, this.requireMatch.bind(this)]],
      selectAdvisory: [
        this.selectAdvisoryTypes[0].title,
        [Validators.required, this.sourceRequireMatch.bind(this)],
      ],
      branch: ['', [Validators.required]],
      pincode: ['', [Validators.required, Validators.pattern('[0-9]{6}')]],
      ConstitutionType: [
        '',
        [Validators.required, this.requireMatch1.bind(this)],
      ],
      numberOfFIEmpanelled: ['',[Validators.required,Validators.min,Validators.max]],
      totalFinancialServicesSalesExperienceInYears: ['',[Validators.required,Validators.min,Validators.max]],
      totalMonthlyMortgageBusiness: ['',[Validators.required]],
      monthlyNumberOfFilesOrCustomersProcessed: ['',[Validators.required,Validators.min,Validators.max]],
      mortgageSalesExperienceInYears: ['',[Validators.required,Validators.min,Validators.max]],
      monthlyNumberOfMortgageFilesOrCustomersProcessed: ['',[Validators.required,Validators.min,Validators.max]],
      numberOfEmployeesOrManpowerInOffice: ['',[Validators.required,Validators.min,Validators.max]],
      numberOfBuilderConnects: ['',[Validators.required,Validators.min,Validators.max]],
      averageDisbursementTicketSize: ['',[Validators.required,Validators.min]],

      // whichOtherBusinessDo: ['', [Validators.required, this.requireMatch3.bind(this)]],
      // personaOfChannel: ['', [this.requireMatch4.bind(this)]],
      // topFisName: ['', [Validators.required, this.requireMatch2.bind(this)]],
      // // NumberOfFI: ['', [Validators.required]],
      // totalMonthlyBusinessCR: ['', [Validators.required]],
      // totalMonthlyIncome: ['', [Validators.required]],
      // ownCar: ['', [Validators.required]],
      // builderConnects: ['', [Validators.required]],
      // IsDSABusinessSourceOfIncome: ['', [Validators.required]],
      // incomeComingFromDSABusiness: ['', [Validators.required]],
      // filesprocessedMonth: ['', [Validators.required]],
      // filesprocessedMortgage: ['', [Validators.required]],
      // houseLoanSellingExperience: ['', [Validators.required]],
      // insuranceSalesExperience: ['', [Validators.required]],
      // NumberOfEmployee: ['', [Validators.required]],
      // mentionBusiness: [''],
      // fisnameone: [''],
      // fisnametwo: [''],
      // fisnamethre: [''],
      // builder1: [''],
      // builder2: [''],
      // builder3: [''],
      // bankMaster: ['']

    });

    // this._apiService.getbankMaster().subscribe((response: any) => {
    //   if (!response.err) {
    //     this.bankMasterList = response?.bank_data;
    //     console.log("bankMster", this.bankMasterList);
    //   }
    // }, (err) => {
    //   Swal.fire({
    //     position: 'center',
    //     icon: 'error',
    //     title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
    //     showConfirmButton: false,
    //     timer: 1500
    //   });
    // })


    this.isSelectAdvisory = this.userData.created_by === null ? true : false;
    if (this.isSelectAdvisory) {
      this.form.controls['selectAdvisory'].addValidators([Validators.required, this.sourceRequireMatch.bind(this)]);
      this.form.controls['selectAdvisory'].updateValueAndValidity();
      this.form.controls['branch'].addValidators([Validators.required, this.branchRequireMatch.bind(this)]);
      this.form.controls['branch'].updateValueAndValidity();
      this._apiService.getBranchList().subscribe((response: any) => {
        if (!response.err) {
          this.branchList = response.branch_data;
          this.branchArray.forEach((ele: any) => {
            this.branchList.push({ title: ele.title, value: ele.value })
          })
          this.filteredBranch = [...this.branchList];
        }
      }, (err) => {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        });
      })
    } else {
      this.form.controls['selectAdvisory'].reset();
      this.form.controls['selectAdvisory'].clearValidators();
      this.form.controls['selectAdvisory'].updateValueAndValidity();
      this.form.controls['selectAdvisory'].clearValidators();
      this.form.controls['branch'].addValidators([Validators.required]);
    }
    this.getCaseDetails();

    this.filteredPartner = [...this.partnerList];
    this.form.controls['partnerType'].valueChanges.subscribe((res: any) => {
      this.filteredPartner = this.partnerList.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
      if (this.filteredPartner.length == 0) {
        this.filteredPartner = [...this.partnerList]
      }
      if (res == 'Direct Selling Agent (DSA)') {
        if (this.constitutionList[0].title !== 'Individual') {
          this.constitutionList.unshift({ title: 'Individual', value: 'Individual' });
        }
      } else {
        if (this.constitutionList[0].title === 'Individual') {
          this.constitutionList.shift();
        }
      }
      this.filteredConstitution = [...this.constitutionList];
      this.form.patchValue({
        ConstitutionType: null
      });
    });

    // this.businessActivities = [...this.businessActivity]
    // this.form.controls['whichOtherBusinessDo'].valueChanges.subscribe((res: any) => {
    //   this.businessActivities = this.businessActivity.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
    //   if (this.businessActivities.length == 0) {
    //     this.businessActivities = [...this.businessActivity]
    //   }
    // })

    this.filteredConstitution = [...this.constitutionList]
    this.form.controls['ConstitutionType'].valueChanges.subscribe((res: any) => {
      if (res !== null) {
        this.filteredConstitution = this.constitutionList.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
        if (this.filteredConstitution.length == 0) {
          this.filteredConstitution = [...this.constitutionList]
        }
      }
    })

    // this.topFISNameDataList = [...this.topFisNameData]
    // this.form.controls['topFisName'].valueChanges.subscribe((res: any) => {
    //   this.topFISNameDataList = this.topFisNameData.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
    //   if (this.topFISNameDataList.length == 0) {
    //     this.topFISNameDataList = [...this.topFisNameData]
    //   }
    // })

    // this.form.controls['topFisName'].valueChanges.subscribe((res: any) => {
    //   if (typeof res === 'string') {
    //     this.topFISNameDataList = this.topFisNameData.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
    //     if (this.topFISNameDataList.length === 0) {
    //       this.topFISNameDataList = [...this.topFisNameData];
    //     }
    //   }
    // })

    // this.personaOfChannelDataList = [...this.personaOfChannelData]
    // this.form.controls['personaOfChannel'].valueChanges.subscribe((res: any) => {
    //   this.personaOfChannelDataList = this.personaOfChannelData.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
    //   if (this.personaOfChannelDataList.length == 0) {
    //     this.personaOfChannelDataList = [...this.personaOfChannelData]
    //   }
    // })

    this.filteredAdvisory = [...this.selectAdvisoryTypes]
    this.form.controls['selectAdvisory'].valueChanges.subscribe((res: any) => {
      this.filteredAdvisory = this.selectAdvisoryTypes.filter((x: any) => x?.title?.toLowerCase()?.includes(res?.toLowerCase()));
      if (this.filteredAdvisory.length == 0) {
        this.filteredAdvisory = [...this.selectAdvisoryTypes]
      }
    });

    this.form.controls['branch'].valueChanges.subscribe((res: any) => {
      if (res) {
        this.filteredBranch = this.branchList.filter((x: any) =>
          x?.title?.toLowerCase()?.includes(res?.toLowerCase())
        );
        if (this.filteredBranch.length == 0) {
          this.filteredBranch = [...this.branchList];
        }
      } else {
        this.filteredBranch = [...this.branchList];
      }
    });
    // this.getAllBranch();
    // this.form.controls['phoneNumber'].disabled ;
    // this.form.controls['emailAddress'].disabled;
  }


  requireMatch(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.partnerList && this.partnerList.find((ele: any) => ele.title == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }


  requireMatch1(control: FormControl): ValidationErrors | null {
    const selection1: any = control.value;


    if (this.constitutionList && this.constitutionList.find((ele: any) => ele.title == selection1) == null) {
      return { requireMatch: true };
    }
    return null;
  }
  // requireMatch2(control: FormControl): ValidationErrors | null {
  //   const selection: any = control.value;
  //   if (this.topFisNameData && this.topFisNameData.find((ele: any) => ele.title == selection) == null) {
  //     return { requireMatch2: true };
  //   }
  //   return null;
  // }

  // requireMatch3(control: FormControl): ValidationErrors | null {
  //   const selection: any = control.value;
  //   if (this.businessActivity && this.businessActivity.find((ele: any) => ele.title == selection) == null) {
  //     return { requireMatch3: true };
  //   }
  //   return null;
  // }
  // requireMatch4(control: FormControl): ValidationErrors | null {
  //   const selection: any = control.value;
  //   if (this.personaOfChannelData && this.personaOfChannelData.find((ele: any) => ele.title == selection) == null) {
  //     return { requireMatch4: true };
  //   }
  //   return null;
  // }

  sourceRequireMatch(control: FormControl): ValidationErrors | null {
    const selection1: any = control.value;
    if (this.selectAdvisoryTypes && this.selectAdvisoryTypes.find((ele: any) => ele.title == selection1) == null) {
      return { requireMatch: true };
    }
    return null;
  }

  branchRequireMatch(control: FormControl): ValidationErrors | null {
    const selection: any = control.value;
    if (this.branchList && this.branchList.find((ele: any) => ele.value == selection) == null) {
      return { requireMatch: true };
    }
    return null;
  }

  getNumberArray(value: number): number[] {
    // for (let i = 0; i < this.selectedFisName; i++) {
    //   const controlName = `branchname${i + 1}`;
    //   this.form.addControl(controlName, this._formBuilder.control(''));
    // }
    return Array.from({ length: value }, (_, index) => index);
  }







  getCaseDetails() {
    this.spinner.show();

    // {phoneNo:this.userData.phone_no,token:this.userInfo.token,
    //   version:this.userInfo.version}


    this._apiService.getCaseDetails({ token: this.userInfo.token }).subscribe((res) => {
      if (!res.error) {
        this.userDetails = res.data[0];
        this.form.patchValue({
          fullName: this.userDetails.partner_name,
          phoneNumber: this.userDetails.phone_no,
          emailAddress: this.userDetails.email_id,
          branch: this.userDetails.branch_name,
          partnerType: this.userDetails.partner_type,
          pincode: this.userDetails.pincode,
          ConstitutionType: this.userDetails?.constitution_type,
          selectAdvisory: this.userDetails.onboarding_type,
          numberOfFIEmpanelled: this.userDetails.numberOfFIEmpanelled,
          totalFinancialServicesSalesExperienceInYears: this.userDetails.totalFinancialServicesSalesExperienceInYears,
          totalMonthlyMortgageBusiness: this.userDetails.totalMonthlyMortgageBusiness,
          monthlyNumberOfFilesOrCustomersProcessed: this.userDetails.monthlyNumberOfFilesOrCustomersProcessed,
          mortgageSalesExperienceInYears: this.userDetails.mortgageSalesExperienceInYears,
          monthlyNumberOfMortgageFilesOrCustomersProcessed: this.userDetails.monthlyNumberOfMortgageFilesOrCustomersProcessed,
          numberOfEmployeesOrManpowerInOffice: this.userDetails.numberOfEmployeesOrManpowerInOffice,
          numberOfBuilderConnects: this.userDetails.numberOfBuilderConnects,
          averageDisbursementTicketSize: this.userDetails.averageDisbursementTicketSize,
          
          // houseLoanSellingExperience: this.userDetails.house_loan_selling_exp,
          // insuranceSalesExperience: this.userDetails.total_lending_insurance_sales_experience,
          // whichOtherBusinessDo: this.userDetails.other_than_DSA_RPA_business,
          // personaOfChannel: this.userDetails.persona_of_channel,
          // NumberOfEmployee: this.userDetails.number_of_employees_manpower,
          // NumberOfFI: this.userDetails.number_of_employees_manpower,
          // topFisName: this.userDetails.top_3_FIs_Name,
          // ownCar: this.userDetails.do_you_own_a_car_or_bike,
          // builderConnects: this.userDetails.do_you_have_builder_connects,
          // totalMonthlyBusinessCR: this.userDetails.total_monthly_business_in_CR,
          // totalMonthlyIncome: this.userDetails.total_monthly_income_in_lacs,
          // IsDSABusinessSourceOfIncome: this.userDetails.is_DSA_RPA_business_the_primary_source_of_income,
          // incomeComingFromDSABusiness: this.userDetails.income_from_DSA_RPA_business_in_lacs,
          // filesprocessedMonth: this.userDetails.number_of_files_processed_in_a_month,
          // filesprocessedMortgage: this.userDetails.number_of_files_processed_for_mortgage_in_a_month,
          // mentionBusiness: this.userDetails.mentionBusiness,
          // fisnameone: this.userDetails.fisnameone,
          // fisnametwo: this.userDetails.fisnametwo,
          // fisnamethre: this.userDetails.fisnamethre,
          // builder1: this.userDetails.builder1,
          // builder2: this.userDetails.builder2,
          // builder3: this.userDetails.builder3,


        });

        if (this.userDetails && this.filteredPartner.length > 0) {
          if (this.userDetails.partner_type !== "") {
            this.form.patchValue({
              partnerType: this.filteredPartner.find((ele: any) => ele.value == this.userDetails.partner_type).title
            });
          }
        }

        if (this.userDetails && this.filteredConstitution.length > 0) {
          if (this.userDetails.constitution_type !== null) {
            this.form.patchValue({
              ConstitutionType: this.filteredConstitution.find((ele: any) => ele.value == this.userDetails.constitution_type).title
            })
          }
        }

        if (this.userDetails && this.filteredAdvisory.length > 0 && this.userDetails.onboarding_type) {
          this.form.patchValue({
            selectAdvisory: this.filteredAdvisory.find((ele: any) => ele.title == this.userDetails.onboarding_type).title
          })
        }
        this.spinner.hide();

        if (this.userDetails.mobile_verify_flag == 1) {
          this.mobileVerify = false
        } else {
          this.mobileVerify = true
        }

        if (this.userDetails.email_verify_flag == 1) {
          this.emailVerify = false
        } else {
          this.emailVerify = true
        }
      } else {
        this.getUser();
      }
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })



  }

  setAdvisoryType(type: any) {
    this.form.patchValue({
      selectAdvisory: type.title
    })
  }

  getUser() {
    this.spinner.show();
    this._apiService.getUserDetails({ partnerId: this.userData.partner_id }).subscribe((res) => {
      this.userDetails = res.data[0];
      if (this.userDetails.created_by === null) {
        this.form.patchValue({
          fullName: this.userDetails.partner_name,
          phoneNumber: this.userDetails.phone_no,
          emailAddress: this.userDetails.email_id,
          branch: this.userDetails.branch_name,
          partnerType: this.userDetails.partner_type,
          pincode: this.userDetails.pincode,
          ConstitutionType: this.userDetails.ConstitutionType,
          selectAdvisory: this.userDetails.selectAdvisory,
          numberOfFIEmpanelled: this.userDetails.numberOfFIEmpanelled,
          totalFinancialServicesSalesExperienceInYears: this.userDetails.totalFinancialServicesSalesExperienceInYears,
          totalMonthlyMortgageBusiness: this.userDetails.totalMonthlyMortgageBusiness,
          monthlyNumberOfFilesOrCustomersProcessed: this.userDetails.monthlyNumberOfFilesOrCustomersProcessed,
          mortgageSalesExperienceInYears: this.userDetails.mortgageSalesExperienceInYears,
          monthlyNumberOfMortgageFilesOrCustomersProcessed: this.userDetails.monthlyNumberOfMortgageFilesOrCustomersProcessed,
          numberOfEmployeesOrManpowerInOffice: this.userDetails.numberOfEmployeesOrManpowerInOffice,
          numberOfBuilderConnects: this.userDetails.numberOfBuilderConnects,
          averageDisbursementTicketSize: this.userDetails.averageDisbursementTicketSize,
          // houseLoanSellingExperience: this.userDetails.house_loan_selling_exp,
          // insuranceSalesExperience: this.userDetails.total_lending_insurance_sales_experience,
          // whichOtherBusinessDo: this.userDetails.other_than_DSA_RPA_business,
          // personaOfChannel: this.userDetails.persona_of_channel,
          // NumberOfEmployee: this.userDetails.number_of_employees_manpower,
          // NumberOfFI: this.userDetails.number_of_employees_manpower,
          // topFisName: this.userDetails.top_3_FIs_Name,
          // ownCar: this.userDetails.do_you_own_a_car_or_bike,
          // builderConnects: this.userDetails.do_you_have_builder_connects,
          // totalMonthlyBusinessCR: this.userDetails.total_monthly_business_in_CR,
          // totalMonthlyIncome: this.userDetails.total_monthly_income_in_lacs,
          // IsDSABusinessSourceOfIncome: this.userDetails.is_DSA_RPA_business_the_primary_source_of_income,
          // incomeComingFromDSABusiness: this.userDetails.income_from_DSA_RPA_business_in_lacs,
          // filesprocessedMonth: this.userDetails.number_of_files_processed_in_a_month,
          // filesprocessedMortgage: this.userDetails.number_of_files_processed_for_mortgage_in_a_month,
          // mentionBusiness: this.userDetails.mentionBusiness,
          // fisnameone: this.userDetails.fisnameone,
          // fisnametwo: this.userDetails.fisnametwo,
          // fisnamethre: this.userDetails.fisnamethre,
          // builder1: this.userDetails.builder1,
          // builder2: this.userDetails.builder2,
          // builder3: this.userDetails.builder3,
        });
      } else {
        this.form.patchValue({
          fullName: this.userData.partner_name, phoneNumber: this.userData.phone_no, emailAddress: this.userData.email_id, branch: this.userData.branch_name, partnerType: this.userData.partner_type,
          pincode: this.userDetails.pincode,
          ConstitutionType: this.userDetails.ConstitutionType,
          selectAdvisory: this.userDetails.selectAdvisory,
          numberOfFIEmpanelled: this.userData.numberOfFIEmpanelled,
          totalFinancialServicesSalesExperienceInYears: this.userData.totalFinancialServicesSalesExperienceInYears,
          totalMonthlyMortgageBusiness: this.userData.totalMonthlyMortgageBusiness,
          monthlyNumberOfFilesOrCustomersProcessed: this.userData.monthlyNumberOfFilesOrCustomersProcessed,
          mortgageSalesExperienceInYears: this.userData.mortgageSalesExperienceInYears,
          monthlyNumberOfMortgageFilesOrCustomersProcessed: this.userData.monthlyNumberOfMortgageFilesOrCustomersProcessed,
          numberOfEmployeesOrManpowerInOffice: this.userData.numberOfEmployeesOrManpowerInOffice,
          numberOfBuilderConnects: this.userData.numberOfBuilderConnects,
          averageDisbursementTicketSize: this.userData.averageDisbursementTicketSize,
          // houseLoanSellingExperience: this.userDetails.house_loan_selling_exp,
          // insuranceSalesExperience: this.userDetails.total_lending_insurance_sales_experience,
          // whichOtherBusinessDo: this.userDetails.other_than_DSA_RPA_business,
          // personaOfChannel: this.userDetails.persona_of_channel,
          // NumberOfEmployee: this.userDetails.number_of_employees_manpower,
          // NumberOfFI: this.userDetails.number_of_employees_manpower,
          // topFisName: this.userDetails.top_3_FIs_Name,
          // ownCar: this.userDetails.do_you_own_a_car_or_bike,
          // builderConnects: this.userDetails.do_you_have_builder_connects,
          // totalMonthlyBusinessCR: this.userDetails.total_monthly_business_in_CR,
          // totalMonthlyIncome: this.userDetails.total_monthly_income_in_lacs,
          // IsDSABusinessSourceOfIncome: this.userDetails.is_DSA_RPA_business_the_primary_source_of_income,
          // incomeComingFromDSABusiness: this.userDetails.income_from_DSA_RPA_business_in_lacs,
          // filesprocessedMonth: this.userDetails.number_of_files_processed_in_a_month,
          // filesprocessedMortgage: this.userDetails.number_of_files_processed_for_mortgage_in_a_month,
          // mentionBusiness: this.userDetails.mentionBusiness,
          // fisnameone: this.userDetails.fisnameone,
          // fisnametwo: this.userDetails.fisnametwo,
          // fisnamethre: this.userDetails.fisnamethre,
          // builder1: this.userDetails.builder1,
          // builder2: this.userDetails.builder2,
          // builder3: this.userDetails.builder3,
        })

      }
      if (this.form.value.partner_type == 'DSA') {
        if (this.constitutionList.length && this.constitutionList[0].title !== 'Individual') {
          this.constitutionList.unshift({ title: 'Individual', value: 'Individual' });
          this.constitutionList = this.constitutionList
        }
      } else {
        if(this.constitutionList[0].title === 'Individual'){
          this.constitutionList.shift();
        }
      }
      this.spinner.hide();

      if (this.userData && this.filteredPartner.length > 0 && this.userData.created_by) {
        this.form.patchValue({
          partnerType: this.filteredPartner.find((ele: any) => ele.value == this.userData.partner_type).title
        })
      }

      if (this.userDetails && this.filteredAdvisory.length > 0 && this.userDetails.created_by === null) {
        this.form.patchValue({
          selectAdvisoryType: this.filteredAdvisory.find((ele: any) => ele.title == this.form.value.selectAdvisory).title
        })
      }

      if (this.userDetails.mobile_verify_flag == 1) {
        this.mobileVerify = false
      } else {
        this.mobileVerify = true
      }

      if (this.userDetails.email_verify_flag == 1) {
        this.emailVerify = false;
      } else {
        this.emailVerify = true
      }


    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })

  }



  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }

  // getAllPartnerType(){
  //   let data={
  //     type:"partner_type"
  //   }
  //   this._apiService.getAgentType(data).subscribe((res)=>{
  //       this.partnerTypeData = res; 
  //   },(err: HttpErrorResponse) => {
  //     if (err.status === 400) {
  //       Swal.fire({
  //         position: 'center',
  //         icon: 'success',
  //         title: err.error.message,
  //         showConfirmButton: false,
  //         timer: 1500
  //       })

  //     } else {
  //       Swal.fire({
  //         position: 'center',
  //         icon: 'error',
  //         title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
  //         showConfirmButton: false,
  //         timer: 1500
  //       })
  //     }
  //   })
  // }


  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }


  next() {
    this.formSumitAttempt = true;


    if (this.form.valid) {

      this.isWebRequest = true;

      if (this.mobileVerify) {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: 'Verify phone no.',
          showConfirmButton: false,
          timer: 1500
        })
        return;
      } else if (this.emailVerify) {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: 'Verify  email id ',
          showConfirmButton: false,
          timer: 1500
        })
        return;
      } else {
        this.spinner.show();
        console.log("form value::::", this.form.value);
        const branchGroup = this.form.get('branchname') as FormGroup;
        console.log("branchGroup ::", branchGroup);
        let data = {
          fullName: this.form.value.fullName,
          MobileNo: this.form.value.phoneNumber,
          EmailID: this.form.value.emailAddress,
          // partnerType: this.form.value.partnerType,
          // partnerType: this.form.value.partnerType,
          partnerType: this.filteredPartner.find((ele: any) => ele.title == this.form.value.partnerType).value,
          branch: this.form.value.branch,
          pincode: this.form.value.pincode,
          // constitutionType: this.form.value.ConstitutionType,

          constitutionType: this.filteredConstitution.find((ele: any) => ele.title == this.form.value.ConstitutionType).value,
          source: this.form.value.selectAdvisory,
          stageCount: 1,
          appId: this.userDetails ? this.userDetails.case_id : '',
          token: this.userInfo.token,
          version: this.userInfo.version,
          numberOfFIEmpanelled: this.form.value.numberOfFIEmpanelled,
          totalFinancialServicesSalesExperienceInYears: this.form.value.totalFinancialServicesSalesExperienceInYears,
          totalMonthlyMortgageBusiness: this.form.value.totalMonthlyMortgageBusiness,
          monthlyNumberOfFilesOrCustomersProcessed: this.form.value.monthlyNumberOfFilesOrCustomersProcessed,
          mortgageSalesExperienceInYears: this.form.value.mortgageSalesExperienceInYears,
          monthlyNumberOfMortgageFilesOrCustomersProcessed: this.form.value.monthlyNumberOfMortgageFilesOrCustomersProcessed,
          numberOfEmployeesOrManpowerInOffice: this.form.value.numberOfEmployeesOrManpowerInOffice,
          numberOfBuilderConnects: this.form.value.numberOfBuilderConnects,
          averageDisbursementTicketSize: this.form.value.averageDisbursementTicketSize,

          // houseLoanSellingExperience: this.form.value.houseLoanSellingExperience,
          // insuranceSalesExperience: this.form.value.insuranceSalesExperience,
          // whichOtherBusinessDo: this.form.value.whichOtherBusinessDo,
          // personaOfChannel: this.form.value.personaOfChannel,
          // NumberOfEmployee: this.form.value.NumberOfEmployee,
          // NumberOfFI: this.form.value.NumberOfFI,
          // topFisName: this.form.value.topFisName,
          // ownCar: this.form.value.ownCar,
          // builderConnects: this.form.value.builderConnects,
          // totalMonthlyBusinessCR: this.form.value.totalMonthlyBusinessCR,
          // totalMonthlyIncome: this.form.value.totalMonthlyIncome,
          // IsDSABusinessSourceOfIncome: this.form.value.IsDSABusinessSourceOfIncome,
          // incomeComingFromDSABusiness: this.form.value.incomeComingFromDSABusiness,
          // filesprocessedMonth: this.form.value.filesprocessedMonth,
          // filesprocessedMortgage: this.form.value.filesprocessedMortgage,
          // fisnameone: this.form.value.fisnameone,
          // fisnametwo: this.form.value.fisnametwo,
          // fisnamethre: this.form.value.fisnamethre,
          // mentionBusiness: this.form.value.mentionBusiness,
          // builder1: this.form.value.builder1,
          // builder2: this.form.value.builder2,
          // builder3: this.form.value.builder3
        }
        if (this.isSelectAdvisory) {
          let updateData = {
            partnerName: this.form.value.fullName,
            typeOfAgent: this.filteredPartner.find((ele: any) => ele.title == this.form.value.partnerType).value,
            phoneNo: this.form.value.phoneNumber,
            emailId: this.form.value.emailAddress,
            branchName: this.form.value.branch,
            source: this.form.value.selectAdvisory,
            version: this.userInfo.version,
            numberOfFIEmpanelled: this.form.value.numberOfFIEmpanelled,
            totalFinancialServicesSalesExperienceInYears: this.form.value.totalFinancialServicesSalesExperienceInYears,
            totalMonthlyMortgageBusiness: this.form.value.totalMonthlyMortgageBusiness,
            monthlyNumberOfFilesOrCustomersProcessed: this.form.value.monthlyNumberOfFilesOrCustomersProcessed,
            mortgageSalesExperienceInYears: this.form.value.mortgageSalesExperienceInYears,
            monthlyNumberOfMortgageFilesOrCustomersProcessed: this.form.value.monthlyNumberOfMortgageFilesOrCustomersProcessed,
            numberOfEmployeesOrManpowerInOffice: this.form.value.numberOfEmployeesOrManpowerInOffice,
            numberOfBuilderConnects: this.form.value.numberOfBuilderConnects,
            averageDisbursementTicketSize: this.form.value.averageDisbursementTicketSize,
            // houseLoanSellingExperience: this.form.value.houseLoanSellingExperience,
            // insuranceSalesExperience: this.form.value.insuranceSalesExperience,
            // whichOtherBusinessDo: this.form.value.whichOtherBusinessDo,
            // personaOfChannel: this.form.value.personaOfChannel,
            // NumberOfEmployee: this.form.value.NumberOfEmployee,
            // NumberOfFI: this.form.value.NumberOfFI,
            // topFisName: this.form.value.topFisName,
            // ownCar: this.form.value.ownCar,
            // builderConnects: this.form.value.builderConnects,
            // totalMonthlyBusinessCR: this.form.value.totalMonthlyBusinessCR,
            // totalMonthlyIncome: this.form.value.totalMonthlyIncome,
            // IsDSABusinessSourceOfIncome: this.form.value.IsDSABusinessSourceOfIncome,
            // incomeComingFromDSABusiness: this.form.value.incomeComingFromDSABusiness,
            // filesprocessedMonth: this.form.value.filesprocessedMonth,
            // filesprocessedMortgage: this.form.value.filesprocessedMortgage,
            // fisnameone: this.form.value.fisnameone,
            // fisnametwo: this.form.value.fisnametwo,
            // fisnamethre: this.form.value.fisnamethre,
            // mentionBusiness: this.form.value.mentionBusiness,
            // builder1: this.form.value.builder1,
            // builder2: this.form.value.builder2,
            // builder3: this.form.value.builder3,
          }
          this._apiService.updatePartner(updateData).subscribe((response: any) => {
            this.spinner.hide();
            if (response.error) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: response.error.message,
                showConfirmButton: false,
                timer: 1500
              })
            }
          }, (err) => {
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            }
            this.isWebRequest = false;
          })

        }

        this.storageService.secureStorage.setItem('LastParameter', data);
        this._apiService.addCaseDetail(data).subscribe((response: any) => {
          this.spinner.hide();
          if (!response.error) {
            Swal.fire({
              position: 'center',
              icon: 'success',
              title: response.message,
              showConfirmButton: false,
              timer: 1500
            })
            this.router.navigate(['/home/kyc-details'])
          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              title: response.message,
              showConfirmButton: false,
              timer: 1500
            })
          }
        },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
            this.isWebRequest = false;
          })
      }





    }





  }

  cancel() {

    // Swal.fire({
    //   position: 'center',
    //   icon: 'error',
    //   title: 'response. message response. message response. response. message response. message response.',
    //   showConfirmButton: false,
    //   timer: 1000500,

    //   heightAuto:true
    // })


    this.router.navigate(['/home'])
  }

  openOTPDialog(title: string, message: string): void {
    let value = ''

    if (title == 'Email Verification') {
      this.spinner.show();
      value = this.form.value.emailAddress;
      let data = {
        mobileNo: this.form.value.phoneNumber,
        emailId: this.form.value.emailAddress,
        type: "verify-email-otp"
      }
      this._auth.login(data).subscribe((response: any) => {
        this.spinner.hide();
        if (!response.error) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })

          const dialogRef = this.dialog.open(OtpComponent, {
            disableClose: true,
            width: '400px',
            data: { title: title, message: message, inputValue: data, otp: response.OTP },
          });

          dialogRef.afterClosed().subscribe(result => {

            if (result) {
              this.getUser();
            }
            //success code here
          });
        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        })

    } else if (title == 'Phone Number Verification') {
      value = this.form.value.phoneNumber;
      this.spinner.show();
      let data = {
        mobileNo: this.form.value.phoneNumber,
        type: "verify-mobile-otp"
      }
      this._auth.login(data).subscribe((response: any) => {
        if (!response.error) {
          this.spinner.hide();
          // Swal.fire({
          //   position: 'center',
          //   icon: 'success',
          //   // title: response.message + response.OTP,
          //   title: response.message ,
          //   showConfirmButton: false,
          //   timer: 1500
          // })

          const dialogRef = this.dialog.open(OtpComponent, {
            disableClose: true,
            width: '400px',
            data: { title: title, messeage: message, inputValue: value, otp: response.OTP },
          });

          dialogRef.afterClosed().subscribe(result => {

            if (result) {
              this.getUser();
            }
            //success code here
          });
        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        })
    }

    // const dialogRef = this.dialog.open(OtpComponent, {
    //   disableClose: true,
    //   width: '400px',
    //   data: { title: title, messeage: message , inputValue:value },
    // });

    // dialogRef.afterClosed().subscribe(result => {

    //   if(result){
    //     this.getUser();
    //   }
    //   //success code here
    // });
  }

  getAllBranch() {
    let data = {
      searchTerm: "",
      token: this.userInfo.token
    }
    this._apiService.getBranchData(data).subscribe((res) => {

      if (!res.error) {
        // console.log(res);
        this.branchArray = res.data;
      }

    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }

  keyPressName(event: any) {
    const pattern = /^[a-zA-Z ]*$/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }


  navigateTo() {
    this.router.navigate(['/home'])
  }

  onInput(event: any): void {
    const value = event.target.value;

    // Check if the value is an integer
    if (value && !Number.isInteger(Number(value))) {
      // If it's not an integer, reset the value to the last valid integer
      event.target.value = Math.floor(Number(value)); // Or you could also set it to the last valid integer
    }
  }
  onInputToFixed(event: any): void {
    let value = event.target.value;
  
    // If the value is a valid number, format it to 2 decimal places
    if (!isNaN(value) && value !== '') {
      value = parseFloat(value).toFixed(2);
    }
  
    // Update the input field with the formatted value
    event.target.value = value;
  }
  
}
