import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-consent',
  templateUrl: './user-consent.component.html',
  styleUrls: ['./user-consent.component.scss']
})
export class UserConsentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
