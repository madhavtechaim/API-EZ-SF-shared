import { ActivatedRoute, Router } from '@angular/router';
import { StorageService } from './../../services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PartnerFiltersComponent } from 'src/app/modals/partner-filters/partner-filters.component';
import { HttpErrorResponse } from '@angular/common/http';
import * as moment from 'moment';
import Swal from 'sweetalert2';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-partner-list',
  templateUrl: './partner-list.component.html',
  styleUrls: ['./partner-list.component.scss']
})
export class PartnerListComponent implements OnInit {
  dayEventList: any;
  appointmentState: any = "All";
  filterData: any = '';
  userInfo: any;

  currentUrl: any;
  trainingPage: boolean = false;
  years: any[] = [];
  endYear: any;
  selectedYear: number;
  // selectedOpt: any;
  constructor(public dialog: MatDialog, private _apiService: ApiService, private storageService: StorageService, private spinner: NgxSpinnerService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.userInfo = this.storageService.secureStorage.getItem("userinfo")
    this.getYears();
    this.selectedYear = new Date().getFullYear();

    this._apiService.patnerSend.subscribe((res: any) => {
      console.log("resresres", res);



      this.appointmentState = res.eventType ? res.eventType : 'All';

      this.filterData = {
        fromDate: res.rangeFrom
          ? res.rangeFrom : '',
        toDate: res.rangeTo ? res.rangeTo : '',
        partnerType: '',
        eventTitle: '',
        eventType: '',
        type: this.appointmentState ? this.appointmentState : 'All',
        searchTerm: '',
        token: this.userInfo.token,
        version: this.userInfo.version,
        filterType: res.filterType ? res.filterType : 'Monthly',
        year: this.selectedYear
      }
    })

    this.getPartnerList(this.filterData);
    this.currentUrl = this.route.snapshot.url.join('/');
    this.currentUrl == 'training-approval' ? this.trainingPage = true : this.trainingPage = false;
    console.log("this.currentUrlthis.currentUrl::", this.currentUrl, this.trainingPage);

  }

  ngAfterViewInit(): void {
    this.currentUrl == 'training-approval' ? this.trainingPage = true : this.trainingPage = false;
  }

  getYears = () => {
    const startYear = 2000;
    this.endYear = new Date().getFullYear();

    for (let year = startYear; year <= this.endYear; year++) {
      this.years.push(year);
    }
    return this.years
  }


  search(event: any) {
    // console.log(event,event.target.value
    //   );
    this.filterData.searchTerm = event.target.value;
    this.filterData.token = this.userInfo.token;
    this.filterData.version = this.userInfo.version;



    setTimeout(() => {
      // console.log('Hello world')
      this.getPartnerList(this.filterData);
    }, 2000)

    // this.getPartnerList(this.filterData);
  }



  getPartnerList(data: any) {
    console.log("data::::::::::::", data);
    this.spinner.show();
    // data={"fromDate":"2022-01-05","toDate":"2023-01-04","partnerType":"","eventTitle":"","eventType":"","type":"Queries","searchTerm":"","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjE4ODMsImlhdCI6MTY3Mjc0MTkzMSwiZXhwIjoxNjg4NTA5OTMxfQ.5vgwYu8W0Bdax5pi5reHUwv3ARCE4qy5XuVpttO3PoI","version":19,"filterType":"Range"}
    // data.type = data.type !='All'?data.type :''
    console.log("training>>>>>>>>>>>>", this.route.snapshot.url.join('/'), this.trainingPage);

    if (this.route.snapshot.url.join('/') !== 'training-approval') {
      this._apiService.getParnterOnbording(data).subscribe((res) => {
        // console.log(">>.>.>", res)
        this.dayEventList = res.data;

        this.spinner.hide();

      }, (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }

      })
    } else {

      this._apiService.getTrainingPartnerList(data).subscribe((res) => {
        // console.log(">>.>.>", res)
        this.dayEventList = res.data;

        this.spinner.hide();

      }, (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }

      })
    }
  }

  onChangeYear(event: any) {
    const selectedOpt = event?.target?.value;
    console.log("selectedOpt:::", selectedOpt);
    this.filterData.year = selectedOpt;

    this._apiService.getTrainingPartnerList(this.filterData).subscribe((res) => {
      this.dayEventList = res.data;
      this.spinner.hide();
    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })
  }




  appointmentStatus(value: any) {
    this.appointmentState = value;
    this.filterData.type = value;
    this.filterData.token = this.userInfo.token;
    this.filterData.version = this.userInfo.version;
    this.getPartnerList(this.filterData);
  }

  openFilterDialog(): void {
    const dialogRef = this.dialog.open(PartnerFiltersComponent, {
      disableClose: true,
      width: '400px',
    });

    dialogRef.afterClosed().subscribe(result => {
      //success code here
      if (result.status) {


        this.filterData.partnerType = result.data.agentType ? result.data.agentType : [];
        this.filterData.type = this.appointmentState ? this.appointmentState : 'All',
          this.filterData.fromDate = result.data.fromDate ? result.data.fromDate : this.filterData.fromDate;
        this.filterData.toDate = result.data.toDate ? result.data.fromDate : this.filterData.toDate;
        // this.filterData.eventStatus = this.appointmentState?this.appointmentState:'All';
        this.filterData.token = this.userInfo.token;
        this.filterData.version = this.userInfo.version;
        this.filterData.branchList = result.data.eventType ? result.data.eventType : '';
        this.getPartnerList(this.filterData);

      }
    });
  }

  navigateTo() {
    this.router.navigate(['/home/dsa-dashboard'])
  }

}
