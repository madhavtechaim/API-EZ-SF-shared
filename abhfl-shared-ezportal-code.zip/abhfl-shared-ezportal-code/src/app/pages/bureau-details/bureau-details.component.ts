import { StorageService } from './../../services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ConsentComponent } from 'src/app/modals/consent/consent.component';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/services/auth.service';
import { DeviceDetectorService } from 'ngx-device-detector';


@Component({
  selector: 'app-bureau-details',
  templateUrl: './bureau-details.component.html',
  styleUrls: ['./bureau-details.component.scss']
})
export class BureauDetailsComponent implements OnInit {
  isConsentRead: boolean;
  userData: any;
  userDetails: any;
  consentCheckFlag: any = false;
  // cibilData: { id: number; userType: string; name: string; isChecked: boolean; cibilDateTime: string; }[];
  invalid: boolean;
  directorData: any[] = [];
  cibilData: any[] = [];
  directorConsent: any[] = [];
  userInfo: any;
  waringMassage: any = "";
  legalConsentCheckFlag: boolean = false;
  isGstVerified: boolean = false;
  isMsmeApplicable: boolean = false;
  legalConsentMessage: any[] = [
    { id: 0, type: '' },
    { id: 1, type: 'TRAI' },
    { id: 2, type: '' },
    { id: 3, type: 'Legal Dispute' },
    { id: 4, type: 'Relation with Aditya Birla' },
    { id: 5, type: 'ITR Verify' }
  ];
  isMsmeNoPresent: boolean = false;

  constructor(private router: Router, public dialog: MatDialog, private _apiService: ApiService, private storageService: StorageService, private spinner: NgxSpinnerService, private _auth: AuthService, private deviceService: DeviceDetectorService) { }

  ngOnInit(): void {

    this.userInfo = this.storageService.secureStorage.getItem("userinfo");

    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    this.isConsentRead = false;
    this.getCaseDetails();



    // this.cibilData=[
    //   // {id: 1 ,userType:'Applicant' , name:"Swapnil navghare" , isChecked : false , cibilDateTime:'12-09-2022 13:31' },
    //   {id: 1 ,userType:'Director' , name:"Bhanudas Chatter" , isChecked : false , cibilDateTime:'12-09-2022 13:31' },
    //   {id: 2 ,userType:'Director' , name:"Yugal Patil" , isChecked : false , cibilDateTime:'12-09-2022 13:31' },
    //   {id: 3 ,userType:'Director' , name:"Kedar Relekar" , isChecked : false , cibilDateTime:'12-09-2022 13:31' }
    // ]
  }



  getCaseDetails() {
    this.spinner.show();
    this._apiService.getCaseDetails({ token: this.userInfo.token }).subscribe((res) => {
      if (!res.error) {
        this.spinner.hide();
        this.userDetails = res.data[0];
        this.isGstVerified = this.userDetails.gst_verify_flag == 1 ? true : false;
        this.isMsmeApplicable = this.userDetails.msme_applicable == 'Yes' ? true : false;
        this.isMsmeNoPresent = this.userDetails.msme_number == null ? false : true;
        this.legalConsentCheckFlag = this.userDetails.dsa_legal_consent == 1 ? true : false;
        this.directorData = res.directorData;
        if (this.userDetails.consent_check) {
          this.isConsentRead = true
        } else {
          this.isConsentRead = false
        }

        this.directorData.forEach((ele: any, i: any) => {
          if (ele.authorised_flag == 1) {
            this.cibilData.push({ isChecked: ele.cibil_consent_check == 0 ? false : true, id: ele.tid, director_full_name: ele.director_full_name })
          }
          // this.cibilData[i].isChecked = ele.cibil_consent_check == 0? false :true
        })
        // console.log("this.cibilData.this.cibilData.",this.cibilData);
        this.consentCheckFlag = this.userDetails.consent_check == 0 || this.userDetails.consent_check == '' ? false : true;
      } else {
        this.spinner.hide();
      }

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })
      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
    })
  }

  changesDate(event: any) {
    // console.log(event.target.value);

  }
  perpairForSubmit() {

    if (!this.consentCheckFlag && (this.userDetails.constitution_type == 'Individual' || this.userDetails.constitution_type == 'Proprietor')) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: "Check User CIBIL Consent",
        showConfirmButton: false,
        timer: 1500
      })
      return;
    } else if (!this.legalConsentCheckFlag) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: "Please check Terms & Condition!",
        showConfirmButton: false,
        timer: 1500
      });
      return;
    } else {
      this.waringMassage = ""
      if (this.userDetails.constitution_type == 'Individual') {
        let date_of_birth = new Date(this.userDetails.date_of_birth)
        let timeDiff = Math.abs(Date.now() - date_of_birth.getTime());
        let age = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365.25);
        if (age < 20) {
          this.waringMassage = this.waringMassage + 'Your Case will not be processed because your age is less than 20 Year'
        }

        if (this.userDetails.cibil_score < 600 && this.consentCheckFlag == true && this.userDetails.cibil_score > 1) {
          if (this.waringMassage != "") {

            this.waringMassage = this.waringMassage + ' ' + '& Your CIBIL Score is less than 600'
          }
          else {
            this.waringMassage = this.waringMassage + 'Your Case will not be processed because Your CIBIL Score is less than 600'
          }
        }
      } else {
        this.directorData.map(director => {
          if (director.authorised_flag == 1 && director.cibil_consent_check && director.cibil_score < 600 && director.cibil_score > 1) {
            this.waringMassage = "Your Case will not be processed because one or more directors CIBIL Score is less tha 600"
          }
        })
      }

      if (this.waringMassage != "") {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: this.waringMassage,
          confirmButtonColor: "#facea8",
          customClass: {
            confirmButton: 'btn btn-sweet-alert-color'
          },
          showConfirmButton: true,
          // timer: 1500
        }).then(() => {
          this.submit()
        });
      } else {
        this.submit()
      }
    }


  }


  submit() {

    let device = this.deviceService.getDeviceInfo().deviceType;

    if (!this.consentCheckFlag && (this.userDetails.constitution_type == 'Individual' || this.userDetails.constitution_type == 'Proprietor')) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: "Check User CIBIL Consent",
        showConfirmButton: false,
        timer: 1500
      })
      return;
    }


    // this.invalid=false;

    // if(this.userDetails.constitution_type != 'Individual'){
    //   this.cibilData.forEach(element => {
    //     if(element.isChecked ==false){
    //       this.invalid = true ; 
    //       return
    //     }
    //   });
    // }

    // if(this.invalid){
    //   Swal.fire({
    //     position: 'center',
    //     icon: 'warning',
    //     title: "Check Director CIBIL Consent",
    //     showConfirmButton: false,
    //     timer: 1500
    //   })
    //   return;
    // }



    this.spinner.show();


    this.cibilData.forEach(element => {
      this.directorConsent.push({ directorId: element.id, concent: element.isChecked ? 1 : 0 })
    });

    let data = {
      appId: this.userDetails.case_id,
      stageCount: 9,
      consentCheck: true,
      directorConsent: this.directorConsent,
      token: this.userInfo.token,
      device: device
      // version:this.userInfo.version,
    }


    this._apiService.addCaseDetail(data).subscribe((response: any) => {
      if (!response.error) {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
        this.router.navigate(['/home'])
      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    },
      (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
      })

  }

  onReadConsent() {
    this.isConsentRead = true;

  }

  cancel() {
    this.router.navigate(['/home'])
  }

  consentDialog(type: string, title: string, messeage: string, index: any): void {

    if (index == null) {
      if (!this.consentCheckFlag) {
        const dialogRef = this.dialog.open(ConsentComponent, {
          disableClose: true,
          width: '400px',
          data: { title: title, messeage: messeage },
        });

        dialogRef.afterClosed().subscribe(result => {

          if (result) {
            this.spinner.show();
            let data =
            {
              caseId: this.userDetails.case_id,
              directorId: "",
              token: this.userInfo.token,
              version: this.userInfo.version
            }

            this._apiService.getCibilScore(data).subscribe((res: any) => {
              if (!res.error) {
                this.spinner.hide();
                this.consentCheckFlag = true
                Swal.fire({
                  position: 'center',
                  icon: 'success',
                  title: res.message,
                  showConfirmButton: false,
                  timer: 1500
                })
              } else {
                this.spinner.hide();
                Swal.fire({
                  position: 'center',
                  icon: 'warning',
                  title: res.message,
                  showConfirmButton: false,
                  timer: 1500
                })
              }
            }, (err: HttpErrorResponse) => {
              this.spinner.hide();
              if (err.status === 400) {
                Swal.fire({
                  position: 'center',
                  icon: 'error',
                  title: err.error.message,
                  showConfirmButton: false,
                  timer: 1500
                })

              } else {
                Swal.fire({
                  position: 'center',
                  icon: 'error',
                  title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                  showConfirmButton: false,
                  timer: 1500
                })
              }
            })


            // 
          }
          //your code here
        });

      } else {
        this.consentCheckFlag = false
      }
    } else {
      if (!this.cibilData[index].isChecked) {

        const dialogRef = this.dialog.open(ConsentComponent, {
          disableClose: true,
          width: '400px',
          data: { title: title, messeage: messeage },
        });

        dialogRef.afterClosed().subscribe(result => {

          if (result) {
            this.spinner.show();
            let data =
            {
              caseId: this.userDetails.case_id,
              directorId: this.cibilData[index].id,
              token: this.userInfo.token,
              version: this.userInfo.version
            }

            this._apiService.getCibilScore(data).subscribe((res: any) => {
              if (!res.error) {
                this.spinner.hide();
                this.cibilData[index].isChecked = true
                Swal.fire({
                  position: 'center',
                  icon: 'success',
                  title: res.message,
                  showConfirmButton: false,
                  timer: 1500
                })
              } else {
                this.spinner.hide();
                Swal.fire({
                  position: 'center',
                  icon: 'warning',
                  title: res.message,
                  showConfirmButton: false,
                  timer: 1500
                })
              }
            }, (err: HttpErrorResponse) => {
              this.spinner.hide();
              if (err.status === 400) {
                Swal.fire({
                  position: 'center',
                  icon: 'error',
                  title: err.error.message,
                  showConfirmButton: false,
                  timer: 1500
                })

              } else {
                Swal.fire({
                  position: 'center',
                  icon: 'error',
                  title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                  showConfirmButton: false,
                  timer: 1500
                })
              }
            })










          }
          //your code here
        });

      } else {
        this.cibilData[index].isChecked = false
      }
    }

  }


  cibilNotAvailable() {
    Swal.fire({
      position: 'center',
      icon: 'warning',
      title: "CIBIL not available",
      showConfirmButton: false,
      timer: 1500
    })

  }

  navigateTo() {
    this.router.navigate(['/home'])
  }

  downloadCibil(id: any, tid: any) {
    this.spinner.show();
    let data

    if (tid != null) {
      data = {
        caseId: id,
        // stageCount:8,
        // consentCheck: true,
        // directorConsent:this.directorConsent
      }
    } else {
      data = {
        caseId: id,
        directorId: tid
        // stageCount:8,
        // consentCheck: true,
        // directorConsent:this.directorConsent
      }
    }



    this._apiService.downloadCIBIL(data).subscribe((response: any) => {
      if (!response.error) {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
        // this.router.navigate(['/home'])
      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    },
      (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
      })
  }

  back() {
    this.router.navigate(['/home/financial-institution-details']);
  }

  legalConsentDialog(title: string): void {
    if (!this.legalConsentCheckFlag) {
      if (this.isGstVerified) {
        this.legalConsentMessage[0].type = '';
      } else {
        this.legalConsentMessage[0].type = 'GST';
      }
      if (this.isMsmeApplicable && this.isMsmeNoPresent) {
        this.legalConsentMessage[2].type = '';
      } else {
        this.legalConsentMessage[2].type = 'MSME';
      }

      const dialogRef = this.dialog.open(ConsentComponent, {
        disableClose: true,
        width: '400px',
        data: { title: title, messeage: JSON.stringify(this.legalConsentMessage) },
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.spinner.show();
          let data =
          {
            caseId: this.userDetails.case_id,
            token: this.userInfo.token,
            version: this.userInfo.version
          }

          this._apiService.updateLegalConsent(data).subscribe((res: any) => {
            if (!res.error) {
              this.spinner.hide();
              this.legalConsentCheckFlag = true;
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: res.message,
                showConfirmButton: false,
                timer: 1500
              })
            } else {
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: res.message,
                showConfirmButton: false,
                timer: 1500
              })
            }
          }, (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
          });
        }
      });
    } else {
      this.legalConsentCheckFlag = false;
    }
  }
}
