import { Component } from '@angular/core';
import { SwUpdate } from '@angular/service-worker';
import { NgxSpinnerService } from 'ngx-spinner';
import { DeviceDetectorService } from 'ngx-device-detector';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  constructor(private readonly updates: SwUpdate,private spinner: NgxSpinnerService,private deviceService: DeviceDetectorService){

    this.updates.available.subscribe(event => {

      window.location.reload();

    });

  }

  ngOnInit(){
    // this.spinner.show();
    this.checkDeviceType();
  }

  checkDeviceType() {
    let deviceInfo = this.deviceService.getDeviceInfo();
    localStorage.setItem('deviceType', deviceInfo.deviceType);
  }
}
