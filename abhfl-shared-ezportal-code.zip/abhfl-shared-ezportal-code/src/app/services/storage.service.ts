import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
// import  SecureStorage from 'secure-web-storage'
const SecureStorage = require('secure-web-storage');
const SECRET_KEY = 'n3vZjSxe6kmwWFffgvT3eridN5gXm20p';
@Injectable({
  providedIn: 'root'
})
export class StorageService {
  secret:any =SECRET_KEY
  constructor() { }
  public secureStorage = new SecureStorage(localStorage, {
    hash: (key:any) => {
      key = CryptoJS.SHA256(key , this.secret);
      return key.toString();
    },
    // Encrypt the localstorage data
    encrypt: function encrypt(data:any) {
      data = CryptoJS.AES.encrypt(data, SECRET_KEY);
      data = data.toString();
      return data;
    },
    // Decrypt the encrypted data
    decrypt: function decrypt(data:any) {
      data = CryptoJS.AES.decrypt(data, SECRET_KEY);
      data = data.toString(CryptoJS.enc.Utf8);
      return data;
    }
  });
}
