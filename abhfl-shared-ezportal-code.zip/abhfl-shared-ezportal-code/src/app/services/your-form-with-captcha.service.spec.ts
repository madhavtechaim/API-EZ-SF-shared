import { TestBed } from '@angular/core/testing';

import { YourFormWithCaptchaService } from './your-form-with-captcha.service';

describe('YourFormWithCaptchaService', () => {
  let service: YourFormWithCaptchaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(YourFormWithCaptchaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
