import { StorageService } from 'src/app/services/storage.service';
import { environment } from './../../environments/environment.prod';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import * as CryptoJS from 'crypto-js';


@Injectable({
  providedIn: 'root',
})
export class AuthService {
  public userData = new BehaviorSubject('');
  captchSource = new BehaviorSubject(null);
  captchStatus = this.captchSource.asObservable();
  public token: any;
  public role: any;
  public name: any;
  public code: any;

  constructor(
    private http: HttpClient,
    private storageService: StorageService
  ) {}

  setCaptchaStatus(code: any) {
    this.captchSource.next(code);
  }

  login(data: any) {
    return this.http.post(`${environment.api}/send-otp`, data);
  }

  OtpVerification(data: any) {
    return this.http.post(`${environment.api}/verify-otp`, data);
  }

  mobileOtpVerification(data: any) {
    return this.http.post(`${environment.api}/verify-mobile-otp`, data);
  }

  getEmailVerify(data: any) {
    return this.http.post<any>(`${environment.api}/verify-email-otp`, data);
  }

  loginUser(data: any) {
    return this.http.post<any>(`${environment.api}/login`, data);
  }

  saveUserinfoToSorage(user: any) {
    this.storageService.secureStorage.setItem('userinfo', user);
  }

  getUserInfoSorage() {
    return this.storageService.secureStorage.getItem('userinfo');
  }

  saveUserToSorage(user: any) {
    this.storageService.secureStorage.setItem('user', user);
  }

  getUserFromSorage() {
    return this.storageService.secureStorage.getItem('user');
  }

  checkLoginwithToken(data: any) {
    return this.http.post<any>(`${environment.api}/checkLoginwithToken`, data);
  }

  encryptParameter(data: any) {
    const encryptedMessage = CryptoJS.AES.encrypt(
      data,
      this.storageService.secret
    )
      .toString()
      .replace(/\//g, 'Por21Ld')
      .replace(/\+/g, 'xMl3Jk')
      .replace(/\=/g, 'Ml32');
    return encryptedMessage;
  }

  decryptParameter(data: any, isReplaced: any) {
    if (isReplaced) {
      data = data
        .replace(/xMl3Jk/g, '+')
        .replace(/Por21Ld/g, '/')
        .replace(/Ml32/g, '=');
    } else {
      data = data;
    }
    const decryptedBytes = CryptoJS.AES.decrypt(
      data,
      this.storageService.secret
    );
    const decryptedMessage = decryptedBytes.toString(CryptoJS.enc.Utf8);
    return decryptedMessage;
  }
}
