import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs'
@Injectable({
  providedIn: 'root'})
export class EventService {

  empAdded=new BehaviorSubject(null);
  notifyCount=new BehaviorSubject(null);
  projectDetails=new BehaviorSubject(null);
  bookmark=new BehaviorSubject(null);
  openActivity=new BehaviorSubject(null);
  notifyTeamNotification=new BehaviorSubject(null);
  tabSelection = new BehaviorSubject(null);
  tab1Selection = new BehaviorSubject(null);
  tab2Selection = new BehaviorSubject(null);
  tab3Selection = new BehaviorSubject(null);
  
  check = new BehaviorSubject(null);
  activityAddComment= new BehaviorSubject<Boolean>(false);
  constructor() {

    
  }

 
}
