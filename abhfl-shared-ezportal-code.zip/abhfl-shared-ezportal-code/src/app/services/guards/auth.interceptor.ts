import { AuthService } from './../auth.service';
import Swal from 'sweetalert2'
import { catchError, Observable, of } from 'rxjs';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { catchError } from "rxjs/internal/operators";
import { Router } from '@angular/router';
import { StorageService } from 'src/app/services/storage.service';
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  token: any='';
  constructor(private storageService: StorageService, private router: Router,public _auth:AuthService) { }

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // if(){
    let token=''
    // }

    let LocalToken = localStorage.getItem('localToken');

    // this.cs.usertoken.subscribe((res:any)=>{
    // console.log("🚀 ~ file: auth.interceptor.ts ~ line 29 ~ AuthInterceptor ~ this.cs.usertoken.subscribe ~ res", res)
    // this.storageService.secureStorage.setItem('token',token);
    // })
    token = this.storageService.secureStorage.getItem('user');
    // console.log("dsadadsadas",this.token ) ;
    // console.log("Interceptor works",);
    
    if (!LocalToken) {
      LocalToken=''
      // return next.handle(request);
    }

    if (!token) {
      token=''
      // return next.handle(request);
    }

    const req1 = request.clone({
      headers: request.headers.set('authorization', `Bearer ${LocalToken}`).set('Cache-Control',' no-cache, no-store, must-revalidate'),
    });

    // return next.handle(req1);
    return next.handle(req1).pipe(catchError((error:any, caught:any) => {
      // console.log("🚀 ~ file: auth.interceptor.ts ~ line 55 ~ AuthInterceptor ~ returnnext.handle ~ caught", caught)
      // console.log("🚀 ~ file: auth.interceptor.ts ~ line 55 ~ AuthInterceptor ~ returnnext.handle ~ error", error)
      //intercept the respons error and displace it to the console
      
      this.handleAuthError(error);
      return of(error);
    }) as any);
  }
  /**
   * manage errors
   * @param err
   * @returns {any}
   */
  private handleAuthError(err: HttpErrorResponse): Observable<any> {
    //handle your auth error or rethrow
    if (err.status === 401) {
      //navigate /delete cookies or whatever

      Swal.fire({
        position: 'center',
        icon: 'success',
        title:'Session Aborted.You have logged in from another device.',
        showConfirmButton: false,
        timer: 1500
      })

    //   this.toastrService.error('Session Aborted.You have logged in from another device.')
    //   this.cs.showalert('Session Aborted.You have logged in from another device.', 'error')
      
      setTimeout(() => {
        // this.cs.logout();
      }, 5000);
      this.router.navigate([`/`]);
      // if you've caught / handled the error, you don't want to rethrow it unless you also want downstream consumers to have to handle it as well.
      return of(err.message);
    }
    throw err;
  }
}
