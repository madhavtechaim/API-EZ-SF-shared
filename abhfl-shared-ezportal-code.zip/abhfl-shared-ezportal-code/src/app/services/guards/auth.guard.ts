import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { StorageService } from '../storage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  token: any;

  constructor(
      private router: Router,
      private storageService: StorageService
  ) {
    this.token = this.storageService.secureStorage.getItem("userinfo")
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
      // let roles = route.data["roles"] as Array<string>;
      console.log("token======", this.token);
      if (this.token) {
          return true;
      }
      else {
          this.router.navigate(['/']);
          return false;
      }
  }

}
