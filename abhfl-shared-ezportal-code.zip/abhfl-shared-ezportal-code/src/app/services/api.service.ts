import { StorageService } from './storage.service';
import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  token: any;
  version: any;
  filterSend = new BehaviorSubject('');
  patnerSend = new BehaviorSubject('');


  constructor(private http: HttpClient, private storageService: StorageService) {
    this.token = this.storageService.secureStorage.getItem('token');
    this.version = this.storageService.secureStorage.getItem('version');

    // console.log("cdsccdscds",this.token,this.storageService.secureStorage.getItem('token'));

  }

  OnInit() {

  }
  convertBase64ToBlobData(
    base64Data: string,
    contentType: string = "image/png",
    sliceSize = 512
  ) {
    const byteCharacters = atob(base64Data);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      const slice = byteCharacters.slice(offset, offset + sliceSize);

      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);

      byteArrays.push(byteArray);
    }

    const blob = new Blob(byteArrays, { type: contentType });
    return blob;
  }

  attachmentDownload(base64content: string, contentType: string, name: string) {
    const blobData = this.convertBase64ToBlobData(base64content, contentType);
    let newVariable: any = window.navigator;

    if (window.navigator && newVariable.msSaveOrOpenBlob) {
      //IE
      newVariable.msSaveOrOpenBlob(blobData, name);
    } else {
      // chrome
      const blob = new Blob([blobData], { type: contentType });
      const url = window.URL.createObjectURL(blob);
      // window.open(url);
      const link = document.createElement("a");
      link.href = url;
      link.download = name;
      link.click();
    }
  }

  addPartner(data: any) {
    return this.http.post<any>(`${environment.api}/add-dsa-partner`, data);
  }

  updatePartner(data: any) {
    return this.http.post<any>(`${environment.api}/update-dsa-partner`, data);
  }

  getAgentType(data: any) {
    return this.http.post<any>(`${environment.api}/get-all-dsa-master`, data);
  }

  getAllSchems(data: any) {
    return this.http.post<any>(`${environment.api}/add-dsa-partner`, data);
  }

  getUserDetails(data: any) {
    return this.http.post<any>(`${environment.api}/get-stepwise-partner-details`, data);
  }

  addCaseDetail(data: any) {
    return this.http.post<any>(`${environment.api}/submit-application-case-details`, data);
  }

  validateBankAcc(data: any) {
    return this.http.post<any>(`${environment.api}/validateBankAccount`, data);
  }

  unverifyPennyDropDetails(data: any) {
    return this.http.post<any>(`${environment.api}/unverifyPennyDropDetails`, data);
  }


  getCaseDetails(data: any) {
    return this.http.post<any>(`${environment.api}/get-application-case-details`, data);
  }

  VerifyPan(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-verify-pan`, data);
  }

  verifyAadhar(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-new-adhar-authentication`, data);
    // return this.http.post<any>(`${environment.api}/dsa-verify-adhaar`,data);
  }

  verifyAadharDigilocker(data: any) {
    return this.http.post<any>(`${environment.api}/dsaDigilockerAdharVerification`, data);
    // return this.http.post<any>(`${environment.api}/dsa-verify-adhaar`,data);
  }


  verifyDirAdhar(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-new-director-adhar-authentication`, data);
  }

  verifyDirAdharDigilocker(data: any) {
    return this.http.post<any>(`${environment.api}/dsaDirectorDigilockerAdharVerification`, data);
  }

  verifyGst(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-verify-gst`, data);
  }

  verifyAdharOtp(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-verify-adhar-otp`, data);
  }

  getMasters(data: any) {
    return this.http.post<any>(`${environment.api}/get-all-dsa-master`, data);
  }

  uploadImage(data: any) {
    return this.http.post<any>(`${environment.api}/upload-Applicant-photo`, data);
  }

  uploadDoc(data: any) {
    return this.http.post<any>(`${environment.api}/upload-document-Files`, data);

  }

  uploadDocumentAttachment(data: any) {
    return this.http.post<any>(`${environment.api}/uploadDocumentAttachment`, data);

  }

  uploadDocumentLogAttachment(data: any) {
    return this.http.post<any>(`${environment.api}/uploadDocumentLogAttachment`, data);

  }



  directorPanVerify(data: any) {
    return this.http.post<any>(`${environment.api}/director-verify-pan`, data);
  }

  directorAdhaarVerify(data: any) {
    return this.http.post<any>(`${environment.api}/director-verify-adhaar`, data);
  }

  directorAdhaarOtpVerify(data: any) {
    return this.http.post<any>(`${environment.api}/director-verify-adhar-otp`, data);
  }

  getPincodeDetails(data: any) {
    return this.http.get<any>(`https://api.postalpincode.in/pincode/${data}`);

  }

  getApplication(data: any) {
    return this.http.post<any>(`${environment.api}/get-application-case-details`, data);
  }

  setCurrentAddress(data: any) {
    // return this.http.post<any>(`${environment.api}/dsa-check-current-address`, data);
    return this.http.post<any>(`${environment.api}/dsa-set-current-address`, data);

  }

  getCaseDocType(data: any) {
    return this.http.post<any>(`${environment.api}/get-case-document-type-List`, data);
  }

  addDsaEvent(data: any) {

    return this.http.post<any>(`${environment.api}/add-dsa-Event`, data);
  }

  getEventDashboardCount(data: any) {
    return this.http.post<any>(`${environment.api}/get-event-Dashboard-Count`, data);
  }


  getEventList(data: any) {
    return this.http.post<any>(`${environment.api}/get-event-List`, data);
  }

  getMemberList(data: any) {

    return this.http.post<any>(`${environment.api}/get-member-List`, data);

  }

  updateEventSchedule(data: any) {
    return this.http.post<any>(`${environment.api}/update-event-Schedule`, data);
  }

  bankUploadDoc(data: any) {
    return this.http.post<any>(`${environment.api}/upload-bank-cancel-Cheque`, data);
  }

  getLogs(data: any) {
    return this.http.post<any>(`${environment.api}/get-event-Comment`, data);
  }

  getcaseApplicationandQueryDetails(data: any) {
    return this.http.post<any>(`${environment.api}/getcaseApplicationandQueryDetails`, data);
  }

  getcaseQueryDetails(data: any) {
    return this.http.post<any>(`${environment.api}/getcaseQueryDetails`, data);
  }

  getincentiveQueryDetails(data: any) {
    return this.http.post<any>(`${environment.api}/getdocumentQueryCount`, data);
  }


  getdocumentqueryList(data: any) {
    return this.http.post<any>(`${environment.api}/getdocumentqueryList`, data);
  }


  getTypeMaster(data: any) {
    return this.http.post<any>(`${environment.api}/getquerydocumentTypeMaster`, data);
  }

  getsingledocumentQueryDetails(data: any) {
    return this.http.post<any>(`${environment.api}/getsingledocumentQueryDetails`, data);
  }

  getdocumentqueryComment(data: any) {
    return this.http.post<any>(`${environment.api}/getdocumentqueryComment`, data);
  }


  updatecaseQueryDetails(data: any) {
    return this.http.post<any>(`${environment.api}/updatecaseQueryDetails`, data);
  }



  getAllPartnerOnbord(data: any) {
    return this.http.post<any>(`${environment.api}/getcaseApplicationandQueryDetails`, data);
  }

  addCategory(data: any) {
    return this.http.post<any>(`${environment.api}/add-Category`, data);
  }


  addInsertdocumentqueryRaised(data: any) {
    return this.http.post<any>(`${environment.api}/insertdocumentqueryRaised`, data);
  }
  adddocumentqueryComment(data: any) {
    return this.http.post<any>(`${environment.api}/adddocumentqueryComment`, data);
  }
  updateDocumentQueryStatus(data: any) {
    return this.http.post<any>(`${environment.api}/updateDocumentQueryStatus`, data);
  }


  getRolls(data: any) {
    return this.http.post<any>(`${environment.api}/get-role-List`, data);
  }


  addAppointments(data: any) {
    return this.http.post<any>(`${environment.api}/add-appointment-status`, data);
  }

  updateAppointment(data: any) {
    return this.http.post<any>(`${environment.api}/update-appointment-status`, data);
  }

  getAppointment(data: any) {
    return this.http.post<any>(`${environment.api}/get-appointment-status`, data);
  }


  addDisposition(data: any) {
    return this.http.post<any>(`${environment.api}/add-Disposition`, data);
  }

  updateDisposition(data: any) {
    return this.http.post<any>(`${environment.api}/update-Disposition`, data);
  }

  getDisposition(data: any) {
    return this.http.post<any>(`${environment.api}/get-disposition`, data);
  }


  addSubDisposition(data: any) {
    return this.http.post<any>(`${environment.api}/add-sub-Disposition`, data);
  }

  updateSubDisposition(data: any) {
    return this.http.post<any>(`${environment.api}/update-sub-Disposition`, data);
  }

  getSubDisposition(data: any) {
    return this.http.post<any>(`${environment.api}/get-sub-disposition`, data);
  }

  deleteSubDisposition(data: any) {
    return this.http.post<any>(`${environment.api}/delete-sub-disposition`, data);
  }


  deleteDirector(data: any) {
    return this.http.post<any>(`${environment.api}/delete-director`, data);
  }


  getBanckCancellationCheck(data: any) {
    return this.http.post<any>(`${environment.api}/get-bank-cheque-File`, data);
  }


  dsaAdLogin(data: any) {
    return this.http.post<any>(`${environment.api}/dsaLoginInApp`, data);
  }

  getPartnerApplicationCount(data: any) {
    return this.http.post<any>(`${environment.api}/get-partner-application-Count`, data);
  }


  getIfscData(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-get-bank-details-using-ifsc-code`, data);
  }


  getPincodeDetails1(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-get-pincode-details`, data);
  }


  getCaseDirector(data: any) {
    return this.http.post<any>(`${environment.api}/get-case-director-data`, data);
  }


  getITRVerify(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-itr-check`, data);
  }



  adhar(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-new-adhar-authentication`, data);
  }


  adharData(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-new-adhar-varification-callback`, data);
  }


  getParnterOnbording(data: any) {
    return this.http.post<any>(`${environment.api}/get-partner-application-list`, data);
  }

  getTrainingPartnerList(data: any) {
    return this.http.post<any>(`${environment.api}/get-annual-application-list`, data);
  }

  adharDirData(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-new-director-adhar-varification-callback`, data);
  }

  getCategories(data: any) {
    return this.http.post<any>(`${environment.api}/get-resource-center-categories`, data);
  }

  getTrainingCategories(data: any) {
    return this.http.post<any>(`${environment.api}/get-training-center-categories`, data);
  }

  getCategoryList(data: any) {
    return this.http.post<any>(`${environment.api}/get-resource-center-documents`, data);
  }
  getTrainingCategoryList(data: any) {
    return this.http.post<any>(`${environment.api}/get-training-center-documents`, data);
  }

  getTrainingList(data: any) {
    return this.http.post<any>(`${environment.api}/get-training-center-documents`, data);
  }

  updateResourceDocument(data: any) {
    return this.http.post<any>(`${environment.api}/update-resource-center-document-status`, data);
  }
  updateTrainingDocument(data: any) {
    return this.http.post<any>(`${environment.api}/update-training-center-document-status`, data);
  }

  resourceCenterComplete(data: any) {
    return this.http.post<any>(`${environment.api}/mark-resource-center-completed`, data);
  }

  trainingCenterComplete(data: any) {
    return this.http.post<any>(`${environment.api}/mark-annual-certification-completed`, data);
  }


  getBranchData(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-get-branches`, data);
  }


  unverifyPAN(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-unverify-pan`, data);

  }

  unverifyDirPAN(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-unverify-director-pan`, data);
  }


  downloadCIBIL(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-get-sibil-score`, data);
  }


  getPartnerCaseApplicationCount(data: any) {
    return this.http.post<any>(`${environment.api}/get-partner-case-application-Count`, data);
  }

  updateConsent(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-update-consent`, data);
  }

  refreshCaptcha(data: any) {
    return this.http.post<any>(`${environment.api}/resend-Captcha`, data);
  }

  deleteDocuments(data: any) {
    return this.http.post<any>(`${environment.api}/delete-case-document`, data);
  }

  getApplicationCompletionData(data: any) {
    // return this.http.post<any>(`${environment.api}/getpdfapplicationcaseDetails`, data);
    return this.http.post<any>(`${environment.api}/getpdfcaseDetails`, data);
  }

  getAgreementPdf(data: any) {
    return this.http.post<any>(`${environment.api}/getpdfagreementDetails`, data);
  }


  getCibilScore(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-get-sibil-score`, data);

  }

  downloadDocuments(data: any) {
    return this.http.post(`${environment.api}/download-file`, data, {
      observe: 'response',
      responseType: 'blob'
    });
  }

  sameAsCurrentAddress(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-update-current-address`, data);
  }


  saveCurrentAddress(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-insert-current-address`, data);
  }


  getGstDoc(data: any) {
    return this.http.post<any>(`${environment.api}/get-gst-File`, data);
  }


  gstUploadDoc(data: any) {
    return this.http.post<any>(`${environment.api}/upload-gst-file`, data);
  }


  uncheckAuthorisedDirector(data: any) {
    return this.http.post<any>(`${environment.api}/dsa_uncheck_authorised_director`, data)
  }


  verifyAdharFlagCheck(data: any) {
    return this.http.post<any>(`${environment.api}/dsacaseverifyAdharFlag`, data)
  }

  sendDirectorVerificationOtp(data: any) {
    return this.http.post<any>(`${environment.api}/sendDirectorVerificationOTP`, data);
  }

  verifyDirectorMobileOTP(data: any) {
    return this.http.post<any>(`${environment.api}/verifyDirectorMobileOTP`, data);
  }

  verifyDirectorEmailOTP(data: any) {
    return this.http.post<any>(`${environment.api}/verifyDirectorEmailOTP`, data);
  }

  verifyDirectorCibilOtp(data: any) {
    return this.http.post<any>(`${environment.api}/verifyDirectorCibilOtp`, data);
  }

  uploadDirectorPhoto(data: any) {
    return this.http.post<any>(`${environment.api}/upload-director-photo`, data);
  }

  sendOnboardingLinksToPartners(data: any) {
    return this.http.post<any>(`${environment.api}/sendOnboardingLinksToPartners`, data);
  }

  approveDSATrainingBySM(data: any) {
    return this.http.post<any>(`${environment.api}/approveDSATrainingBySM`, data);
  }
  approveDSACertificationBySM(data: any) {
    return this.http.post<any>(`${environment.api}/approveDSACertificationBySM`, data);
  }


  getDocument(data: any) {
    return this.http.post<any>(`${environment.documentURL}/incentive-Folders`, data);
    //  return this.http.post<any>(`${environment.api}/approveDSATrainingBySM`, data);return this.http.post<any>(`${environment.documentURL}`, data);
    // return this.http.post<any>(`https://27fa-103-208-71-156.in.ngrok.io/api/incentive-Folders`, data);
  }


  updateLegalConsent(data: any) {
    return this.http.post<any>(`${environment.api}/dsa-update-legal-consent`, data);
  }

  getBranchList() {
    return this.http.get<any>(`${environment.api}/get-branch-list`);
  }
  checkExcelFileExists(data: any) {

    return this.http.post<any>(`${environment.incentiveURL}/checkExcelFileExists`, data);

  }

  getpartnercaseDashboardList(data: any) {
    return this.http.post<any>(`${environment.api}/get-annual-training-Count`, data);
  }

  getbankMaster() {
    return this.http.get<any>(`${environment.api}/get-dsa-bank-master`);
  }

  getIncentiveFolders(data: any) {
    return this.http.post<any>(`${environment.api}/getIncentiveFolders`, data);
    // return this.http.post<any>(`${environment.api}/get-incentive-folders`, data);
  }

  fetchScorecardDocuments(data:any){
    return this.http.post<any>(`${environment.documentURL}/fetch-scorecard-documents`, data);
  }
}
