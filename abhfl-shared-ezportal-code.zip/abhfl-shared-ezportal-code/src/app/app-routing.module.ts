import { UserConsentComponent } from './pages/user-consent/user-consent.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { AdLoginComponent } from './pages/ad-login/ad-login.component';
import { AuthGuard } from './services/guards/auth.guard';

const routes: Routes = [
  { path: '', component: AdLoginComponent },
  // {path: 'ad-login', component: AdLoginComponent },
  {path: 'onboarding/selectadvisory', component: LoginComponent },
  {path: 'onboarding/selectadvisory/:fullName/:emailId/:mobileNo', component: LoginComponent },
  {path: 'onboarding', component: LoginComponent },
  { path:'consent' , component: UserConsentComponent},
  { path: 'home', canActivate:[AuthGuard], loadChildren: () => import('./modules/home/home.module').then(m => m.HomeModule) },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
