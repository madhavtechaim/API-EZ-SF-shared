import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './pages/login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { HttpClientModule } from '@angular/common/http';
import { UserConsentComponent } from './pages/user-consent/user-consent.component';
import { AdLoginComponent } from './pages/ad-login/ad-login.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { BotDetectCaptchaModule } from 'angular-captcha';
import { NgxSpinnerModule } from 'ngx-spinner';
import {MatDatepickerModule} from '@angular/material/datepicker';

  import {MatAutocompleteModule} from '@angular/material/autocomplete';
  import {MatBottomSheetModule} from '@angular/material/bottom-sheet';
  import {MatButtonToggleModule} from '@angular/material/button-toggle';
  import {MatCardModule} from '@angular/material/card';
  import {MatChipsModule} from '@angular/material/chips';
  import {MatDialogModule} from '@angular/material/dialog';
  import {MatDividerModule} from '@angular/material/divider';
  import {MatExpansionModule} from '@angular/material/expansion';
  import {MatGridListModule} from '@angular/material/grid-list';
  import {MatListModule} from '@angular/material/list';
  import {MatMenuModule} from '@angular/material/menu';
  // import {MatNativeDateModule} from '@angular/material/d';
  import {MatPaginatorModule} from '@angular/material/paginator';
  import {MatProgressBarModule} from '@angular/material/progress-bar';
  import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
  import {MatRadioModule} from '@angular/material/radio';
  // import {MatRippleModule} from '@angular/material/';
  import {MatSelectModule} from '@angular/material/select';
  import {MatSidenavModule} from '@angular/material/sidenav';
  import {MatSliderModule} from '@angular/material/slider';
  import {MatSlideToggleModule} from '@angular/material/slide-toggle';
  import {MatSnackBarModule} from '@angular/material/snack-bar';
  import {MatSortModule} from '@angular/material/sort';
  import {MatStepperModule} from '@angular/material/stepper';
  import {MatTableModule} from '@angular/material/table';
  import {MatTabsModule} from '@angular/material/tabs';
  import {MatToolbarModule} from '@angular/material/toolbar';
  import {MatTooltipModule} from '@angular/material/tooltip';
  import {MatTreeModule} from '@angular/material/tree';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { CompleteApplicationComponent } from './modals/complete-application/complete-application.component';
import { NotificationComponent } from './modals/notification/notification.component';
import { UserApplicattionComponent } from './pages/user-applicattion/user-applicattion.component';
import { OAuthModule } from 'angular-oauth2-oidc';
import { AuthGuard } from './services/guards/auth.guard';
import { QueriesModalComponent } from './modals/queries-modal/queries-modal.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { TrainingModuleComponent } from './pages/training-module/training-module.component';
import { TrainingCompleteComponent } from './modals/training-complete/training-complete.component';
import { TrainingThankYouComponent } from './modals/training-thank-you/training-thank-you.component';
import { TrainingApprovalComponent } from './pages/training-approval/training-approval.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserConsentComponent,
    AdLoginComponent,
    CompleteApplicationComponent,
    NotificationComponent,
    UserApplicattionComponent,
    // QueriesModalComponent,
    // TrainingModuleComponent,
    // TrainingCompleteComponent,
    // TrainingThankYouComponent,
    // TrainingApprovalComponent,
  
    

   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    MatCheckboxModule,
    BotDetectCaptchaModule,
    NgxSpinnerModule,
    MatDatepickerModule,
    PdfViewerModule,

    MatAutocompleteModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      // Register the ServiceWorker as soon as the app is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000'
    }),
    OAuthModule.forRoot()
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
