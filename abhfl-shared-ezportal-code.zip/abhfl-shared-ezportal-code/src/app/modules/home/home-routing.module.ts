import { UserApplicattionComponent } from './../../pages/user-applicattion/user-applicattion.component';
import { ContentComponent } from './../../pages/content/content.component';
import { SubCategoryComponent } from './../../pages/sub-category/sub-category.component';
import { CategoryComponent } from './../../pages/category/category.component';
import { AddContentComponent } from './../../pages/add-content/add-content.component';
import { AddSubCategoryComponent } from './../../pages/add-sub-category/add-sub-category.component';
import { AddCategoryComponent } from 'src/app/pages/add-category/add-category.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ActivityListComponent } from 'src/app/pages/activity-list/activity-list.component';
import { AddEventComponent } from 'src/app/pages/add-event/add-event.component';
import { AddPartnerComponent } from 'src/app/pages/add-partner/add-partner.component';
import { AddressDetailsComponent } from 'src/app/pages/address-details/address-details.component';
import { BankDetailsComponent } from 'src/app/pages/bank-details/bank-details.component';
import { BasicDetailsComponent } from 'src/app/pages/basic-details/basic-details.component';
import { BureauDetailsComponent } from 'src/app/pages/bureau-details/bureau-details.component';
import { CodeOfConductComponent } from 'src/app/pages/code-of-conduct/code-of-conduct.component';
import { DashboardComponent } from 'src/app/pages/dashboard/dashboard.component';
import { DsaDashboardComponent } from 'src/app/pages/dsa-dashboard/dsa-dashboard.component';
import { EventDetailsComponent } from 'src/app/pages/event-details/event-details.component';
import { KycDetailsComponent } from 'src/app/pages/kyc-details/kyc-details.component';
import { PartnerDetailsComponent } from 'src/app/pages/partner-details/partner-details.component';
import { PartnerListComponent } from 'src/app/pages/partner-list/partner-list.component';
import { QueriesComponent } from 'src/app/pages/queries/queries.component';
import { TrainingModuleComponent } from 'src/app/pages/training-module/training-module.component';
import { ReferenceDetailsComponent } from 'src/app/pages/reference-details/reference-details.component';
import { ResourcesComponent } from 'src/app/pages/resources/resources.component';
import { UploadDocumentsComponent } from 'src/app/pages/upload-documents/upload-documents.component';
import { HomeComponent } from './home.component';
import { IncentiveCornerComponent } from 'src/app/pages/incentive-corner/incentive-corner.component';
import { IncentiveQueriesComponent } from 'src/app/pages/incentive-queries/incentive-queries.component';
import { FinancialInstitutionDetailsComponent } from 'src/app/pages/financial-institution-details/financial-institution-details.component';
import { TrainingComponent } from 'src/app/modals/training/training.component';
import { TrainingApprovalComponent } from 'src/app/pages/training-approval/training-approval.component';

const routes: Routes = [{
  path: '', component: HomeComponent, children: [
    { path: '', component: DashboardComponent },
    { path: 'resources', component: ResourcesComponent },
    { path: 'queries', component: QueriesComponent },
    { path: 'incentive-queries', component: IncentiveQueriesComponent },
    {path:'training', component:TrainingModuleComponent},
    
    { path: 'basic-details', component: BasicDetailsComponent },
    // { path: 'kyc-details', component: KycDetailsComponent },
    { path: 'kyc-details', component: KycDetailsComponent },
    { path: 'kyc-details/:isAadharVerification', component: KycDetailsComponent },
    { path: 'partner-details', component: PartnerDetailsComponent },
    { path: 'partner-details/:isDirectorAadharVerification', component: PartnerDetailsComponent },
    { path: 'address-details', component: AddressDetailsComponent },
    { path: 'bank-details', component: BankDetailsComponent },
    { path: 'upload-documents', component: UploadDocumentsComponent },
    { path: 'code-of-conduct', component: CodeOfConductComponent },
    { path: 'reference-details', component: ReferenceDetailsComponent },
    { path: 'financial-institution-details', component: FinancialInstitutionDetailsComponent },
    { path: 'bureau-details', component: BureauDetailsComponent },
    { path: 'dsa-dashboard', component: DsaDashboardComponent },
    { path: 'add-partner', component: AddPartnerComponent },
    { path: 'add-event', component: AddEventComponent },
    { path: 'event-details', component: EventDetailsComponent },
    { path: 'activity-list', component: ActivityListComponent },
    { path: 'incentive-corner', component: IncentiveCornerComponent },
    { path: 'partner-list', component: PartnerListComponent },
    { path: 'add-category', component: AddCategoryComponent },
    { path: 'add-subcategory', component: AddSubCategoryComponent },
    { path: 'add-content', component: AddContentComponent },
    { path: 'category', component: CategoryComponent },
    { path: 'subcategory', component: SubCategoryComponent },
    { path: 'content', component: ContentComponent },
    { path: 'userApplication', component: UserApplicattionComponent },
    { path: 'training-approval', component: TrainingApprovalComponent },

    //  { path: 'training-approval', component: TrainingApprovalComponent },

  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
