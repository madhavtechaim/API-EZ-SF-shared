import { NotificationComponent } from './../../modals/notification/notification.component';
import { StorageService } from './../../services/storage.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { environment } from '../../../environments/environment';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  userData: any;
  dsaUserData: any;
  userInfo: any;
  isDesktop: boolean = true;
  supportNumber: any =environment.tollfree_mobile_number;
  supportNumberText: any = environment.tollfree_mobile_number_text;

  constructor(private router: Router, private storageService:StorageService,public dialog: MatDialog) {
 
   }

  ngOnInit(): void {
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");


    console.log("this.userInfo",this.userInfo);
    
    this.userData = this.storageService.secureStorage.getItem('UserDetails');
    this.dsaUserData = this.storageService.secureStorage.getItem('DSAUserDetails');
    // console.log("this.userData",this.userData,this.dsaUserData);

    this.isDesktop = localStorage.getItem('deviceType') === 'desktop' ? true : false;
  }

  logout() {

    if(this.userData){
      this.storageService.secureStorage.clear();
      this.router.navigate(['/onboarding'])
     }else{
      this.storageService.secureStorage.clear();
       this.router.navigate(['/'])
     }
  }

  routeChange(){

    if(this.dsaUserData){
      this.router.navigate(['/home/dsa-dashboard'])
    }else{
      this.router.navigate(['/home/dsa-dashboard'])
    }
  }


  openNotification(){
 
      let value =''
      const dialogRef = this.dialog.open(NotificationComponent, {
        disableClose: true,
        width: '400px',
        data: { title: "Today's Event Notification", message: 'message' , inputValue:'data'},
      });
  
      dialogRef.afterClosed().subscribe(result => {
  
        // if(result){
        //   this.getUser();
        // }
        //success code here
      });
  
   
  }

}
