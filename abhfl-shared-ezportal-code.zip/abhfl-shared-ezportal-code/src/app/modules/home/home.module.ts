import { GstUploadDocComponent } from './../../components/gst-upload-doc/gst-upload-doc.component';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { WaitingAadharComponent } from './../../modals/waiting-aadhar/waiting-aadhar.component';
import { BankUploadDocComponent } from './../../components/bank-upload-doc/bank-upload-doc.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatMenuModule } from '@angular/material/menu';
import { DashboardComponent } from '../../pages/dashboard/dashboard.component';
import { ResourcesComponent } from '../../pages/resources/resources.component';
import { QueriesComponent } from '../../pages/queries/queries.component';

import { BasicDetailsComponent } from '../../pages/basic-details/basic-details.component';
import { KycDetailsComponent } from '../../pages/kyc-details/kyc-details.component';
import { ProgressBarComponent } from '../../components/progress-bar/progress-bar.component';
import { UploadDocumentComponent } from '../../components/upload-document/upload-document.component';
import { ApplicantPhotoComponent } from '../../components/applicant-photo/applicant-photo.component';
import { PartnerDetailsComponent } from '../../pages/partner-details/partner-details.component';
import { AddressDetailsComponent } from '../../pages/address-details/address-details.component';
import { BankDetailsComponent } from '../../pages/bank-details/bank-details.component';
import { UploadDocumentsComponent } from '../../pages/upload-documents/upload-documents.component';
import { ViewCardComponent } from '../../components/view-card/view-card.component';
import { CodeOfConductComponent } from '../../pages/code-of-conduct/code-of-conduct.component';
import { ReferenceDetailsComponent } from '../../pages/reference-details/reference-details.component';
import { BureauDetailsComponent } from '../../pages/bureau-details/bureau-details.component';
import { DownloadDocumentComponent } from '../../components/download-document/download-document.component';
import { DsaDashboardComponent } from '../../pages/dsa-dashboard/dsa-dashboard.component';
import { AddPartnerComponent } from '../../pages/add-partner/add-partner.component';
import { AddEventComponent } from '../../pages/add-event/add-event.component';
import { EventDetailsComponent } from '../../pages/event-details/event-details.component';
import { MatDialogModule } from '@angular/material/dialog';
import { ESignDocumentComponent } from '../../modals/e-sign-document/e-sign-document.component';
import { AadharComponent } from '../../modals/aadhar/aadhar.component';
import { OtpComponent } from '../../modals/otp/otp.component';
import { ConsentComponent } from '../../modals/consent/consent.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ShareLinkComponent } from '../../modals/share-link/share-link.component';
import { ClipboardModule } from 'ngx-clipboard';
import { PartnerListComponent } from '../../pages/partner-list/partner-list.component';
import { PartnerCardComponent } from '../../components/partner-card/partner-card.component';
import { ActivityListComponent } from '../../pages/activity-list/activity-list.component';
import { ActivityCardComponent } from '../../components/activity-card/activity-card.component';
import { ActivityFiltersComponent } from '../../modals/activity-filters/activity-filters.component';
import { PartnerFiltersComponent } from '../../modals/partner-filters/partner-filters.component';
import { AdhaarCurrentAddressComponent } from 'src/app/modals/adhaar-current-address/adhaar-current-address.component';
import { LogsComponent } from 'src/app/modals/logs/logs.component';
import { AddCategoryComponent } from 'src/app/pages/add-category/add-category.component';
import { AddSubCategoryComponent } from 'src/app/pages/add-sub-category/add-sub-category.component';
import { AddContentComponent } from 'src/app/pages/add-content/add-content.component';
import {MatRadioModule} from '@angular/material/radio';
import {MatTreeModule} from '@angular/material/tree';
import {MatExpansionModule} from '@angular/material/expansion';
import { BotDetectCaptchaModule } from 'angular-captcha';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner'
import { CategoryComponent } from 'src/app/pages/category/category.component';
import { SubCategoryComponent } from 'src/app/pages/sub-category/sub-category.component';
import { ContentComponent } from 'src/app/pages/content/content.component';
import {MatTableModule} from '@angular/material/table';
import { TrainingComponent } from 'src/app/modals/training/training.component';
import { MatNativeDateModule } from '@angular/material/core';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { IncentiveCornerComponent } from 'src/app/pages/incentive-corner/incentive-corner.component';
import { IncentiveQueriesComponent } from 'src/app/pages/incentive-queries/incentive-queries.component';
import { ViewQueryComponent } from 'src/app/modals/view-query/view-query.component';
import { RaisedQueryComponent } from 'src/app/modals/raised-query/raised-query.component';
import { RaisedQueryCommentComponent } from 'src/app/modals/raised-query-comment/raised-query-comment.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { FinancialInstitutionDetailsComponent } from 'src/app/pages/financial-institution-details/financial-institution-details.component';
import { TrainingApprovalComponent } from 'src/app/pages/training-approval/training-approval.component';
import { TrainingThankYouComponent } from 'src/app/modals/training-thank-you/training-thank-you.component';
import { TrainingCompleteComponent } from 'src/app/modals/training-complete/training-complete.component';
import { TrainingModuleComponent } from 'src/app/pages/training-module/training-module.component';
import { QueriesModalComponent } from 'src/app/modals/queries-modal/queries-modal.component';

@NgModule({
  declarations: [
    HomeComponent,
    DashboardComponent,
    ResourcesComponent,
    QueriesComponent,
    IncentiveQueriesComponent,
    BasicDetailsComponent,
    KycDetailsComponent,
    ProgressBarComponent,
    UploadDocumentComponent,
    ApplicantPhotoComponent,
    PartnerDetailsComponent,
    AddressDetailsComponent,
    BankDetailsComponent,
    UploadDocumentsComponent,
    ViewCardComponent,
    CodeOfConductComponent,
    ReferenceDetailsComponent,
    BureauDetailsComponent,
    DownloadDocumentComponent,
    DsaDashboardComponent,
    AddPartnerComponent,
    AddEventComponent,
    EventDetailsComponent,
    ESignDocumentComponent,
    AadharComponent,
    OtpComponent,
    ConsentComponent,
    ShareLinkComponent,
    PartnerListComponent,
    PartnerCardComponent,
    ActivityListComponent,
    IncentiveCornerComponent,
    ActivityCardComponent,
    ActivityFiltersComponent,
    ViewQueryComponent,
    RaisedQueryComponent,
    RaisedQueryCommentComponent,
    PartnerFiltersComponent,
    AdhaarCurrentAddressComponent,
    BankUploadDocComponent,
    LogsComponent,
    AddCategoryComponent,
    AddSubCategoryComponent,
    AddContentComponent,
    WaitingAadharComponent,
    CategoryComponent,
    SubCategoryComponent,
    ContentComponent,
    TrainingComponent,
    GstUploadDocComponent,
    FinancialInstitutionDetailsComponent,
    TrainingApprovalComponent,
    QueriesModalComponent,
    TrainingModuleComponent,
    TrainingCompleteComponent,
    TrainingThankYouComponent,

  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HomeRoutingModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatChipsModule,
    MatCheckboxModule,
    MatDialogModule,
    HttpClientModule,
    ClipboardModule,
    MatMenuModule,
    MatRadioModule,
    MatTreeModule,
    MatExpansionModule,
    BotDetectCaptchaModule,
    MatProgressSpinnerModule,
    MatTableModule,
    MatPaginatorModule,
    MatNativeDateModule,
    MatAutocompleteModule,
    PdfViewerModule
  ]
})
export class HomeModule { }
