import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-e-sign-document',
  templateUrl: './e-sign-document.component.html',
  styleUrls: ['./e-sign-document.component.scss']
})
export class ESignDocumentComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ESignDocumentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
  }

  continue() {
    this.dialogRef.close(true);
  }

}
