import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-training',
  templateUrl: './training.component.html',
  styleUrls: ['./training.component.scss']
})
export class TrainingComponent implements OnInit {
  spinner: boolean;

  constructor(public dialogRef: MatDialogRef<TrainingComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _apiService:ApiService) { }

  ngOnInit(): void {
    this.verifyAadhar()

    // console.log("this.datathis.data",this.data);

  }
  verifyAadhar() {
    let data ={}

    // this._apiService.adharData({
    //   accessRequestId: this.data.requestId,
    //   caseId : this.data.caseId?this.data.caseId:'',
    //   adharNumber:this.data.aadharId
    // }).subscribe((response: any) => {
    //   if (!response.error) {
    //     Swal.fire({
    //       position: 'center',
    //       icon: 'success',
    //       title: response.message,
    //       showConfirmButton: false,
    //       timer: 1500
    //     })
    //     this.spinner = false;
    //     this.dialogRef.close(true);
    //   } else {
    //     Swal.fire({
    //       position: 'center',
    //       icon: 'warning',
    //       title: response.message,
    //       showConfirmButton: false,
    //       timer: 1500
    //     })
    //     this.spinner = false;
    //     this.dialogRef.close(false);
    //   }
    // },
    //   (err: HttpErrorResponse) => {
    //     if (err.status === 400) {
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'error',
    //         title: err.error.message,
    //         showConfirmButton: false,
    //         timer: 1500
    //       })
    //       this.spinner = false;
    //       this.dialogRef.close(false);

    //     } else {
    //       Swal.fire({
    //         position: 'center',
    //         icon: 'error',
    //         title: err.error.message ? err.error.message: 'Server error' ,
    //         showConfirmButton: false,
    //         timer: 1500
    //       })
    //       this.spinner = false;
    //       this.dialogRef.close(false);
    //     }
    //   })


  
  }


  continue() {
    this.dialogRef.close(false);
  }

}
