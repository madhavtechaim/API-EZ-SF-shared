import { FormArray, FormBuilder, FormControl } from '@angular/forms';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-activity-filters',
  templateUrl: './activity-filters.component.html',
  styleUrls: ['./activity-filters.component.scss']
})
export class ActivityFiltersComponent implements OnInit {
  form: any;
  formArray: FormArray;
  agentType: any=[];
  appointmentStatus: any[]=[];
  eventName: any[]=[];
  eventType: any[]=[];

  constructor(public dialogRef: MatDialogRef<ActivityFiltersComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private fb:FormBuilder) { }

  ngOnInit(): void {

    this.form = this.fb.group({
      agentType:[''],
      appointmentFromDate:[''],
      appointmentToDate:[''],
      appointmentStatus:[''],
      eventName:[''],
      eventType:[''],
    })
  }

  checkChange(event:any,value:any) {

    if(value =='agentType'){
      this.agentType =  this.checkBox(event.source.value,event.source.checked,this.agentType);
    }else if(value =='appointmentStatus'){
      this.appointmentStatus =  this.checkBox(event.source.value,event.source.checked,this.appointmentStatus);
    }else if(value =='eventName'){
      this.eventName =  this.checkBox(event.source.value,event.source.checked,this.eventName);
    }else if(value =='eventType'){
      this.eventType =  this.checkBox(event.source.value,event.source.checked,this.eventType);
    }
   
  }

  checkBox(value:any,checked:any,array:any) {
    let arrayData = [...array] 
    if(checked){
      arrayData.push(value)
    }else{
      arrayData.forEach((ctrl: any,i:any) => {
      if(ctrl == value) {
        arrayData.splice(i,1)
      }
    });
    }
    return arrayData
  }




  continue() {
    // console.log(this.form);
    let data={
      startDate:"",
      fromDate:this.form.value.appointmentFromDate,
      toDate:this.form.value.appointmentToDate,
      agentType:this.agentType,
      eventTitle:this.eventName,
      // eventType:this.eventType,
      eventStatus:this.appointmentStatus,
      // searchTerm:''
    }

   
    // return;
    
    this.dialogRef.close({data:data , status:true});
  }

}
