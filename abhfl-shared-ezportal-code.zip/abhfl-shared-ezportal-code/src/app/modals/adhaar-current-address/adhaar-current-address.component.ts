import { Component, OnInit,Inject } from '@angular/core';
import { StorageService } from 'src/app/services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import { AuthService } from './../../services/auth.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-adhaar-current-address',
  templateUrl: './adhaar-current-address.component.html',
  styleUrls: ['./adhaar-current-address.component.scss']
})
export class AdhaarCurrentAddressComponent implements OnInit {
  otpForm: FormGroup;
  formSumitAttempt: any=false;
  address: any;

  constructor(public dialogRef: MatDialogRef<AdhaarCurrentAddressComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb:FormBuilder, private _auth:AuthService,public _apiService:ApiService, private storageService:StorageService,private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    // console.log("data",this.data);

    this.otpForm= this.fb.group({
      addressType:['',[Validators.required]]
    })


  }

  get f() {
    return this.otpForm.controls;
  }

  
  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }


  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  continue(){
    this.formSumitAttempt= true;
    this.address = this.storageService.secureStorage.getItem('UserAddress');

    if(this.otpForm.invalid){
      return
    }


    this.spinner.show();
    let data={
      caseId:this.data.inputValue,
      addressFlag:1,
      address_type : this.otpForm.value.addressType,
      // addressline1 : this.address.line1 ,
      // addressline2 : this.address.line2,
      // pincode : this.address.pin,
      // area : this.address.locality,
      // landmark : this.address.landmark  ,
      // city : this.address.vtc,
      // district : this.address.district,
      // state : this.address.state,
      // country : this.address.country
    }

    this._apiService.setCurrentAddress(data).subscribe(
      (response: any) => {
        if(!response.error){
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          
        this.dialogRef.close(true);
        }else{
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
      (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
      }
    );

  }

}
