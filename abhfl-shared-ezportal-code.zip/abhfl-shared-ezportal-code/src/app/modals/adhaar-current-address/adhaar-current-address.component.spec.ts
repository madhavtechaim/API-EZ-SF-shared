import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdhaarCurrentAddressComponent } from './adhaar-current-address.component';

describe('AdhaarCurrentAddressComponent', () => {
  let component: AdhaarCurrentAddressComponent;
  let fixture: ComponentFixture<AdhaarCurrentAddressComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdhaarCurrentAddressComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdhaarCurrentAddressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
