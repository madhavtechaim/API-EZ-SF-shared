import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompleteApplicationComponent } from './complete-application.component';

describe('CompleteApplicationComponent', () => {
  let component: CompleteApplicationComponent;
  let fixture: ComponentFixture<CompleteApplicationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompleteApplicationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompleteApplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
