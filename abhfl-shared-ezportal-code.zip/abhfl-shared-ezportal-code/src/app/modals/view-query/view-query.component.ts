import { FormArray, FormBuilder, FormControl } from '@angular/forms';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RaisedQueryCommentComponent } from '../raised-query-comment/raised-query-comment.component';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { StorageService } from 'src/app/services/storage.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiService } from 'src/app/services/api.service';
import { environment } from 'src/environments/environment';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-view-query',
  templateUrl: './view-query.component.html',
  styleUrls: ['./view-query.component.scss']
})
export class ViewQueryComponent implements OnInit {
  form: any;
  formArray: FormArray;
  agentType: any=[];
  appointmentStatus: any[]=[];
  eventName: any[]=[];
  eventType: any[]=[];
  userInfo: any;
  typeData: any;
  queryData: any=[];
  querydocumentData: any;
  filePath: string;
  commentsData: any;
  newPopup:any;
  querydocument: any;
  routeSub: any;
  id: number;
  sub: any;
  filesize: string;
  constructor(private route: ActivatedRoute,private router:Router,public storageService:StorageService,private spinner: NgxSpinnerService,public _apiService: ApiService,public dialog: MatDialog ,public dialogRef: MatDialogRef<ViewQueryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, @Inject(MAT_DIALOG_DATA) public data1: any,private fb:FormBuilder) { }

  ngOnInit(): void {

    this.filePath = environment.imgUrl;
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    this.form = this.fb.group({
      agentType:[''],
      appointmentFromDate:[''],
      appointmentToDate:[''],
      appointmentStatus:[''],
      eventName:[''],
      eventType:[''],
    })
    this.getsingledocumentQueryDetails();
    this.getdocumentqueryComment();
  }


  cancelSave(): void {
    this.dialogRef.close();
    }
  raisedComments(): void {
    const dialogRef = this.dialog.open(RaisedQueryCommentComponent, {
      data:{'data':this.data},
      disableClose: true,
      panelClass:'small-css'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        dialogRef.close();
        this.getsingledocumentQueryDetails();
        this.getdocumentqueryComment();
        this.querydocumentData;
      }
  
    });
  }

  DownloadProjectDocuments(doc:any) {
    console.log("-------->",doc)
      let path=doc[0].path.replace('uploads/DSA/Document_Attachment','');
      if (doc[0].storage_location == 'FILE_SYSTEM'){
        window.open(environment.imgUrl + "uploads/DSA/Document_Attachment/" + path.substr(0, path.lastIndexOf('.')) + "." + path.substr(path.lastIndexOf('.') + 1));
      //  this._apiService.attachmentDownload(doc[0].path, doc[0].type, doc[0].file_name);
      } else{
        this._apiService.attachmentDownload(doc[0].path, doc[0].type, doc[0].file_name);
       }
      /*  (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }

    }) */
  }

  DownloadProjectDocumentsCooments(doc:any) {
    console.log("-------->",doc)
      let path=doc.path//.replace('uploads/DSA/Document_Attachment','');
      console.log(path);
      if (doc.storage_location == 'FILE_SYSTEM'){
        window.open(environment.imgUrl + "uploads/DSA/Document_Attachment/" + path.substr(0, path.lastIndexOf('.')) + "." + path.substr(path.lastIndexOf('.') + 1));
      //  this._apiService.attachmentDownload(doc[0].path, doc[0].type, doc[0].file_name);
      } else{
        this._apiService.attachmentDownload(doc[0].path, doc[0].type, doc[0].file_name);
       }
      /*  (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }

    }) */
  }

  getsingledocumentQueryDetails() {
   this.spinner.show();
    let data = {
      token:this.userInfo.token,
      version:this.userInfo.version,
      qID:this.data.item
    }
    this._apiService.getsingledocumentQueryDetails(data).subscribe((res) => {
  
      this.queryData = res.queryData[0];
      this.querydocument = res.querydocumentData;
      this.querydocumentData = res.querydocumentData[0];
      this.filesize=(this.querydocumentData.fileSize/(1024 * 1024)).toFixed(3);
      console.log(">>.>.>", res)
      this.spinner.hide();

    },
     (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }

    })
  }

  getdocumentqueryComment() {
      this.spinner.show();
       let data = {
         token:this.userInfo.token,
         version:this.userInfo.version,
         documentId:this.data.id,
         id:this.data.item
       }
       this._apiService.getdocumentqueryComment(data).subscribe((res) => {
       this.commentsData = res.logData;
       this.commentsData.forEach((element: { documentData: any[]; }) => {
        element.documentData.forEach(element1 => {
          element1.fileSize=(element1.fileSize/(1024 * 1024)).toFixed(2);
        });
       });
         console.log("----->", this.commentsData)
         this.spinner.hide();
   
       }, (err: HttpErrorResponse) => {
         this.spinner.hide();
         if (err.status === 400) {
           Swal.fire({
             position: 'center',
             icon: 'success',
             title: err.error.message,
             showConfirmButton: false,
             timer: 1500
           })
   
         } else {
           Swal.fire({
             position: 'center',
             icon: 'error',
             title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
             showConfirmButton: false,
             timer: 1500
           })
         }
   
       })
     }
  

  checkChange(event:any,value:any) {
    if(value =='agentType'){
      this.agentType =  this.checkBox(event.source.value,event.source.checked,this.agentType);
    }else if(value =='appointmentStatus'){
      this.appointmentStatus =  this.checkBox(event.source.value,event.source.checked,this.appointmentStatus);
    }else if(value =='eventName'){
      this.eventName =  this.checkBox(event.source.value,event.source.checked,this.eventName);
    }else if(value =='eventType'){
      this.eventType =  this.checkBox(event.source.value,event.source.checked,this.eventType);
    }
   
  }

  checkBox(value:any,checked:any,array:any) {
    let arrayData = [...array] 
    if(checked){
      arrayData.push(value)
    }else{
      arrayData.forEach((ctrl: any,i:any) => {
      if(ctrl == value) {
        arrayData.splice(i,1)
      }
    });
    }
    return arrayData
  }




  continue() {
    // console.log(this.form);
    let data={
      startDate:"",
      fromDate:this.form.value.appointmentFromDate,
      toDate:this.form.value.appointmentToDate,
      agentType:this.agentType,
      eventTitle:this.eventName,
      // eventType:this.eventType,
      eventStatus:this.appointmentStatus,
      // searchTerm:''
    }

   
    // return;
    
    this.dialogRef.close({data:data , status:true});
  }

}
