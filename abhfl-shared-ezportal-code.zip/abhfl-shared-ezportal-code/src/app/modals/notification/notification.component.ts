import { ApiService } from 'src/app/services/api.service';
import { StorageService } from './../../services/storage.service';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit {
  userInfo: any;
  selectedDate=new Date();
  dayEventList: any;
  moment =moment;
  constructor(public dialogRef: MatDialogRef<NotificationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private storageService:StorageService,private _apiService:ApiService) { }

  ngOnInit(): void {
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");


    // console.log(moment(this.selectedDate).format("YYYY-MM-DD hh:mm A"));
    
    this.getEventList();


  }

  continue() {
    this.dialogRef.close(true);
  }


  getEventList() {
    // this.spinner.show();
    let data = {
      startDate: moment(this.selectedDate).format("YYYY-MM-DD"),
      // startDate:'2022-10-12',
      fromDate: "",
      toDate: "",
      agentType: "",
      eventTitle: "",
      eventType: "",
      eventStatus: "",
      token : this.userInfo.token,
      version : this.userInfo.version
    }



    this._apiService.getEventList(data).subscribe((res) => {

      this.dayEventList = res.eventData;


      this.dayEventList = this.dayEventList.filter((ele:any)=>
      {
        // console.log(ele.start_time ,moment(this.selectedDate).format("HH:mm:ss") );
        
       return ele.start_time > moment(this.selectedDate).format("HH:mm:ss")
      }
      
      );


      // console.log("this.dayEventListthis.dayEventList",this.dayEventList);
      
      // this.spinner.hide();

      // res.eventData.forEach(element => {
      //   element.start_time=moment(element.start_time).format('hh:mm A');
      // });

    }, (err: HttpErrorResponse) => {
      // this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
   
    })
  }


}
