import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WaitingAadharComponent } from './waiting-aadhar.component';

describe('WaitingAadharComponent', () => {
  let component: WaitingAadharComponent;
  let fixture: ComponentFixture<WaitingAadharComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WaitingAadharComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WaitingAadharComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
