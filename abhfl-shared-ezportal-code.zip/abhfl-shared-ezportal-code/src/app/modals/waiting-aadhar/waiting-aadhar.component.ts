import { StorageService } from './../../services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-waiting-aadhar',
  templateUrl: './waiting-aadhar.component.html',
  styleUrls: ['./waiting-aadhar.component.scss']
})
export class WaitingAadharComponent implements OnInit {
  spinner: boolean;
  userInfo: any;


  constructor(public dialogRef: MatDialogRef<WaitingAadharComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _apiService:ApiService, private storageService:StorageService,private spinn: NgxSpinnerService) { }

  ngOnInit(): void {
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    this.verifyAadhar();

    // console.log("this.datathis.data",this.data);
    this.spinner = true;
    

  }
  verifyAadhar() {

    // let data ={}

    if(!this.data.dirId){
      this.spinn.show();
      this._apiService.adharData({
        accessRequestId: this.data.requestId,
        caseId : this.data.caseId?this.data.caseId:'',
        token: this.userInfo.token,
        adharNumber:this.data.aadharId
      }).subscribe((response: any) => {
        if (!response.error) {
          this.spinn.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.spinner = false;
          this.storageService.secureStorage.setItem('UserAddress' ,response.data.result[0].parsedFile.data.issuedTo.address)
          this.dialogRef.close(true);
        } else {
          this.spinn.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.spinner = false;
          this.dialogRef.close(false);
        }
      },
        (err: HttpErrorResponse) => {
          this.spinn.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
            this.spinner = false;
            this.dialogRef.close(false);
  
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
            this.spinner = false;
            this.dialogRef.close(false);
          }
        })
    }
    else{
      this.spinn.show();
      this._apiService.adharDirData({
        accessRequestId: this.data.requestId,
        caseId : this.data.caseId?this.data.caseId:'',
        adharNumber:this.data.aadharId,
        token: this.userInfo.token,
        directorId : this.data.dirId?this.data.dirId:null
      }).subscribe((response: any) => {
        if (!response.error) {
          this.spinn.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.spinner = false;
          this.dialogRef.close(true);
        } else {
          this.spinn.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.spinner = false;
          this.dialogRef.close(false);
        }
      },
        (err: HttpErrorResponse) => {
          this.spinn.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
            this.spinner = false;
            this.dialogRef.close(false);
  
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
            this.spinner = false;
            this.dialogRef.close(false);
          }
        })
    }
  }


  continue() {
    this.dialogRef.close(false);
  }

}
