import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, Inject, Output, EventEmitter } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiService } from 'src/app/services/api.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-raised-query',
  templateUrl: './raised-query.component.html',
  styleUrls: ['./raised-query.component.scss']
})
export class RaisedQueryComponent implements OnInit {
  form: FormGroup;
  @Output() detect = new EventEmitter<boolean>();
  formSumitAttempt: boolean;
  flag: boolean = false;
  isWebRequest: boolean = false;
  formArray: FormArray;
  heading:string='Upload Document';
  subheading:any='Please upload .pdf, .jpg. File limit is 5MB';
  agentType: any=[];
  appointmentStatus: any[]=[];
  eventName: any[]=[];
  eventType: any[]=[];
  rollslist=[{'name':'narendra'}];
  typeData: any;
  uploadfile: File;
  userInfo: any;
  typeDatas: any;
  queryNo: any;
  constructor(public storageService:StorageService,private spinner: NgxSpinnerService,public _apiService: ApiService,public dialogRef: MatDialogRef<RaisedQueryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private fb:FormBuilder) { }

  ngOnInit(): void {
    console.log("=====>",this.data);
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
this.getTypeMaster();
    this.form = this.fb.group({
      queryType:[null, [Validators.required]],
      querySubject:[null, [Validators.required]],
      queryDescription:[null, [Validators.required]],

    })
  }

  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }

  uploadEaisedDoc(event:any){
    this.uploadfile = event.target.files[0];
    this.subheading=(this.uploadfile.size/(1024 * 1024)).toFixed(3);
    this.heading=this.uploadfile.name;
    console.log("========>",this.uploadfile);
  }


  getTypeMaster() {
    this.spinner.show();
// data={"fromDate":"2022-01-05","toDate":"2023-01-04","partnerType":"","eventTitle":"","eventType":"","type":"Queries","searchTerm":"","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjE4ODMsImlhdCI6MTY3Mjc0MTkzMSwiZXhwIjoxNjg4NTA5OTMxfQ.5vgwYu8W0Bdax5pi5reHUwv3ARCE4qy5XuVpttO3PoI","version":19,"filterType":"Range"}
    // data.type = data.type !='All'?data.type :''
    let data = {
      token:this.userInfo.token,//'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjE4ODMsImlhdCI6MTY3NjAzNDYyMCwiZXhwIjoxNjkxODAyNjIwfQ.eDbRh9dh8sPtdflgEnXfqjzKhFF61cgjMkRbkBuBJao',//this.storageService.secureStorage.getItem('token'),
      version:this.userInfo.version,//this.storageService.secureStorage.getItem('version')
    }
    this._apiService.getTypeMaster(data).subscribe((res) => {
      // console.log(">>.>.>", res)
      this.typeData = res.docData;
      console.log(">>.>.>", this.typeData);
      this.spinner.hide();

    }, (err: HttpErrorResponse) => {
      this.spinner.hide();
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
          showConfirmButton: false,
          timer: 1500
        })
      }

    })
  }

  clickevent(event:any){
    console.log("-------->",event)
    this.typeDatas=event;

  }
  submit() {
    this.formSumitAttempt = true;
    // console.log(this.form.value)
   /*  if(this.uploadfile==null){
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Please upload Document',
        showConfirmButton: false,
        timer: 1500
      })
      this.flag=false;
    }else{
      this.flag=true;
    } */
    if (this.form.valid ) {/* && this.flag==true */
      this.isWebRequest = true;
      let data={
        queryType:this.typeDatas.type_name,
        role:this.typeDatas.assign_role,
        assignTo:null,
        querySubject:this.form.value.querySubject,
        queryCategory:null,
        queryDescription:this.form.value.queryDescription,
        documentType:null,
        documentcaseId:this.data,
        token:this.userInfo.token,//'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJsdW1lbi1qd3QiLCJzdWIiOjE4ODMsImlhdCI6MTY3NjAzNDYyMCwiZXhwIjoxNjkxODAyNjIwfQ.eDbRh9dh8sPtdflgEnXfqjzKhFF61cgjMkRbkBuBJao',
        version:this.userInfo.version}
      
      /* { ...this.form.value} */
       console.log(data);
    this._apiService.addInsertdocumentqueryRaised(data).subscribe((response:any)=>{
      if(!response.error){
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
        this.dialogRef.close('true') 
        this.detect.emit(true);
        this.queryNo=response.queryNo
        
        if(this.uploadfile!=null)
          {
         this.uploadDoc();
          }        
        //this.router.navigate(['/home/add-subcategory'])
      }else{
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: response.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    },
    (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
    }
    
  }


  uploadDoc(){
    // const file = event.target.files[0]
     this.spinner.show();
 
      if(this.uploadfile.size > 5242880){
       Swal.fire({
         position: 'center',
         icon: 'warning',
         title: "Document size should be up to 5MB",
         showConfirmButton: false,
         timer: 1500
       })
       this.spinner.hide();
       return;
     }
 
     if(this.uploadfile.type == 'image/png' || this.uploadfile.type == 'image/jpeg' || this.uploadfile.type == 'image/jpg' ||this.uploadfile.type == 'application/pdf' || this.uploadfile.type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || this.uploadfile.type == 'vnd.ms-excel' || this.uploadfile.type == 'application/msword'|| this.uploadfile.type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'){ 
 
       const dataUp = new FormData();
       dataUp.append('file',this.uploadfile);
       dataUp.append('documentcaseId', this.data);
       dataUp.append('qid',this.queryNo );/* 'Q2023020800002' this.queryNo*/
       dataUp.append('version',this.userInfo.version);
       dataUp.append('token',this.userInfo.token,);
 
       console.log("===>",dataUp);
       this._apiService.uploadDocumentAttachment(dataUp).subscribe((response:any)=>{
         if(!response.error){
           this.spinner.hide();
         /*   Swal.fire({
             position: 'center',
             icon: 'success',
             title: response.message,
             showConfirmButton: false,
             timer: 1500
           }) */
           this.detect.emit(true);
          
         }else{
           this.spinner.hide();
           Swal.fire({
             position: 'center',
             icon: 'warning',
             title: response.message,
             showConfirmButton: false,
             timer: 1500
           })
         }
       },(err: HttpErrorResponse) =>
         {
           this.spinner.hide();
         if (err.status === 400 || err.status === 500) {
           Swal.fire({
             position: 'center',
             icon: 'error',
             title: err.error.message,
             showConfirmButton: false,
             timer: 1500
           })
         }  else {
           Swal.fire({
             position: 'center',
             icon: 'error',
             title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
             showConfirmButton: false,
             timer: 1500
           })
         }
       })
 
      }else{
       this.spinner.hide();
       Swal.fire({
         position: 'center',
         icon: 'warning',
         title: 'Please upload pdf, jpg , jpeg ,doc,excel or  png image',
         showConfirmButton: false,
         timer: 1500
       })
     } 
 
 
   }
  checkChange(event:any,value:any) {

    if(value =='agentType'){
      this.agentType =  this.checkBox(event.source.value,event.source.checked,this.agentType);
    }else if(value =='appointmentStatus'){
      this.appointmentStatus =  this.checkBox(event.source.value,event.source.checked,this.appointmentStatus);
    }else if(value =='eventName'){
      this.eventName =  this.checkBox(event.source.value,event.source.checked,this.eventName);
    }else if(value =='eventType'){
      this.eventType =  this.checkBox(event.source.value,event.source.checked,this.eventType);
    }
   
  }

  checkBox(value:any,checked:any,array:any) {
    let arrayData = [...array] 
    if(checked){
      arrayData.push(value)
    }else{
      arrayData.forEach((ctrl: any,i:any) => {
      if(ctrl == value) {
        arrayData.splice(i,1)
      }
    });
    }
    return arrayData
  }



}
