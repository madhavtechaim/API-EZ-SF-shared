import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiService } from 'src/app/services/api.service';
import { AuthService } from 'src/app/services/auth.service';
import { StorageService } from 'src/app/services/storage.service';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-logs',
  templateUrl: './logs.component.html',
  styleUrls: ['./logs.component.scss']
})
export class LogsComponent implements OnInit {
  otpForm: FormGroup;
  formSumitAttempt: any=false;
  list: any=[];
  moment: any = moment;
  userInfo: any;

  constructor(public dialogRef: MatDialogRef<LogsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb:FormBuilder, private _auth:AuthService,public _apiService:ApiService, private storageService:StorageService, private spinner: NgxSpinnerService) { }

  ngOnInit(): void {

    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
   
    // console.log("data",this.data);
    this.getLogs();
  }





  getLogs(){
    this.spinner.show();
    let data={
      eventId:this.data.inputValue,
      // token:this.storageService.secureStorage.getItem('token'),
      // version:this.storageService.secureStorage.getItem('version')
      token : this.userInfo.token,
      version : this.userInfo.version
    }
      this._apiService.getLogs(data).subscribe((res) => {
        if(!res.error){
          this.list = res['logData'];
          this.spinner.hide();
        }else{
          this.spinner.hide();
        }
   
      }, (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
  
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
      })
    }
  

  continue(){
  
    this.dialogRef.close(true);



  }

}
