import { ApiService } from 'src/app/services/api.service';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-consent',
  templateUrl: './consent.component.html',
  styleUrls: ['./consent.component.scss']
})
export class ConsentComponent implements OnInit {

  consentTypes: any[] = [];
  constructor(public dialogRef: MatDialogRef<ConsentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any , private _apiService:ApiService , private spinner: NgxSpinnerService ) { }

  ngOnInit(): void {
    // console.log(this.data);

    this.consentTypes= JSON.parse(this.data.messeage);
  }

  continue() {

    if(this.data.title =='ITR Consent'){
      this.spinner.show();
      this._apiService.getITRVerify({...this.data.itr}).subscribe((res:any)=>{
        if(!res.error){
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: res.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.dialogRef.close(true);
        }else{
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: res.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },(err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })

        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
    })

    }else{
      this.dialogRef.close(true);
    }

  }

}
