import { environment } from 'src/environments/environment';
import { Component, OnInit, Inject, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import Swal from 'sweetalert2'
import { HttpErrorResponse } from '@angular/common/http';
import { ApiService } from 'src/app/services/api.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { StorageService } from 'src/app/services/storage.service';
@Component({
  selector: 'app-share-link',
  templateUrl: './share-link.component.html',
  styleUrls: ['./share-link.component.scss']
})
export class ShareLinkComponent implements OnInit {
  details: any = navigator.userAgent;
  regexp: any = /android|iphone|kindle|ipad/i;
  isMobileDevice: any;
  // @Input() data: any

  patnerLink: string;
  isLinkCopied: any = false;

  constructor(public dialogRef: MatDialogRef<ShareLinkComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public _apiService: ApiService,
    private spinner: NgxSpinnerService,
    private storageService: StorageService) { }

  ngOnInit(): void {
    this.isMobileDevice = this.regexp.test(this.details);

    // if (this.isMobileDevice) {
    //   console.log("You are using a Mobile Device");
    // } else {
    console.log("You are using Desktop", this.data);
    // }
    this.patnerLink = environment.partnerlink;
  }

  onClickCopyIcon() {
    this.isLinkCopied = true;
    // Swal.fire({
    //   position: 'center',
    //   icon: 'success',
    //   title: "Successfully copied",
    //   showConfirmButton: false,
    //   timer: 1500
    // })
  }

  onClickShareBtn = () => {
    // console.log("===");
    if (navigator.share != undefined)
      navigator.share({
        title: document.title,
        text: 'Share link',
        url: this.patnerLink
      })
        .then(() => "")
        .catch(err => "");
  }

  sendLink() {
    this.spinner.show();
    // Swal.fire({
    //   position: 'center',
    //   icon: 'success',
    //   title: "Link Send To Partner",
    //   showConfirmButton: false,
    //   timer: 1500
    // })
    let data = this.data
    this._apiService.sendOnboardingLinksToPartners(data).subscribe((res: any) => {
      if (!res.error) {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'warning',
          title: res.message,
          showConfirmButton: false,
          timer: 1500
        })
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        this.spinner.hide();
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      // this.isWebRequest = false;
    })
  }

}
