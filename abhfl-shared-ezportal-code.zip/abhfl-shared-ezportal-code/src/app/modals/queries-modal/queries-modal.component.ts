import { StorageService } from 'src/app/services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import { AuthService } from './../../services/auth.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-queries-modal',
  templateUrl: './queries-modal.component.html',
  styleUrls: ['./queries-modal.component.scss']
})
export class QueriesModalComponent implements OnInit {
  
  constructor(public dialogRef: MatDialogRef<QueriesModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any , private _apiService:ApiService , private spinner: NgxSpinnerService ) { }



  ngOnInit(): void {
    // console.log("******",this.data)
  }

}
