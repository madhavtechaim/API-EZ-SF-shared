import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, Inject, Output, EventEmitter } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { ApiService } from 'src/app/services/api.service';
import { StorageService } from 'src/app/services/storage.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { EventService } from 'src/app/services/events.service';

@Component({
  selector: 'app-raised-query-comment',
  templateUrl: './raised-query-comment.component.html',
  styleUrls: ['./raised-query-comment.component.scss']
})
export class RaisedQueryCommentComponent implements OnInit {
  form: FormGroup;
  formArray: FormArray;
  formSumitAttempt: boolean;
  flag: boolean = false;
  isWebRequest: boolean = false;
  agentType: any = [];
  appointmentStatus: any[] = [];
  eventName: any[] = [];
  eventType: any[] = [];
  heading: string = 'Upload Document';
  subheading: any = 'Please upload .pdf, .jpg. File limit is 5MB';
  id: 1;
  rollslist = [{ 'name': 'narendra' }];
  userInfo: any;
  @Output() detect = new EventEmitter<boolean>();
  uploadfile: File;
  attachmentId: any;
  constructor(public eventService: EventService, public storageService: StorageService, private spinner: NgxSpinnerService, public _apiService: ApiService, public dialogRef: MatDialogRef<RaisedQueryCommentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder) { }

  ngOnInit(): void {
    console.log("======>", this.data.data.item);
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");
    this.form = this.fb.group({
      remark: [null, [Validators.required]],
    })
  }

  get f() {
    return this.form.controls;
  }

  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }
  checkChange(event: any, value: any) {

    if (value == 'agentType') {
      this.agentType = this.checkBox(event.source.value, event.source.checked, this.agentType);
    } else if (value == 'appointmentStatus') {
      this.appointmentStatus = this.checkBox(event.source.value, event.source.checked, this.appointmentStatus);
    } else if (value == 'eventName') {
      this.eventName = this.checkBox(event.source.value, event.source.checked, this.eventName);
    } else if (value == 'eventType') {
      this.eventType = this.checkBox(event.source.value, event.source.checked, this.eventType);
    }

  }

  uploadREaisedDoc(event: any) {
    this.uploadfile = event.target.files[0];
    this.subheading = (this.uploadfile.size / (1024 * 1024)).toFixed(3);
    this.heading = this.uploadfile.name;
    console.log("========>", this.uploadfile);
  }





  submit() {

    /*  if(this.uploadfile==null){
       Swal.fire({
         position: 'center',
         icon: 'warning',
         title: 'Please upload Document',
         showConfirmButton: false,
         timer: 1500
       })
       this.flag=false;
     }else{
       this.flag=true;
     } */
    this.formSumitAttempt = true;
    // console.log(this.form.value)

    if (this.form.valid) {/* && this.flag==true */
      this.spinner.show();

      this.isWebRequest = true;
      let data = {
        remark: this.form.value.remark,
        documentId: this.data.data.id,
        id: this.data.data.item,
        token: this.userInfo.token,
        version: this.userInfo.version
      }
      /* { ...this.form.value} */
      console.log(data);
      this._apiService.adddocumentqueryComment(data).subscribe((response: any) => {
        if (!response.error) {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })

          this.attachmentId = response.id;
          if (this.data.data.type == 'Reopen') {
            this.statusChange();
          }
          // this.statusChange();
          if (this.uploadfile != null) {
            this.uploadDoc();
          } else {
            this.spinner.hide();
            this.dialogRef.close('true')
            this.eventService.activityAddComment.next(true);

          }

          //this.router.navigate(['/home/add-subcategory'])
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        })
    }

  }

  statusChange() {
    this.formSumitAttempt = true;
    // console.log(this.form.value)
    if (this.form.valid) {
      this.isWebRequest = true;
      let data = {
        remark: this.form.value.remark,
        documentcaseId: this.data.data.id,
        queryId: this.data.data.item,
        token: this.userInfo.token,
        version: this.userInfo.version
      }

      /* { ...this.form.value} */
      console.log(data);
      this._apiService.updateDocumentQueryStatus(data).subscribe((response: any) => {
        if (!response.error) {
          /*  Swal.fire({
             position: 'center',
             icon: 'success',
             title: response.message,
             showConfirmButton: false,
             timer: 1500
           }) */
          this.dialogRef.close('true')
          this.attachmentId = response.id;
          this.eventService.activityAddComment.next(true);
          // this.uploadDoc();
          //this.router.navigate(['/home/add-subcategory'])
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
          this.isWebRequest = false;
        })
    }

  }
  uploadDoc() {
    // const file = event.target.files[0]

    if (this.uploadfile.size > 5242880) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: "Document size should be up to 5MB",
        showConfirmButton: false,
        timer: 1500
      })
      this.spinner.hide();
      return;
    }


    if (this.uploadfile.type == 'image/png' || this.uploadfile.type == 'image/jpeg' || this.uploadfile.type == 'image/jpg' || this.uploadfile.type == 'application/pdf' || this.uploadfile.type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || this.uploadfile.type == 'vnd.ms-excel' || this.uploadfile.type == 'application/msword' || this.uploadfile.type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      const dataUp = new FormData();
      dataUp.append('file', this.uploadfile);
      dataUp.append('documentcaseId', this.data);
      dataUp.append('qid', this.attachmentId);/*this.attachmentId 'Q2023020800002' */
      dataUp.append('version', this.userInfo.version);
      dataUp.append('token', this.userInfo.token);

      console.log("===>", dataUp);
      this._apiService.uploadDocumentLogAttachment(dataUp).subscribe((response: any) => {
        if (!response.error) {
          this.spinner.hide();
          /*  Swal.fire({
             position: 'center',
             icon: 'success',
             title: response.message,
             showConfirmButton: false,
             timer: 1500
           }) */
          this.detect.emit(true);
          this.dialogRef.close('true')

        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      }, (err: HttpErrorResponse) => {
        this.spinner.hide();
        if (err.status === 400 || err.status === 500) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.error.message,
            showConfirmButton: false,
            timer: 1500
          })
        } else {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
            showConfirmButton: false,
            timer: 1500
          })
        }
      })

    } else {
      this.spinner.hide();
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Please upload pdf, jpg , jpeg ,doc,excel or  png image',
        showConfirmButton: false,
        timer: 1500
      })
    }


  }

  checkBox(value: any, checked: any, array: any) {
    let arrayData = [...array]
    if (checked) {
      arrayData.push(value)
    } else {
      arrayData.forEach((ctrl: any, i: any) => {
        if (ctrl == value) {
          arrayData.splice(i, 1)
        }
      });
    }
    return arrayData
  }


}
