import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-thank-you',
  templateUrl: './training-thank-you.component.html',
  styleUrls: ['./training-thank-you.component.scss']
})
export class TrainingThankYouComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
