import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-complete',
  templateUrl: './training-complete.component.html',
  styleUrls: ['./training-complete.component.scss']
})
export class TrainingCompleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
