import { StorageService } from 'src/app/services/storage.service';
import { ApiService } from 'src/app/services/api.service';
import { AuthService } from './../../services/auth.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2'
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.scss']
})
export class OtpComponent implements OnInit {
  otpForm: FormGroup;
  formSumitAttempt: any = false;
  time: number = 180;
  display: any;
  interval: any;
  show: boolean = false;
  textInput: any = 'password'

  constructor(public dialogRef: MatDialogRef<OtpComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder, private _auth: AuthService, public _apiService: ApiService, private storageService: StorageService, private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    // console.log("data",this.data);
    this.startTimer();
    this.otpForm = this.fb.group({
      otp: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{6}$")]]
    })

    this.otpForm.controls['otp'].patchValue(this.data.otp)


  }

  get f() {
    return this.otpForm.controls;
  }


  isFieldValid(field: any) {
    return (
      (!field.valid && field.touched) ||
      (!field.valid &&
        field.untouched && this.formSumitAttempt)
    );
  }


  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  continue() {
    this.formSumitAttempt = true;

    if (this.otpForm.valid) {
      if (this.data.title == 'Phone Number Verification') {
        this.spinner.show();
        let data = {
          mobileNo: this.data.inputValue,
          otp: this.otpForm.value.otp,
          type: "verify-mobile-otp"
        }

        this._auth.mobileOtpVerification(data).subscribe(
          (response: any) => {
            if (!response.error) {
              this.spinner.hide();
              // Swal.fire({
              //   position: 'center',
              //   icon: 'success',
              //   title: response.message,
              //   showConfirmButton: false,
              //   timer: 1500
              // })
              this.clear()

              this.dialogRef.close(true);
            } else {
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: response.message,
                showConfirmButton: false,
                timer: 1500
              })
            }
          },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
          }
        );
      } else if (this.data.title == 'Email Verification') {
        this.spinner.show();
        let data = {
          emailId: this.data.inputValue.emailId,
          otp: this.otpForm.value.otp,
          type: "verify-email-otp"
        }

        this._auth.getEmailVerify(data).subscribe(
          (response: any) => {
            if (!response.error) {
              this.spinner.hide();
              // Swal.fire({
              //   position: 'center',
              //   icon: 'success',
              //   title: response.message,
              //   showConfirmButton: false,
              //   timer: 1500
              // })
              this.clear()
              this.dialogRef.close(true);
            } else {
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: response.message,
                showConfirmButton: false,
                timer: 1500
              })
            }
          },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })
            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
          }
        );
      } else if (this.data.title == 'Director Phone Number Verification') {
        this.spinner.show();
        let data = {
          mobileNo: this.data.inputValue.mobileNo,
          otp: this.otpForm.value.otp,
          type: "Director Phone Number Verification",
          directorId: this.data.inputValue.directorId,
          caseId: this.data.inputValue.caseId
        }

        this._apiService.verifyDirectorMobileOTP(data).subscribe(
          (response: any) => {
            if (!response.error) {
              this.spinner.hide();
              this.clear()
              this.dialogRef.close(true);
            } else {
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: response.message,
                showConfirmButton: false,
                timer: 1500
              })
            }
          },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
          }
        );
      } else if (this.data.title == 'Director Email Verification') {
        this.spinner.show();
        let data = {
          emailId: this.data.inputValue.emailId,
          otp: this.otpForm.value.otp,
          type: "Director Email Verification",
          directorId: this.data.inputValue.directorId,
          caseId: this.data.inputValue.caseId
        }

        this._apiService.verifyDirectorEmailOTP(data).subscribe(
          (response: any) => {
            if (!response.error) {
              this.spinner.hide();
              this.clear()
              this.dialogRef.close(true);
            } else {
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: response.message,
                showConfirmButton: false,
                timer: 1500
              })
            }
          },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
          }
        );
      } else if (this.data.title == 'CIBIL OTP') {
        this.spinner.show();
        let data = {
          emailId: this.data.inputValue.emailId,
          mobileNo: this.data.inputValue.mobileNo,
          otp: this.otpForm.value.otp,
          type: "verifyDirectorCibilOtp",
          directorId: this.data.inputValue.directorId,
          caseId: this.data.inputValue.caseId
        }

        this._apiService.verifyDirectorCibilOtp(data).subscribe(
          (response: any) => {
            if (!response.error) {
              this.spinner.hide();
              this.clear()
              this.dialogRef.close(true);
            } else {
              this.spinner.hide();
              Swal.fire({
                position: 'center',
                icon: 'warning',
                title: response.message,
                showConfirmButton: false,
                timer: 1500
              })
            }
          },
          (err: HttpErrorResponse) => {
            this.spinner.hide();
            if (err.status === 400) {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.error.message,
                showConfirmButton: false,
                timer: 1500
              })

            } else {
              Swal.fire({
                position: 'center',
                icon: 'error',
                title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
                showConfirmButton: false,
                timer: 1500
              })
            }
          }
        );
      }
      // else
      // if(this.data.title == 'Aadhar Verification'){
      // this._apiService.verifyAdharOtp({...this.data.inputValue,otp:this.otpForm.value.otp,}).subscribe(
      //   (response: any) => {
      //     if(!response.error){
      //       Swal.fire({
      //         position: 'center',
      //         icon: 'success',
      //         title: response.message,
      //         showConfirmButton: false,
      //         timer: 1500
      //       })

      //   this.storageService.secureStorage.setItem('Aadhar',response.data.result)

      //     this.dialogRef.close(true);
      //     }else{
      //       Swal.fire({
      //         position: 'center',
      //         icon: 'warning',
      //         title: response.message,
      //         showConfirmButton: false,
      //         timer: 1500
      //       })
      //     }
      //   },
      //   (err: HttpErrorResponse) => {
      //     if (err.status === 400) {
      //       Swal.fire({
      //         position: 'center',
      //         icon: 'error',
      //         title: err.error.message,
      //         showConfirmButton: false,
      //         timer: 1500
      //       })
      //     } else {
      //       Swal.fire({
      //         position: 'center',
      //         icon: 'error',
      //         title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
      //         showConfirmButton: false,
      //         timer: 1500
      //       })
      //     }
      //   }
      // );
      // }else if (this.data.title == 'Director Aadhar Verification'){
      //   this._apiService.directorAdhaarOtpVerify({...this.data.inputValue,otp:this.otpForm.value.otp,}).subscribe(
      //     (response: any) => {
      //       if(!response.error){
      //         Swal.fire({
      //           position: 'center',
      //           icon: 'success',
      //           title: response.message,
      //           showConfirmButton: false,
      //           timer: 1500
      //         })

      //     this.storageService.secureStorage.setItem('Aadhar',response.data.result)

      //       this.dialogRef.close(true);
      //       }else{
      //         Swal.fire({
      //           position: 'center',
      //           icon: 'warning',
      //           title: response.message,
      //           showConfirmButton: false,
      //           timer: 1500
      //         })
      //       }
      //     },
      //     (err: HttpErrorResponse) => {
      //       if (err.status === 400) {
      //         Swal.fire({
      //           position: 'center',
      //           icon: 'error',
      //           title: err.error.message,
      //           showConfirmButton: false,
      //           timer: 1500
      //         })
      //       } else {
      //         Swal.fire({
      //           position: 'center',
      //           icon: 'error',
      //           title: err.message?err.message: err.error.message ? err.error.message: 'Server error' ,
      //           showConfirmButton: false,
      //           timer: 1500
      //         })
      //       }
      //     }
      //   );
      //   }
    }
  }


  resendOTP(title: any, mobile: any, email: any) {
    if (title == 'Email Verification') {
      this.spinner.show();
      this._auth.login({ ...mobile }).subscribe((response: any) => {
        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.startTimer();

        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })

          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }

        })

    } else if (title == 'Phone Number Verification') {
      // value = this.form.value.phoneNumber;
      this.spinner.show();
      let data = {
        mobileNo: mobile,
        type: "verify-mobile-otp"
      }
      this._auth.login(data).subscribe((response: any) => {
        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            // title: response.message + response.OTP,
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.startTimer();
        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
        })
    } else if (title == 'Director Email Verification') {
      let data = this.data.inputValue

      this._apiService.sendDirectorVerificationOtp(data).subscribe((response: any) => {

        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.startTimer();

        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
        })
      console.log("/////", data);
      // const dialogRef = this.dialog.open(OtpComponent, {
      //   disableClose: true,
      //   width: '400px',
      //   data: { title: title, message: message , inputValue:data , otp:'123456' },
      // });
    } else if (title == 'Director Phone Number Verification') {
      let data = this.data.inputValue
      this._apiService.sendDirectorVerificationOtp(data).subscribe((response: any) => {

        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.startTimer();

        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
        })

      // const dialogRef = this.dialog.open(OtpComponent, {
      //   disableClose: true,
      //   width: '400px',
      //   data: { title: title, message: message , inputValue:data, otp:'123456' },
      // });

    } else if (title == 'CIBIL OTP') {
      let data = this.data.inputValue
      this._apiService.sendDirectorVerificationOtp(data).subscribe((response: any) => {

        if (!response.error) {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
          this.startTimer();
        } else {
          this.spinner.hide();
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: response.message,
            showConfirmButton: false,
            timer: 1500
          })
        }
      },
        (err: HttpErrorResponse) => {
          this.spinner.hide();
          if (err.status === 400) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.error.message,
              showConfirmButton: false,
              timer: 1500
            })
          } else {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: err.message ? err.message : err.error.message ? err.error.message : 'Server error',
              showConfirmButton: false,
              timer: 1500
            })
          }
        })

    }
  }

  startTimer() {
    this.time = 180;
    this.show = false;
    clearInterval(this.interval);
    // console.log("=====>");
    this.interval = setInterval(() => {
      if (this.time === 0) {
        this.time--;
      } else {
        this.time--;
      }
      this.display = this.transform(this.time)

      // console.log("this.displaythis.displaythis.display",this.display);

      if (this.display == '0:0') {
        this.show = true;
        clearInterval(this.interval);
      }
    }, 1000);
  }


  transform(value: number): string {
    const minutes: number = Math.floor(value / 60);
    return minutes + ':' + (value - minutes * 60);
  }


  clear() {
    clearInterval(this.interval);
  }
}
