import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, Inject } from '@angular/core';
import { FormArray, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { ApiService } from 'src/app/services/api.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { StorageService } from './../../services/storage.service';

@Component({
  selector: 'app-partner-filters',
  templateUrl: './partner-filters.component.html',
  styleUrls: ['./partner-filters.component.scss']
})
export class PartnerFiltersComponent implements OnInit {
  form: any;
  formArray: FormArray;
  agentType: any=[];
  appointmentStatus: any[]=[];
  eventName: any[]=[];
  eventType: any[]=[];
  isWebRequest: boolean = false;
  
  userInfo: any;
  userDetails: any;
  branchArray: any;

  constructor(public dialogRef: MatDialogRef<PartnerFiltersComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private storageService: StorageService,private fb:FormBuilder,public _apiService:ApiService,private spinner: NgxSpinnerService ) { }

  ngOnInit(): void {
    this.userInfo = this.storageService.secureStorage.getItem("userinfo");

    this.form = this.fb.group({
      agentType:[''],
      appointmentFromDate:[''],
      appointmentToDate:[''],
      eventType:[''],
    })


    this.getBranch()

  }

  getBranch(){
    
    let data={
      searchTerm:"",
      token:this.userInfo.token,
      version:this.userInfo.version
    }
    this._apiService.getBranchData(data).subscribe((res)=>{

      if(!res.error){
        // console.log(res);
        this.branchArray = res.data ;
        // console.log("this.branchArraythis.branchArray",this.branchArray);
        
      }

    },(err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: err.error.message,
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: err.message?err.message: err.error.message ? err.error.message: 'Server error',
          showConfirmButton: false,
          timer: 1500
        })
      }
      this.isWebRequest = false;
    })
  }

  checkChange(event:any,value:any) {

    if(value =='agentType'){
      this.agentType =  this.checkBox(event.source.value,event.source.checked,this.agentType);
    }else  if(value =='eventType'){
      this.eventType =  this.checkBox(event.source.value,event.source.checked,this.eventType);
    }
   
  }

  checkBox(value:any,checked:any,array:any) {
    let arrayData = [...array] 
    if(checked){
      arrayData.push(value)
    }else{
      arrayData.forEach((ctrl: any,i:any) => {
      if(ctrl == value) {
        arrayData.splice(i,1)
      }
    });
    }
    return arrayData
  }




  continue() {
    // console.log(this.form);
    let data={
      fromDate:this.form.value.appointmentFromDate,
      toDate:this.form.value.appointmentToDate,
      agentType:this.agentType,
      eventType:this.eventType,
      branchList:this.eventType
    }


    

    // console.log("datadatadata",data);

   
 
    
    this.dialogRef.close({data:data , status:true});
  }

}
