// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  // api: "http://8a8d-2402-e280-3e5e-38-8d4f-2644-6140-4643.ngrok.io/api",
  // imgUrl:"http://8a8d-2402-e280-3e5e-38-8d4f-2644-6140-4643.ngrok.io/",

  // api: "http://localhost:8000/api",                                           //local
  // imgUrl: "http://localhost:8000/",                                           //local
  // documentURL: "http://localhost:9000/api",                //local
  // terms_n_condition_url: "http://localhost:4200/assets/term_condition.html",  //local
  // partnerlink: "http://192.168.1.114:4200/#/onboarding", 
  // incentiveURL:'http://localhost:8000',
  //                      //Local

  api: "https://ezportal.adityabirlacapital.com/api",                                  //Production
  imgUrl: "https://ezportal.adityabirlacapital.com/",                                   //Production
  terms_n_condition_url: "https://ezportal.adityabirlacapital.com/term_condition.html", //Production
  partnerlink: "https://ezportal.adityabirlacapital.com/?onboarding=",                  //Production
  documentURL: "https://ezportal.adityabirlacapital.com/api",                          //Production
  incentiveURL:'https://ezportal.adityabirlacapital.com',

  // api: "https://ezportaluat.adityabirlacapital.com/api",                                  //UAT
  // imgUrl: "https://ezflouat.insideabc.com/api/public/",                                    //UAT
  // terms_n_condition_url: "https://ezportaluat.adityabirlacapital.com/term_condition.html", //UAT
  // partnerlink: "https://ezportaluat.adityabirlacapital.com/?onboarding=",                  //UAT
  // documentURL: "https://ezportaluat.adityabirlacapital.com/api",                           //UAT

  cyberArkUrl: 'https://aaq4824.id.cyberark.cloud/abhflezportalprod/',
  
  // partnerlink:'https://dsaportal.abhfl.com'
  // applicantUrl:""


  // partnerlink:"https://ezportal.adityabirlacapital.com/#/onboarding",
  // partnerlink:"https://ezportal.adityabirlacapital.com/?onboarding=",    //////Production
  //////Server
 // encKey: 'ABHFL@AFT@Aug2022',
  adfsUrl: 'https://login.adityabirlacapital.com/adfs',
  serviceUrl: '',
  // serviceUrl: 'https://192.168.1.47:44369',
  redirectUri: 'https://ezflo.adityabirlacapital.com',
  // clientId: 'e68004dc-fff8-46a0-a61b-ec52a56490a5',
  clientId: 'efe6531e-b8b1-4d23-ac73-68d00ff0dea5',
  loginUrl: 'https://login.adityabirlacapital.com/adfs/oauth2/authorize/',
  logoutUrl: 'https://login.adityabirlacapital.com/adfs/oauth2/logout',

  tollfree_mobile_number_text: '1800-270-7000',
  tollfree_mobile_number: '18002707000'
};

/*

 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
